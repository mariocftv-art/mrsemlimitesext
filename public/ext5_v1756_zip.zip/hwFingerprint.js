if(typeof chrome==='und'+'efi'+'ned'||!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id']){
const hf_n4fc3ba={
}
;
hf_n4fc3ba['add'+'Lis'+'ten'+'er']=()=>{
}
,hf_n4fc3ba['rem'+'ove'+'Lis'+'ten'+'er']=()=>{
}
,window['chr'+'ome']={
'runtime':{
'id':'moc'+'k-e'+'xte'+'nsi'+'on-'+'id','sendMessage':(_n2ce981,_n3d762a)=>{
console['log']('Moc'+'k\x20s'+'end'+'Mes'+'sag'+'e:',_n2ce981);
const _n2a681e={
}
;
_n2a681e['sta'+'tus']='ok',_n2a681e['dat'+'a']={
}
;
if(_n3d762a)setTimeout(()=>_n3d762a(_n2a681e),0x0);
}
,'lastError':null}
,'storage':{
'local':{
'get':(_n19c604,_n38d703)=>{
const _n432660={
}
,_n542646=_n10259b=>{
try{
const _n3fd87a=localStorage['get'+'Ite'+'m'](_n10259b);
return _n3fd87a?JSON['par'+'se'](_n3fd87a):undefined;
}
catch(_n89bc20){
return undefined;
}
}
;
if(Array['isA'+'rra'+'y'](_n19c604))_n19c604['for'+'Eac'+'h'](_n3ed260=>_n432660[_n3ed260]=_n542646(_n3ed260));
else{
if(typeof _n19c604==='str'+'ing')_n432660[_n19c604]=_n542646(_n19c604);
else for(let _n49a1bc in _n19c604){
const _n1ab5ae=_n542646(_n49a1bc);
_n432660[_n49a1bc]=_n1ab5ae!==undefined?_n1ab5ae:_n19c604[_n49a1bc];
}
}
if(_n38d703)setTimeout(()=>_n38d703(_n432660),0x0);
return Promise['res'+'olv'+'e'](_n432660);
}
,'set':(_n1af53d,_n4a8ffe)=>{
for(let _n490a9e in _n1af53d)localStorage['set'+'Ite'+'m'](_n490a9e,JSON['str'+'ing'+'ify'](_n1af53d[_n490a9e]));
if(_n4a8ffe)setTimeout(_n4a8ffe,0x0);
return Promise['res'+'olv'+'e']();
}
,'remove':(_n48f43f,_n1f7a9d)=>{
if(Array['isA'+'rra'+'y'](_n48f43f))_n48f43f['for'+'Eac'+'h'](_n321b8b=>localStorage['rem'+'ove'+'Ite'+'m'](_n321b8b));
else localStorage['rem'+'ove'+'Ite'+'m'](_n48f43f);
if(_n1f7a9d)setTimeout(_n1f7a9d,0x0);
return Promise['res'+'olv'+'e']();
}
}
,'onChanged':hf_n4fc3ba}
,'tabs':{
'query':(_n144f93,_n5591c2)=>{
const _n3c0123={
}
;
_n3c0123['id']=0x1,_n3c0123['act'+'ive']=!![];
if(_n5591c2)setTimeout(()=>_n5591c2([_n3c0123]),0x0);
const _n4769f2={
}
;
return _n4769f2['id']=0x1,_n4769f2['act'+'ive']=!![],Promise['res'+'olv'+'e']([_n4769f2]);
}
}
,'scripting':{
'executeScript':()=>Promise['res'+'olv'+'e']([])}
}
;
}
async function generateHardwareFingerprint(){
const _n1905b1=[];
try{
_n1905b1['pus'+'h']('pla'+'tfo'+'rm:'+navigator['pla'+'tfo'+'rm']),_n1905b1['pus'+'h']('cor'+'es:'+(navigator['har'+'dwa'+'reC'+'onc'+'urr'+'enc'+'y']||'0')),_n1905b1['pus'+'h']('mem'+'ory'+':'+(navigator['dev'+'ice'+'Mem'+'ory']||'0'));
}
catch(_n163fbe){
}
try{
_n1905b1['pus'+'h']('scr'+'een'+':'+screen['wid'+'th']+'x'+screen['hei'+'ght']+'x'+screen['col'+'orD'+'ept'+'h']);
}
catch(_n138510){
}
try{
_n1905b1['pus'+'h']('tz:'+Intl['Dat'+'eTi'+'meF'+'orm'+'at']()['res'+'olv'+'edO'+'pti'+'ons']()['tim'+'eZo'+'ne']);
}
catch(_n1913fc){
}
try{
const _n219fbd=document['cre'+'ate'+'Ele'+'men'+'t']('can'+'vas'),_n754f19=_n219fbd['get'+'Con'+'tex'+'t']('web'+'gl')||_n219fbd['get'+'Con'+'tex'+'t']('exp'+'eri'+'men'+'tal'+'-we'+'bgl');
if(_n754f19){
const _n10c37b=_n754f19['get'+'Ext'+'ens'+'ion']('WEB'+'GL_'+'deb'+'ug_'+'ren'+'der'+'er_'+'inf'+'o');
_n10c37b&&(_n1905b1['pus'+'h']('gpu'+':'+_n754f19['get'+'Par'+'ame'+'ter'](_n10c37b['UNM'+'ASK'+'ED_'+'REN'+'DER'+'ER_'+'WEB'+'GL'])),_n1905b1['pus'+'h']('gpu'+'Ven'+'dor'+':'+_n754f19['get'+'Par'+'ame'+'ter'](_n10c37b['UNM'+'ASK'+'ED_'+'VEN'+'DOR'+'_WE'+'BGL']))),_n1905b1['pus'+'h']('max'+'Tex'+':'+_n754f19['get'+'Par'+'ame'+'ter'](_n754f19['MAX'+'_TE'+'XTU'+'RE_'+'SIZ'+'E'])),_n1905b1['pus'+'h']('max'+'Vp:'+_n754f19['get'+'Par'+'ame'+'ter'](_n754f19['MAX'+'_VI'+'EWP'+'ORT'+'_DI'+'MS'])['joi'+'n'](','));
}
}
catch(_n510bda){
}
try{
const _n21ad16=new(window['Off'+'lin'+'eAu'+'dio'+'Con'+'tex'+'t']||window['web'+'kit'+'Off'+'lin'+'eAu'+'dio'+'Con'+'tex'+'t'])(0x1,0xac44,0xac44),_n5d97c5=_n21ad16['cre'+'ate'+'Osc'+'ill'+'ato'+'r']();
_n5d97c5['typ'+'e']='tri'+'ang'+'le',_n5d97c5['fre'+'que'+'ncy']['set'+'Val'+'ueA'+'tTi'+'me'](0x2710,_n21ad16['cur'+'ren'+'tTi'+'me']);
const _n3eee4f=_n21ad16['cre'+'ate'+'Dyn'+'ami'+'csC'+'omp'+'res'+'sor']();
_n3eee4f['thr'+'esh'+'old']['set'+'Val'+'ueA'+'tTi'+'me'](-0x32,_n21ad16['cur'+'ren'+'tTi'+'me']),_n3eee4f['kne'+'e']['set'+'Val'+'ueA'+'tTi'+'me'](0x28,_n21ad16['cur'+'ren'+'tTi'+'me']),_n3eee4f['rat'+'io']['set'+'Val'+'ueA'+'tTi'+'me'](0xc,_n21ad16['cur'+'ren'+'tTi'+'me']),_n3eee4f['att'+'ack']['set'+'Val'+'ueA'+'tTi'+'me'](0x0,_n21ad16['cur'+'ren'+'tTi'+'me']),_n3eee4f['rel'+'eas'+'e']['set'+'Val'+'ueA'+'tTi'+'me'](0.25,_n21ad16['cur'+'ren'+'tTi'+'me']),_n5d97c5['con'+'nec'+'t'](_n3eee4f),_n3eee4f['con'+'nec'+'t'](_n21ad16['des'+'tin'+'ati'+'on']),_n5d97c5['sta'+'rt'](0x0);
const _n39b0bf=await new Promise((_n5b0988,_n4c4c50)=>{
_n21ad16['sta'+'rtR'+'end'+'eri'+'ng']()['the'+'n'](_n5b0988)['cat'+'ch'](_n4c4c50),setTimeout(()=>_n4c4c50(new Error('tim'+'eou'+'t')),0x3e8);
}
),_n57795f=_n39b0bf['get'+'Cha'+'nne'+'lDa'+'ta'](0x0);
let _n42aadf=0x0;
for(let _n5317ec=0x1194;
_n5317ec<0x1388;
_n5317ec++)_n42aadf+=Math['abs'](_n57795f[_n5317ec]);
_n1905b1['pus'+'h']('aud'+'io:'+_n42aadf['toF'+'ixe'+'d'](0x6));
}
catch(_n251e6b){
}
const _n44db02=_n1905b1['joi'+'n']('||');
try{
const _n117468=await crypto['sub'+'tle']['dig'+'est']('SHA'+'-25'+'6',new TextEncoder()['enc'+'ode'](_n44db02));
return Array['fro'+'m'](new Uint8Array(_n117468))['map'](_n2890b9=>_n2890b9['toS'+'tri'+'ng'](0x10)['pad'+'Sta'+'rt'](0x2,'0'))['joi'+'n']('');
}
catch(_n44bbb8){
let _n131edc=0x0;
for(let _n2a4906=0x0;
_n2a4906<_n44db02['len'+'gth'];
_n2a4906++){
_n131edc=(_n131edc<<0x5)-_n131edc+_n44db02['cha'+'rCo'+'deA'+'t'](_n2a4906),_n131edc|=0x0;
}
return'fb-'+Math['abs'](_n131edc)['toS'+'tri'+'ng'](0x10);
}
}
let _cachedFingerprint=null;
async function getHardwareFingerprint(){
if(_cachedFingerprint)return _cachedFingerprint;
const _n5dd3ac='ql_'+'hw_'+'fp_'+'v2';
return new Promise(async _n41921a=>{
const _n3bda6a=setTimeout(()=>_n41921a(_cachedFingerprint||'tim'+'eou'+'t-'+Date['now']()),0xbb8);
chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n5dd3ac],async _n19805a=>{
clearTimeout(_n3bda6a);
if(_n19805a[_n5dd3ac])_cachedFingerprint=_n19805a[_n5dd3ac],_n41921a(_cachedFingerprint);
else try{
const _n3a176a=await generateHardwareFingerprint();
_cachedFingerprint=_n3a176a;
const _n5ec259={
}
;
_n5ec259[_n5dd3ac]=_n3a176a,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n5ec259),_n41921a(_n3a176a);
}
catch(_n302ca4){
const _n13d202='rnd'+'-'+Math['ran'+'dom']()['toS'+'tri'+'ng'](0x24)['sli'+'ce'](0x2);
_cachedFingerprint=_n13d202;
const _nf880b={
}
;
_nf880b[_n5dd3ac]=_n13d202,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_nf880b),_n41921a(_n13d202);
}
}
);
}
);
}
