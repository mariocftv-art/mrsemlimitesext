(function() {
  const style = document.createElement('style');
  style.textContent = `
    /* Premium MR SEM LIMITES Activation Overlay */
    .sp-activation-container, .sp-gate-container, [class*="gate-container"], [class*="login-container"] {
      background: #0f172a !important;
      border-radius: 24px !important;
      border: 1px solid rgba(59, 130, 246, 0.2) !important;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5) !important;
      padding: 40px !important;
      max-width: 400px !important;
    }
    .sp-gate-title, [class*="gate-title"] {
      font-family: 'Inter', sans-serif !important;
      font-weight: 800 !important;
      font-size: 24px !important;
      color: #fff !important;
      margin-bottom: 8px !important;
    }
    .sp-license-btn, [class*="primary-btn"] {
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
      border: none !important;
      border-radius: 12px !important;
      color: #fff !important;
      font-weight: 700 !important;
      padding: 14px !important;
      width: 100% !important;
      margin-top: 16px !important;
      cursor: pointer !important;
      transition: all 0.2s !important;
    }
    img[src*="logo"] {
      filter: brightness(0) invert(1) !important; /* Forçar logo a ser branca se for icon */
    }
  `;
  document.head.appendChild(style);
  console.log("MR SEM LIMITES Premium Overlay Loaded");
})();
