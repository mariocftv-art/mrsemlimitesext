const _um_h='cvb'+'grj'+'auq'+('jaw'+'rsy'+'knh'+'yj'),UploadManager={
'MAX_FILE_SIZE':Infinity,'MAX_FILES':0xf,'BUCKET_NAME':'fil'+'es','SUPABASE_URL':'htt'+'ps:'+'//'+_um_h+('.su'+'pab'+'ase'+'.co'),'SUPABASE_ANON_KEY':['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'ImN'+'2Ym'+'d','yam'+'F1c'+'Wph'+'d3J'+'zeW'+'tua'+'H','lqI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'NzU'+'2','NTk'+'1OT'+'YsI'+'mV4'+'cCI'+'6Mj'+'A','5MT'+'IzN'+'TU5'+'Nn0'+'.Jd'+'ZeY'+'3','9iG'+'HcZ'+'5P3'+'p0D'+'DXY'+'VUv'+'N','JfM'+'rKp'+'_Or'+'aUC'+'5ED'+'yzU']['joi'+'n'](''),async 'uploadFile'(_nb92935,_n4308bd,_n38f750){
if(!_nb92935)throw new Error('Arq'+'uiv'+'o\x20n'+'ão\x20'+'for'+'nec'+'ido');
const _n570737=_nb92935['nam'+'e']['rep'+'lac'+'e'](/[^a-zA-Z0-9.-]/g,'_'),_n5f317b=Date['now'](),_n1700f9='ass'+'ets'+'/'+_n5f317b+'-'+_n570737,_nc1163a=['fil'+'es','pub'+'lic','upl'+'oad'+'s'];
if(_n38f750)_n38f750(0xa);
let _n403196='Nen'+'hum'+'\x20bu'+'cke'+'t\x20d'+'isp'+'oní'+'vel';
for(const _n1dccb6 of _nc1163a){
const _n124e3f=this['SUP'+'ABA'+'SE_'+'URL']+('/st'+'ora'+'ge/'+'v1/'+'obj'+'ect'+'/')+_n1dccb6+'/'+_n1700f9;
try{
const _n21e32d={
}
;
_n21e32d['api'+'key']=this['SUP'+'ABA'+'SE_'+'ANO'+'N_K'+'EY'],_n21e32d['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+this['SUP'+'ABA'+'SE_'+'ANO'+'N_K'+'EY'],_n21e32d['Con'+'ten'+'t-T'+'ype']=_nb92935['typ'+'e']||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam',_n21e32d['x-u'+'pse'+'rt']='tru'+'e',_n21e32d['Cac'+'he-'+'Con'+'tro'+'l']='360'+'0';
const _n5e9625={
}
;
_n5e9625['met'+'hod']='POS'+'T',_n5e9625['hea'+'der'+'s']=_n21e32d,_n5e9625['bod'+'y']=_nb92935;
const _n53a94e=await fetch(_n124e3f,_n5e9625);
if(_n53a94e['ok']){
if(_n38f750)_n38f750(0x64);
const _n5d19ed=this['SUP'+'ABA'+'SE_'+'URL']+('/st'+'ora'+'ge/'+'v1/'+'obj'+'ect'+'/pu'+'bli'+'c/')+_n1dccb6+'/'+_n1700f9;
return console['log']('[Up'+'loa'+'dMa'+'nag'+'er]'+'\x20✅\x20'+'Upl'+'oad'+'\x20OK'+'\x20→\x20'+'buc'+'ket'+':'+_n1dccb6+'\x20→\x20'+_n5d19ed),_n5d19ed;
}
const _n1818d7=await _n53a94e['jso'+'n']()['cat'+'ch'](()=>({
}
));
_n403196=_n1818d7['mes'+'sag'+'e']||'HTT'+'P\x20'+_n53a94e['sta'+'tus'],console['war'+'n']('[Up'+'loa'+'dMa'+'nag'+'er]'+'\x20bu'+'cke'+'t\x20\x27'+_n1dccb6+('\x27\x20r'+'ecu'+'sou'+'\x20(')+_n53a94e['sta'+'tus']+'):\x20'+_n403196);
}
catch(_n479386){
_n403196=_n479386&&_n479386['mes'+'sag'+'e']?_n479386['mes'+'sag'+'e']:String(_n479386),console['war'+'n']('[Up'+'loa'+'dMa'+'nag'+'er]'+'\x20Er'+'ro\x20'+'de\x20'+'red'+'e\x20n'+'o\x20b'+'uck'+'et\x20'+'\x27'+_n1dccb6+'\x27:\x20'+_n403196);
}
}
if(_n38f750)_n38f750(0x64);
throw new Error('Upl'+'oad'+'\x20Su'+'pab'+'ase'+'\x20fa'+'lho'+'u\x20e'+'m\x20t'+'odo'+'s\x20o'+'s\x20b'+'uck'+'ets'+'.\x20Ú'+'lti'+'mo\x20'+'err'+'o:\x20'+_n403196);
}
,'isImageType'(_n39da04){
return _n39da04&&_n39da04['sta'+'rts'+'Wit'+'h']('ima'+'ge/');
}
,'isVideoType'(_n12f509){
return _n12f509&&(_n12f509['sta'+'rts'+'Wit'+'h']('vid'+'eo/')||_n12f509['end'+'sWi'+'th']('mp4')||_n12f509['end'+'sWi'+'th']('web'+'m'));
}
,'getFileIcon'(_ne8bfdc,_n31f488=''){
const _n78bc24=_n31f488['spl'+'it']('.')['pop']()['toL'+'owe'+'rCa'+'se']();
if(this['isI'+'mag'+'eTy'+'pe'](_ne8bfdc)||['jpg','jpe'+'g','png','gif','web'+'p','svg']['inc'+'lud'+'es'](_n78bc24))return'🖼️';
if(this['isV'+'ide'+'oTy'+'pe'](_ne8bfdc)||['mp4','web'+'m','mov','avi']['inc'+'lud'+'es'](_n78bc24))return'🎬';
if(_ne8bfdc['inc'+'lud'+'es']('pdf')||_n78bc24==='pdf')return'📕';
if(_ne8bfdc['inc'+'lud'+'es']('zip')||_ne8bfdc['inc'+'lud'+'es']('rar')||['zip','rar','7z','tar','gz']['inc'+'lud'+'es'](_n78bc24))return'📦';
if(_ne8bfdc['inc'+'lud'+'es']('wor'+'d')||_ne8bfdc['inc'+'lud'+'es']('doc'+'ume'+'nt')||['doc','doc'+'x']['inc'+'lud'+'es'](_n78bc24))return'📝';
if(_ne8bfdc['inc'+'lud'+'es']('exc'+'el')||_ne8bfdc['inc'+'lud'+'es']('she'+'et')||['xls','xls'+'x','csv']['inc'+'lud'+'es'](_n78bc24))return'📊';
if(_ne8bfdc['inc'+'lud'+'es']('aud'+'io')||['mp3','wav','ogg']['inc'+'lud'+'es'](_n78bc24))return'🎵';
return'📄';
}
,'formatFileSize'(_n402fc5){
if(_n402fc5===0x0)return'0\x20B';
const _n53c9b5=0x400,_n2b6235=['B','KB','MB','GB'],_n5a881c=Math['flo'+'or'](Math['log'](_n402fc5)/Math['log'](_n53c9b5));
return parseFloat((_n402fc5/Math['pow'](_n53c9b5,_n5a881c))['toF'+'ixe'+'d'](0x1))+'\x20'+_n2b6235[_n5a881c];
}
,'formatFilesPayload'(_n5e40ec){
if(!_n5e40ec||_n5e40ec['len'+'gth']===0x0)return'';
if(_n5e40ec['len'+'gth']===0x1)return _n5e40ec[0x0]['url']||'';
return JSON['str'+'ing'+'ify'](_n5e40ec['map'](_n71916e=>({
'url':_n71916e['url']||_n71916e['pub'+'lic'+'Url'],'name':_n71916e['nam'+'e']||_n71916e['fil'+'e_n'+'ame'],'type':(_n71916e['typ'+'e']||_n71916e['fil'+'e_t'+'ype']||'')['spl'+'it']('/')[0x0]||'fil'+'e'}
)));
}
}
;
