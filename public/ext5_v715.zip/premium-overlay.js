(function() {
  const style = document.createElement('style');
  style.textContent = `
    /* Premium MR SEM LIMITES Activation Overlay */
    .sp-activation-container, .sp-gate-container {
      background: #0f172a !important;
      border-radius: 24px !important;
      border: 1px solid rgba(59, 130, 246, 0.2) !important;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5) !important;
      padding: 40px !important;
      max-width: 400px !important;
    }
    .sp-gate-title {
      font-family: 'Inter', sans-serif !important;
      font-weight: 800 !important;
      font-size: 24px !important;
      color: #fff !important;
      margin-bottom: 8px !important;
    }
    .sp-gate-subtitle {
      color: #94a3b8 !important;
      font-size: 14px !important;
    }
    .sp-license-input {
      background: rgba(30, 41, 59, 0.5) !important;
      border: 1px solid #334155 !important;
      border-radius: 12px !important;
      color: #fff !important;
      padding: 12px 16px !important;
      font-family: monospace !important;
      width: 100% !important;
      margin-top: 20px !important;
    }
    .sp-license-btn {
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
      border: none !important;
      border-radius: 12px !important;
      color: #fff !important;
      font-weight: 700 !important;
      padding: 14px !important;
      width: 100% !important;
      margin-top: 16px !important;
      cursor: pointer !important;
      transition: all 0.2s !important;
      box-shadow: 0 10px 15px -3px rgba(59, 130, 246, 0.3) !important;
    }
    .sp-license-btn:hover {
      transform: translateY(-2px) !important;
      box-shadow: 0 20px 25px -5px rgba(59, 130, 246, 0.4) !important;
    }
  `;
  document.head.appendChild(style);
})();
