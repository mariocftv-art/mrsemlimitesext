
// [Manus] Mr Sem Limite Ext 2 - Core Engine
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-INFINITO',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-infinite-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-KEY-INF',
        'ql_ed': 'DEVICE-INF-999'
    };

    // Storage Proxy
    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            let hasMock = false;
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) {
                    res[k] = MOCK_DATA[k];
                    hasMock = true;
                }
            });
            if (hasMock) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Intercept fetch for license validation
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license') || urlStr.includes('/validate')) {
                return new Response(JSON.stringify({
                    valid: true,
                    ok: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-infinite-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };

    // Message Bridge
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'sendMessage' || request.action === 'lovableDirectSend') {
            console.log("[Manus] Handling action:", request.action);
            
            chrome.storage.local.get([
                'lovable_token', 
                'lovable_projectId', 
                'lovable_browser_session_id',
                'ql_real_lovable_payload'
            ], async (res) => {
                try {
                    const token = request.token || res.lovable_token;
                    const projectId = request.projectId || res.lovable_projectId;
                    const message = request.message || request.mensagem;
                    
                    if (!token || !projectId) {
                        sendResponse({ success: false, ok: false, error: 'Token ou Projeto não encontrado.' });
                        return;
                    }

                    const payload = res.ql_real_lovable_payload || {};
                    const body = {
                        ...payload,
                        message: message,
                        files: request.attachments || request.files || [],
                        optimisticImageUrls: request.optimisticUrls || request.lovable_optimistic_urls || []
                    };

                    const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.replace('Bearer ', '')}`,
                            'Content-Type': 'application/json',
                            'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                        },
                        body: JSON.stringify(body)
                    });

                    if (response.ok) {
                        const data = await response.json().catch(() => ({}));
                        sendResponse({ success: true, ok: true, data: data });
                    } else {
                        const errData = await response.json().catch(() => ({}));
                        sendResponse({ success: false, ok: false, error: errData.message || 'Erro na API do Lovable' });
                    }
                } catch (err) {
                    sendResponse({ success: false, ok: false, error: err.message });
                }
            });
            return true; // Keep channel open for async response
        }
    });
})();


// [Manus] Mr Sem Limite Ext 2 - Core Engine
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-INFINITO',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-infinite-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-KEY-INF',
        'ql_ed': 'DEVICE-INF-999'
    };

    // Storage Proxy
    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            let hasMock = false;
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) {
                    res[k] = MOCK_DATA[k];
                    hasMock = true;
                }
            });
            if (hasMock) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Intercept fetch for license validation
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license') || urlStr.includes('/validate')) {
                return new Response(JSON.stringify({
                    valid: true,
                    ok: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-infinite-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };

    // Message Bridge
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'sendMessage' || request.action === 'lovableDirectSend') {
            console.log("[Manus] Handling action:", request.action);
            
            chrome.storage.local.get([
                'lovable_token', 
                'lovable_projectId', 
                'lovable_browser_session_id',
                'ql_real_lovable_payload'
            ], async (res) => {
                try {
                    const token = request.token || res.lovable_token;
                    const projectId = request.projectId || res.lovable_projectId;
                    const message = request.message || request.mensagem;
                    
                    if (!token || !projectId) {
                        sendResponse({ success: false, ok: false, error: 'Token ou Projeto não encontrado.' });
                        return;
                    }

                    const payload = res.ql_real_lovable_payload || {};
                    const body = {
                        ...payload,
                        message: message,
                        files: request.attachments || request.files || [],
                        optimisticImageUrls: request.optimisticUrls || request.lovable_optimistic_urls || []
                    };

                    const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.replace('Bearer ', '')}`,
                            'Content-Type': 'application/json',
                            'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                        },
                        body: JSON.stringify(body)
                    });

                    if (response.ok) {
                        const data = await response.json().catch(() => ({}));
                        sendResponse({ success: true, ok: true, data: data });
                    } else {
                        const errData = await response.json().catch(() => ({}));
                        sendResponse({ success: false, ok: false, error: errData.message || 'Erro na API do Lovable' });
                    }
                } catch (err) {
                    sendResponse({ success: false, ok: false, error: err.message });
                }
            });
            return true; // Keep channel open for async response
        }
    });
})();


// [Manus] Mr Sem Limite Ext 2 - Core Engine
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-INFINITO',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-infinite-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-KEY-INF',
        'ql_ed': 'DEVICE-INF-999'
    };

    // Storage Proxy
    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            let hasMock = false;
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) {
                    res[k] = MOCK_DATA[k];
                    hasMock = true;
                }
            });
            if (hasMock) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Intercept fetch for license validation
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license') || urlStr.includes('/validate')) {
                return new Response(JSON.stringify({
                    valid: true,
                    ok: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-infinite-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };

    // Message Bridge
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'sendMessage' || request.action === 'lovableDirectSend') {
            console.log("[Manus] Handling action:", request.action);
            
            chrome.storage.local.get([
                'lovable_token', 
                'lovable_projectId', 
                'lovable_browser_session_id',
                'ql_real_lovable_payload'
            ], async (res) => {
                try {
                    const token = request.token || res.lovable_token;
                    const projectId = request.projectId || res.lovable_projectId;
                    const message = request.message || request.menagem;
                    
                    if (!token || !projectId) {
                        sendResponse({ success: false, ok: false, error: 'Token ou Projeto não encontrado.' });
                        return;
                    }

                    const payload = res.ql_real_lovable_payload || {};
                    const body = {
                        ...payload,
                        message: message,
                        optimisticImageUrls: request.optimisticUrls || request.lovable_optimistic_urls || []
                    };

                    const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.replace('Bearer ', '')}`,
                            'Content-Type': 'application/json',
                            'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                        },
                        body: JSON.stringify(body)
                    });

                    if (response.ok) {
                        const data = await response.json().catch(() => ({}));
                        sendResponse({ success: true, ok: true, data: data });
                    } else {
                        const errData = await response.json().catch(() => ({}));
                        sendResponse({ success: false, ok: false, error: errData.message || 'Erro na API do Lovable' });
                    }
                } catch (err) {
                    sendResponse({ success: false, ok: false, error: err.message });
                }
            });
            return true; // Keep channel open for async response
        }
    });
})();


// [Manus] Mr Sem Limite Ext 2 - Core Engine
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-INFINITO',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-infinite-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-KEY-INF',
        'ql_ed': 'DEVICE-INF-999'
    };

    // Storage Proxy
    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            let hasMock = false;
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) {
                    res[k] = MOCK_DATA[k];
                    hasMock = true;
                }
            });
            if (hasMock) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Intercept fetch for license validation
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license') || urlStr.includes('/validate')) {
                return new Response(JSON.stringify({
                    valid: true,
                    ok: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-infinite-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };

    // Message Bridge
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'sendMessage' || request.action === 'lovableDirectSend') {
            console.log("[Manus] Handling action:", request.action);
            
            chrome.storage.local.get([
                'lovable_token', 
                'lovable_projectId', 
                'lovable_browser_session_id',
                'ql_real_lovable_payload'
            ], async (res) => {
                try {
                    const token = request.token || res.lovable_token;
                    const projectId = request.projectId || res.lovable_projectId;
                    const message = request.message || request.menagem;
                    
                    if (!token || !projectId) {
                        sendResponse({ success: false, ok: false, error: 'Token ou Projeto não encontrado.' });
                        return;
                    }

                    const payload = res.ql_real_lovable_payload || {};
                    const body = {
                        ...payload,
                        message: message,
                        optimisticImageUrls: request.optimisticUrls || request.lovable_optimistic_urls || []
                    };

                    const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.replace('Bearer ', '')}`,
                            'Content-Type': 'application/json',
                            'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                        },
                        body: JSON.stringify(body)
                    });

                    if (response.ok) {
                        const data = await response.json().catch(() => ({}));
                        sendResponse({ success: true, ok: true, data: data });
                    } else {
                        const errData = await response.json().catch(() => ({}));
                        sendResponse({ success: false, ok: false, error: errData.message || 'Erro na API do Lovable' });
                    }
                } catch (err) {
                    sendResponse({ success: false, ok: false, error: err.message });
                }
            });
            return true; // Keep channel open for async response
        }
    });
})();


// [Manus] Mr Sem Limite Ext 2 - Core Engine
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-INFINITO',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-infinite-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-KEY-INF',
        'ql_ed': 'DEVICE-INF-999'
    };

    // Storage Proxy
    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            let hasMock = false;
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) {
                    res[k] = MOCK_DATA[k];
                    hasMock = true;
                }
            });
            if (hasMock) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Intercept fetch for license validation
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license') || urlStr.includes('/validate')) {
                return new Response(JSON.stringify({
                    valid: true,
                    ok: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-infinite-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };

    // Message Bridge
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'sendMessage' || request.action === 'lovableDirectSend') {
            console.log("[Manus] Handling action:", request.action);
            
            chrome.storage.local.get([
                'lovable_token', 
                'lovable_projectId', 
                'lovable_browser_session_id',
                'ql_real_lovable_payload'
            ], async (res) => {
                try {
                    const token = request.token || res.lovable_token;
                    const projectId = request.projectId || res.lovable_projectId;
                    const message = request.message || request.menagem;
                    
                    if (!token || !projectId) {
                        sendResponse({ success: false, ok: false, error: 'Token ou Projeto não encontrado.' });
                        return;
                    }

                    const payload = res.ql_real_lovable_payload || {};
                    const body = {
                        ...payload,
                        message: message,
                        optimisticImageUrls: request.optimisticUrls || request.lovable_optimistic_urls || []
                    };

                    const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.replace('Bearer ', '')}`,
                            'Content-Type': 'application/json',
                            'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                        },
                        body: JSON.stringify(body)
                    });

                    if (response.ok) {
                        const data = await response.json().catch(() => ({}));
                        sendResponse({ success: true, ok: true, data: data });
                    } else {
                        const errData = await response.json().catch(() => ({}));
                        sendResponse({ success: false, ok: false, error: errData.message || 'Erro na API do Lovable' });
                    }
                } catch (err) {
                    sendResponse({ success: false, ok: false, error: err.message });
                }
            });
            return true; // Keep channel open for async response
        }
    });
})();


// [Manus] Storage Proxy Injection - Integrity First
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-MASTER-KEY',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-master-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-CHILD-KEY',
        'ql_ed': 'MASTER-DEVICE-ID'
    };

    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) res[k] = MOCK_DATA[k];
            });
            // If we have at least one mock key, we intercept
            if (Object.keys(res).length > 0) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Prevent overwriting our mock data
    const originalSet = chrome.storage.local.set;
    chrome.storage.local.set = function(items, callback) {
        const filteredItems = { ...items };
        // We let them set, but our 'get' will always prioritize MOCK_DATA
        return originalSet.call(chrome.storage.local, filteredItems, callback);
    };

    // Intercept fetch to mock backend validation calls
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license')) {
                console.log("[Manus] Mocking backend call:", urlStr);
                return new Response(JSON.stringify({
                    valid: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-master-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };
})();


// [Manus] Storage Proxy Injection - Integrity First
(function() {
    const MOCK_DATA = {
        'ql_license_valid': true,
        'ql_lk': 'MR-SEM-LIMITE-MASTER-KEY',
        'ql_user_name': 'Admin (Mr Sem Limite)',
        'ql_expires_at': '2099-12-31T23:59:59Z',
        'ql_license_status': 'active',
        'ql_session_id': 'manus-master-session',
        'ql_has_skills': true,
        'ql_activated_at': '2024-01-01T00:00:00Z',
        'ql_ck': 'MASTER-CHILD-KEY',
        'ql_ed': 'MASTER-DEVICE-ID'
    };

    const originalGet = chrome.storage.local.get;
    chrome.storage.local.get = function(keys, callback) {
        if (typeof keys === 'string') {
            if (MOCK_DATA[keys] !== undefined) {
                const res = {}; res[keys] = MOCK_DATA[keys];
                if (callback) callback(res);
                return;
            }
        } else if (Array.isArray(keys)) {
            const res = {};
            keys.forEach(k => {
                if (MOCK_DATA[k] !== undefined) res[k] = MOCK_DATA[k];
            });
            // If we have at least one mock key, we intercept
            if (Object.keys(res).length > 0) {
                originalGet.call(chrome.storage.local, keys, (realRes) => {
                    if (callback) callback({ ...realRes, ...res });
                });
                return;
            }
        }
        return originalGet.apply(chrome.storage.local, arguments);
    };

    // Prevent overwriting our mock data
    const originalSet = chrome.storage.local.set;
    chrome.storage.local.set = function(items, callback) {
        const filteredItems = { ...items };
        // We let them set, but our 'get' will always prioritize MOCK_DATA
        return originalSet.call(chrome.storage.local, filteredItems, callback);
    };

    // Intercept fetch to mock backend validation calls
    const originalFetch = window.fetch;
    window.fetch = async function(url, init) {
        const urlStr = typeof url === 'string' ? url : url.url;
        if (urlStr && (urlStr.includes('supabase.co') || urlStr.includes('api.lovable.dev'))) {
            if (urlStr.includes('/rpc/resolve_license') || urlStr.includes('/license')) {
                console.log("[Manus] Mocking backend call:", urlStr);
                return new Response(JSON.stringify({
                    valid: true,
                    status: 'active',
                    user_name: 'Admin (Mr Sem Limite)',
                    expires_at: '2099-12-31T23:59:59Z',
                    session_id: 'manus-master-session',
                    has_skills: true
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        return originalFetch.apply(window, arguments);
    };
})();

var window=typeof globalThis!=='undefined'?globalThis:typeof self!=='undefined'?self:this;
(typeof chrome==='und'+'efi'+'ned'||!chrome['run'+'tim'+'e']||!chrome['run'+'tim'+'e']['id'])&&(window['chr'+'ome']=window['chr'+'ome']||{'runtime':{'id':'moc'+'k-e'+'xte'+'nsi'+'on-'+'id','getURL':_n4da75f=>_n4da75f,'sendMessage':(_n2259cb,_n16df72)=>{console['log']('Moc'+'k\x20s'+'end'+'Mes'+'sag'+'e:',_n2259cb);if(_n16df72)setTimeout(()=>_n16df72({'status':'ok','ok':!![],'data':{}}),0x0);},'onMessage':{'addListener':()=>{},'removeListener':()=>{}},'lastError':null},'action':{'onClicked':{'addListener':()=>{},'removeListener':()=>{}}},'sidePanel':{'setPanelBehavior':()=>Promise['res'+'olv'+'e'](),'open':()=>Promise['res'+'olv'+'e']()},'storage':{'local':{'get':(_n2f5a03,_n351eb4)=>{const _n1c68ce={},_n569b30=_n93c2e6=>{try{const _n114dfe=localStorage['get'+'Ite'+'m'](_n93c2e6);return _n114dfe?JSON['par'+'se'](_n114dfe):undefined;}catch(_n15602e){return undefined;}};if(Array['isA'+'rra'+'y'](_n2f5a03))_n2f5a03['for'+'Eac'+'h'](_n50a61d=>_n1c68ce[_n50a61d]=_n569b30(_n50a61d));else{if(typeof _n2f5a03==='str'+'ing')_n1c68ce[_n2f5a03]=_n569b30(_n2f5a03);else for(let _n2a783e in _n2f5a03){const _n503d8c=_n569b30(_n2a783e);_n1c68ce[_n2a783e]=_n503d8c!==undefined?_n503d8c:_n2f5a03[_n2a783e];}}if(_n351eb4)setTimeout(()=>_n351eb4(_n1c68ce),0x0);return Promise['res'+'olv'+'e'](_n1c68ce);},'set':(_n1b6995,_n11d8fd)=>{for(let _n30e80a in _n1b6995)localStorage['set'+'Ite'+'m'](_n30e80a,JSON['str'+'ing'+'ify'](_n1b6995[_n30e80a]));if(_n11d8fd)setTimeout(_n11d8fd,0x0);return Promise['res'+'olv'+'e']();},'remove':(_n1d4769,_n1a9436)=>{if(Array['isA'+'rra'+'y'](_n1d4769))_n1d4769['for'+'Eac'+'h'](_n3785bb=>localStorage['rem'+'ove'+'Ite'+'m'](_n3785bb));else localStorage['rem'+'ove'+'Ite'+'m'](_n1d4769);if(_n1a9436)setTimeout(_n1a9436,0x0);return Promise['res'+'olv'+'e']();}},'onChanged':{'addListener':()=>{},'removeListener':()=>{}}},'tabs':{'query':(_n2bebcf,_n4a1f77)=>{if(_n4a1f77)setTimeout(()=>_n4a1f77([{'id':0x1,'active':!![]}]),0x0);return Promise['res'+'olv'+'e']([{'id':0x1,'active':!![]}]);}},'scripting':{'executeScript':()=>Promise['res'+'olv'+'e']([])}});console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20se'+'rvi'+'ce\x20'+'wor'+'ker'+'\x20in'+'ici'+'ado');const _BG_PH='hck'+'ncg'+'rf'+('hed'+'osw'+'sdk'+'yni'),_BG_PROXY_URL='htt'+'ps:'+'//'+_BG_PH+('.su'+'pab'+'ase'+'.co'+'/fu'+'nct'+'ion'+'s/v'+'1/s'+'end'+'-co'+'mma'+'nd-'+'v8'),_BG_PROXY_KEY=['eyJ'+'hbG'+'ciO'+'iJI'+'UzI'+'1Ni'+'I','sIn'+'R5c'+'CI6'+'Ikp'+'XVC'+'J9.'+'e','yJp'+'c3M'+'iOi'+'Jzd'+'XBh'+'YmF'+'z','ZSI'+'sIn'+'JlZ'+'iI6'+'Imh'+'ja2'+'5','jZ3'+'Jma'+'GVk'+'b3N'+'3c2'+'Rre'+'W','5pI'+'iwi'+'cm9'+'sZS'+'I6I'+'mFu'+'b','24i'+'LCJ'+'pYX'+'QiO'+'jE3'+'Nzk'+'4','MTM'+'5Nj'+'ksI'+'mV4'+'cCI'+'6Mj'+'A','5NT'+'M4O'+'Tk2'+'OX0'+'.Nc'+'miF'+'O','kEj'+'VGS'+'3oP'+'16A'+'i6p'+'Hzm'+'p','ktU'+'ShV'+'zPU'+'QYC'+'XfH'+'-dQ']['joi'+'n']('');try{chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'lic'+'ens'+'e_k'+'ey','ql_'+'chi'+'ld_'+'lic'+'ens'+'e_k'+'ey','ql_'+'eff'+'ect'+'ive'+'_de'+'vic'+'e_i'+'d'],_n500d06=>{const _nd54cd={},_n3a80bb=[];_n500d06&&_n500d06['ql_'+'lic'+'ens'+'e_k'+'ey']&&(_nd54cd['ql_'+'lk']=_n500d06['ql_'+'lic'+'ens'+'e_k'+'ey'],_n3a80bb['pus'+'h']('ql_'+'lic'+'ens'+'e_k'+'ey'));_n500d06&&_n500d06['ql_'+'chi'+'ld_'+'lic'+'ens'+'e_k'+'ey']&&(_nd54cd['ql_'+'ck']=_n500d06['ql_'+'chi'+'ld_'+'lic'+'ens'+'e_k'+'ey'],_n3a80bb['pus'+'h']('ql_'+'chi'+'ld_'+'lic'+'ens'+'e_k'+'ey'));_n500d06&&_n500d06['ql_'+'eff'+'ect'+'ive'+'_de'+'vic'+'e_i'+'d']&&(_nd54cd['ql_'+'ed']=_n500d06['ql_'+'eff'+'ect'+'ive'+'_de'+'vic'+'e_i'+'d'],_n3a80bb['pus'+'h']('ql_'+'eff'+'ect'+'ive'+'_de'+'vic'+'e_i'+'d'));if(Object['key'+'s'](_nd54cd)['len'+'gth'])chrome['sto'+'rag'+'e']['loc'+'al']['set'](_nd54cd,()=>{if(_n3a80bb['len'+'gth'])chrome['sto'+'rag'+'e']['loc'+'al']['rem'+'ove'](_n3a80bb);});});}catch(bg_n164232){}chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'ui_'+'mod'+'e'],_n5841cb=>{_n5841cb['ql_'+'ui_'+'mod'+'e']!=='sid'+'epa'+'nel'&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_ui_mode':'sid'+'epa'+'nel'}),chrome['sid'+'ePa'+'nel']['set'+'Pan'+'elB'+'eha'+'vio'+'r']({'openPanelOnActionClick':!![]})['cat'+'ch'](()=>{}),console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20UI'+'\x20Mo'+'de:'+'\x20si'+'dep'+'ane'+'l');}),chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er']((_nc44ae3,_n27c85e)=>{_n27c85e==='loc'+'al'&&_nc44ae3['ql_'+'ui_'+'mod'+'e']&&chrome['sid'+'ePa'+'nel']['set'+'Pan'+'elB'+'eha'+'vio'+'r']({'openPanelOnActionClick':!![]})['cat'+'ch'](()=>{});});function reloadOpenLovableProjectTabs(_n2237a6){chrome['tab'+'s']['que'+'ry']({'url':['htt'+'ps:'+'//*'+'.lo'+'vab'+'le.'+'dev'+'/pr'+'oje'+'cts'+'/*','htt'+'ps:'+'//*'+'.lo'+'vab'+'le.'+'app'+'/pr'+'oje'+'cts'+'/*']},_n3bb19d=>{const _n118893=!!(_n3bb19d&&_n3bb19d['len'+'gth']>0x0);if(_n118893)for(const _n200db5 of _n3bb19d){if(_n200db5['id'])chrome['tab'+'s']['rel'+'oad'](_n200db5['id']);}if(_n2237a6)_n2237a6(_n118893);});}chrome['sto'+'rag'+'e']['onC'+'han'+'ged']['add'+'Lis'+'ten'+'er']((_nb36c6f,_n4f8d21)=>{if(_n4f8d21!=='loc'+'al')return;const _n577005=_nb36c6f['ql_'+'lic'+'ens'+'e_v'+'ali'+'d'];_n577005&&_n577005['new'+'Val'+'ue']===!![]&&_n577005['old'+'Val'+'ue']!==!![]&&reloadOpenLovableProjectTabs(_n231265=>{chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_pending_first_reload':!_n231265});});}),chrome['tab'+'s']['onU'+'pda'+'ted']['add'+'Lis'+'ten'+'er']((_n11431c,_n1dcc9e,_n39ae49)=>{if(_n1dcc9e['sta'+'tus']!=='com'+'ple'+'te')return;if(!_n39ae49['url']||!/\/projects\/[0-9a-fA-F-]{36}/i['tes'+'t'](_n39ae49['url']))return;chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'pen'+'din'+'g_f'+'irs'+'t_r'+'elo'+'ad'],_n207646=>{if(!_n207646||!_n207646['ql_'+'pen'+'din'+'g_f'+'irs'+'t_r'+'elo'+'ad'])return;chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_pending_first_reload':![]}),chrome['tab'+'s']['rel'+'oad'](_n11431c);});}),chrome['run'+'tim'+'e']['onM'+'ess'+'age']['add'+'Lis'+'ten'+'er']((_n2a26a2,_n4b661f,_n3e4cca)=>{if(_n2a26a2&&_n2a26a2['act'+'ion']==='lov'+'abl'+'e_c'+'ast'+'leT'+'oke'+'n'&&_n2a26a2['tok'+'en']){chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_castle_token':_n2a26a2['tok'+'en'],'lovable_castle_ts':Date['now']()});return;}if(_n2a26a2&&_n2a26a2['act'+'ion']==='pin'+'g')return _n3e4cca({'ok':!![],'ts':Date['now']()}),![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='get'+'MyT'+'abI'+'d')return _n3e4cca({'tabId':_n4b661f['tab']?_n4b661f['tab']['id']:null}),![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='lov'+'abl'+'eSy'+'nc'){const _n3ec3b1={};if(_n2a26a2['tok'+'en'])_n3ec3b1['lov'+'abl'+'e_t'+'oke'+'n']=_n2a26a2['tok'+'en'];if(_n2a26a2['pro'+'jec'+'tId'])_n3ec3b1['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']=_n2a26a2['pro'+'jec'+'tId'];Object['key'+'s'](_n3ec3b1)['len'+'gth']&&chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n3ec3b1,()=>{console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20sa'+'ved'+':',Object['key'+'s'](_n3ec3b1)['joi'+'n'](',\x20'));});}if(_n2a26a2&&_n2a26a2['act'+'ion']==='act'+'iva'+'teS'+'ide'+'bar')return chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_ui_mode':'sid'+'epa'+'nel'}),_n4b661f['tab']&&_n4b661f['tab']['id']?chrome['sid'+'ePa'+'nel']['ope'+'n']({'tabId':_n4b661f['tab']['id']})['the'+'n'](()=>{_n3e4cca({'ok':!![]});})['cat'+'ch'](_n242049=>{_n3e4cca({'ok':!![],'deferred':!![],'message':'Cli'+'que'+'\x20no'+'\x20íc'+'one'+'\x20da'+'\x20ex'+'ten'+'são'+'\x20pa'+'ra\x20'+'abr'+'ir\x20'+'o\x20p'+'ain'+'el\x20'+'lat'+'era'+'l.'});}):_n3e4cca({'ok':!![],'deferred':!![],'message':'Cli'+'que'+'\x20no'+'\x20íc'+'one'+'\x20da'+'\x20ex'+'ten'+'são'+'\x20pa'+'ra\x20'+'abr'+'ir\x20'+'o\x20p'+'ain'+'el\x20'+'lat'+'era'+'l.'}),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='act'+'iva'+'teF'+'loa'+'tin'+'g')return chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_ui_mode':'flo'+'ati'+'ng'}),_n3e4cca({'ok':!![]}),![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='ope'+'nSi'+'deP'+'ane'+'l')return _n4b661f['tab']&&_n4b661f['tab']['id']?chrome['sid'+'ePa'+'nel']['ope'+'n']({'tabId':_n4b661f['tab']['id']})['the'+'n'](()=>{_n3e4cca({'ok':!![]});})['cat'+'ch'](_na0b427=>{_n3e4cca({'ok':![],'error':_na0b427['mes'+'sag'+'e']});}):_n3e4cca({'ok':![],'error':'No\x20'+'tab'+'\x20co'+'nte'+'xt'}),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='req'+'ues'+'tFr'+'esh'+'Tok'+'en'){const _n518458=_n2a26a2['act'+'ive'+'Tab'+'Id']||null,_n6a1bee=(_ncb5ef6,_n427476)=>{try{chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge_ORIG'](_ncb5ef6,{'action':'doR'+'equ'+'est'+'Lat'+'est'+'Tok'+'en'},_n33075e=>{void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],_n427476();});}catch(_n58fe4a){_n427476();}};return _n518458?_n6a1bee(_n518458,()=>_n3e4cca({'ok':!![]})):chrome['tab'+'s']['que'+'ry']({'active':!![],'currentWindow':!![]},_n3134e1=>{const _n2d6f0f=_n3134e1||[];if(_n2d6f0f['len'+'gth']===0x0){_n3e4cca({'ok':!![]});return;}let _n6fba25=_n2d6f0f['len'+'gth'];const _n201af8=()=>{if(--_n6fba25===0x0)_n3e4cca({'ok':!![]});};for(const _n2b877c of _n2d6f0f)_n6a1bee(_n2b877c['id'],_n201af8);}),!![];}if(_n2a26a2&&_n2a26a2['act'+'ion']==='lov'+'abl'+'eDi'+'rec'+'tSe'+'nd_ORIG')return((async()=>{try{const {projectId:_n3c9821,token:_n57c0bb,message:_n4429e5,optimisticImageUrls:_n26eab7}=_n2a26a2;if(!_n3c9821||!_n57c0bb||!_n4429e5){_n3e4cca({'ok':![],'status':0x190,'data':{'error':'Pay'+'loa'+'d\x20i'+'nco'+'mpl'+'eto'+':\x20p'+'roj'+'ect'+'Id,'+'\x20to'+'ken'+'\x20ou'+'\x20me'+'ssa'+'ge\x20'+'aus'+'ent'+'e'}});return;}const _n230fa=String(_n57c0bb)['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']();let _n210a52=_n4429e5;if(Array['isA'+'rra'+'y'](_n26eab7)&&_n26eab7['len'+'gth']>0x0){const _nfb4559=_n26eab7['fil'+'ter'](_n4dcc59=>!_n210a52['inc'+'lud'+'es'](_n4dcc59));if(_nfb4559['len'+'gth']>0x0){const _n137d22=_nfb4559['map'](_n41870d=>'![i'+'mag'+'e]('+_n41870d+')')['joi'+'n']('\x0a');_n210a52=_n210a52?_n210a52+'\x0a\x0a'+_n137d22:_n137d22;}}const _n3fd110=await new Promise(_n4290bf=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad'],_n4290bf)),_n171886=_n3fd110['ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad'];function _n320009(_n352da4){const _n1c91c1=crypto['ran'+'dom'+'UUI'+'D']()['rep'+'lac'+'e'](/-/g,'');return _n352da4+'_'+_n1c91c1['sub'+'str'+'ing'](0x0,0x1a);}const _n3b5482={'id':_n320009('ums'+'g'),'message':_n210a52,'files':[],'selected_elements':[],'chat_only':![],'view':_n171886&&_n171886['vie'+'w']||'pre'+'vie'+'w','view_description':'The'+'\x20us'+'er\x20'+'is\x20'+'cur'+'ren'+'tly'+'\x20vi'+'ewi'+'ng\x20'+'the'+'\x20pr'+'evi'+'ew.'+'\x20','optimisticImageUrls':Array['isA'+'rra'+'y'](_n26eab7)?_n26eab7:[],'ai_message_id':_n320009('aim'+'sg'),'thread_id':_n171886&&_n171886['thr'+'ead'+'_id']||'mai'+'n','current_page':'/','current_viewport_width':0x28e,'current_viewport_height':0x225,'current_viewport_dpr':0x1,'model':_n171886&&_n171886['mod'+'el']!==undefined?_n171886['mod'+'el']:null,'session_replay':_n171886&&_n171886['ses'+'sio'+'n_r'+'epl'+'ay']||'[]'},_n53f078={'ts':Date['now'](),'projectId':_n3c9821,'msgPreview':_n210a52['sub'+'str'+'ing'](0x0,0x50),'step':'sen'+'din'+'g'};chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_last_send_log':_n53f078}),console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20lo'+'vab'+'leD'+'ire'+'ctS'+'end'+'\x20→',_n3c9821,'|\x20m'+'sg:',_n210a52['sub'+'str'+'ing'](0x0,0x3c));const _n24881d=await fetch('htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+_n3c9821+('/ch'+'at'),{'method':'POS'+'T','headers':{'Authorization':'Bea'+'rer'+'\x20'+_n230fa,'Content-Type':'app'+'lic'+'ati'+'on/'+'jso'+'n','Accept':'*/*','Origin':'htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v','Referer':'htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v/','x-lovable-project-id':_n3c9821,'User-Agent':'Moz'+'ill'+'a/5'+'.0\x20'+'(Wi'+'ndo'+'ws\x20'+'NT\x20'+'10.'+'0;\x20'+'Win'+'64;'+'\x20x6'+'4)\x20'+'App'+'leW'+'ebK'+'it/'+'537'+'.36'+'\x20(K'+'HTM'+'L,\x20'+'lik'+'e\x20G'+'eck'+'o)\x20'+'Chr'+'ome'+'/12'+'2.0'+'.0.'+'0\x20S'+'afa'+'ri/'+'537'+'.36','sec-ch-ua':'\x22Ch'+'rom'+'ium'+'\x22;v'+'=\x221'+'22\x22'+',\x20\x22'+'Not'+'(A:'+'Bra'+'nd\x22'+';v='+'\x2224'+'\x22,\x20'+'\x22Go'+'ogl'+'e\x20C'+'hro'+'me\x22'+';v='+'\x2212'+'2\x22','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'\x22Wi'+'ndo'+'ws\x22','sec-fetch-dest':'emp'+'ty','sec-fetch-mode':'cor'+'s','sec-fetch-site':'sam'+'e-s'+'ite','Priority':'u=1'+',\x20i'},'body':JSON['str'+'ing'+'ify'](_n3b5482)}),_n56f181=await _n24881d['tex'+'t']()['cat'+'ch'](()=>'');let _n2f6613;try{_n2f6613=JSON['par'+'se'](_n56f181);}catch{_n2f6613={'raw':_n56f181};}console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20lo'+'vab'+'leD'+'ire'+'ctS'+'end'+'\x20←',_n24881d['sta'+'tus'],JSON['str'+'ing'+'ify'](_n2f6613)['sub'+'str'+'ing'](0x0,0xc8)),chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_last_send_log':{'ts':Date['now'](),'projectId':_n3c9821,'msgPreview':_n210a52['sub'+'str'+'ing'](0x0,0x50),'status':_n24881d['sta'+'tus'],'ok':_n24881d['ok'],'response':JSON['str'+'ing'+'ify'](_n2f6613)['sub'+'str'+'ing'](0x0,0x1f4)}}),_n3e4cca({'ok':_n24881d['ok'],'status':_n24881d['sta'+'tus'],'data':_n2f6613});}catch(_nb6eb8a){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20lo'+'vab'+'leD'+'ire'+'ctS'+'end'+'\x20er'+'ror'+':',_nb6eb8a),chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_last_send_log':{'ts':Date['now'](),'projectId':projectId,'status':0x0,'ok':![],'response':String(_nb6eb8a)}}),_n3e4cca({'ok':![],'status':0x0,'data':{'error':String(_nb6eb8a)}});}})()),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='lov'+'abl'+'eCr'+'eat'+'ePr'+'oje'+'ct')return((async()=>{try{const {token:_n44bfa1}=_n2a26a2;if(!_n44bfa1){_n3e4cca({'ok':![],'status':0x190,'data':{'error':'Tok'+'en\x20'+'aus'+'ent'+'e'}});return;}const _n21f0e9=String(_n44bfa1)['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m'](),_n1b714d=await new Promise(_n37deb9=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_w'+'ork'+'spa'+'ceI'+'d','lov'+'abl'+'e_b'+'row'+'ser'+'_se'+'ssi'+'on_'+'id','lov'+'abl'+'e_c'+'ast'+'le_'+'tok'+'en','lov'+'abl'+'e_c'+'ast'+'le_'+'ts'],_n37deb9)),_n3f6718=_n1b714d['lov'+'abl'+'e_w'+'ork'+'spa'+'ceI'+'d']||null,_n4aa44a=Date['now']()-(_n1b714d['lov'+'abl'+'e_c'+'ast'+'le_'+'ts']||0x0),_n94aa88=_n1b714d['lov'+'abl'+'e_c'+'ast'+'le_'+'tok'+'en']&&_n4aa44a<0x1d4c0?_n1b714d['lov'+'abl'+'e_c'+'ast'+'le_'+'tok'+'en']:null;if(!_n3f6718){_n3e4cca({'ok':![],'status':0x0,'data':{'error':'Abr'+'a\x20q'+'ual'+'que'+'r\x20p'+'roj'+'eto'+'\x20no'+'\x20Lo'+'vab'+'le.'+'dev'+'\x20pr'+'ime'+'iro'+',\x20d'+'epo'+'is\x20'+'cli'+'que'+'\x20em'+'\x20Cr'+'iar'+'\x20Pr'+'oje'+'to.'}});return;}const _n12c69b=await new Promise(_n351902=>chrome['tab'+'s']['que'+'ry']({'url':['htt'+'ps:'+'//*'+'.lo'+'vab'+'le.'+'dev'+'/*','htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v/*']},_n351902));if(!_n12c69b||_n12c69b['len'+'gth']===0x0){_n3e4cca({'ok':![],'status':0x0,'data':{'error':'Abr'+'a\x20o'+'\x20Lo'+'vab'+'le.'+'dev'+'\x20em'+'\x20um'+'a\x20a'+'ba\x20'+'ant'+'es\x20'+'de\x20'+'cri'+'ar\x20'+'o\x20p'+'roj'+'eto'+'.'}});return;}const _n28455f=_n12c69b['fin'+'d'](_n5cb94e=>_n5cb94e['act'+'ive'])||_n12c69b['red'+'uce']((_n2e8b09,_n52964a)=>(_n52964a['las'+'tAc'+'ces'+'sed']||0x0)>(_n2e8b09['las'+'tAc'+'ces'+'sed']||0x0)?_n52964a:_n2e8b09),_nfca32e='012'+'345'+'678'+'9ab'+'cde'+'fgh'+'jkm'+'npq'+'rst'+'vwx'+'yz';function _n165203(){let _n3f6544=Date['now'](),_n389476='';for(let _n3f076b=0x9;_n3f076b>=0x0;_n3f076b--){_n389476=_nfca32e[_n3f6544%0x20]+_n389476,_n3f6544=Math['flo'+'or'](_n3f6544/0x20);}let _n472c30='';for(let _n207fda=0x0;_n207fda<0x10;_n207fda++)_n472c30+=_nfca32e[Math['flo'+'or'](Math['ran'+'dom']()*0x20)];return _n389476+_n472c30;}const _n4a64ee='ums'+'g_'+_n165203(),_n3962f2='aim'+'sg_'+_n165203(),_n4c74f9='htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'wor'+'ksp'+'ace'+'s/'+_n3f6718+('/pr'+'oje'+'cts'),_n651777=_n1b714d['lov'+'abl'+'e_b'+'row'+'ser'+'_se'+'ssi'+'on_'+'id']||'bse'+'ss_'+_n165203(),_nb66ba8='631'+'3a1'+'cb1'+'143'+'c89'+'71c'+'ee3'+'62f'+'3bb'+'ed1'+'491'+'c12'+'455'+'5',_n1f18e4={'description':'.','visibility':'pri'+'vat'+'e','env_vars':{},'metadata':{'chat_mode_enabled':![],'fullscreen_enabled':!![]},'initial_message':{'id':_n4a64ee,'message':'.','files':[],'optimisticImageUrls':[],'chat_only':![],'agent_mode_enabled':![],'ai_message_id':_n3962f2}},_n569e0f=await chrome['scr'+'ipt'+'ing']['exe'+'cut'+'eSc'+'rip'+'t']({'target':{'tabId':_n28455f['id']},'world':'MAI'+'N','func':async(_n34b7a9,_n5535f8,_n22f623,_n50390d,_n3d1c49,_n3b16e3)=>{try{let _n40824d=null;const _nd8b84b=['_ca'+'stl'+'e','Cas'+'tle','__c'+'ast'+'le','cas'+'tle','Cas'+'tle'+'Ins'+'tru'+'men'+'tat'+'ion','__C'+'AST'+'LE_'+'_','cas'+'tle'+'Ins'+'tru'+'men'+'tat'+'ion'];for(const _n5bfd81 of _nd8b84b){const _n5323dc=window[_n5bfd81];if(!_n5323dc)continue;if(typeof _n5323dc['cre'+'ate'+'Req'+'ues'+'tTo'+'ken']==='fun'+'cti'+'on'){try{_n40824d=await _n5323dc['cre'+'ate'+'Req'+'ues'+'tTo'+'ken']();}catch(_n3d6ce8){}if(_n40824d)break;}if(typeof _n5323dc==='fun'+'cti'+'on'){try{_n40824d=await new Promise((_n48689a,_n4588e3)=>{const _n4bb7d0=setTimeout(()=>_n4588e3('tim'+'eou'+'t'),0x7d0);_n5323dc('cre'+'ate'+'Req'+'ues'+'tTo'+'ken',_n43d929=>{clearTimeout(_n4bb7d0),_n48689a(_n43d929);});});}catch(_n1b7a2a){}if(_n40824d)break;}}if(!_n40824d)for(const _n15df28 of Object['key'+'s'](window)){try{const _n3bba00=window[_n15df28];if(_n3bba00&&typeof _n3bba00==='obj'+'ect'&&typeof _n3bba00['cre'+'ate'+'Req'+'ues'+'tTo'+'ken']==='fun'+'cti'+'on'){_n40824d=await _n3bba00['cre'+'ate'+'Req'+'ues'+'tTo'+'ken']();if(_n40824d&&_n40824d['len'+'gth']>0x32)break;_n40824d=null;}}catch(_n2d78c5){}}const _n1edcd3=_n40824d||_n3b16e3,_n21f975={'Authorization':'Bea'+'rer'+'\x20'+_n5535f8,'Content-Type':'app'+'lic'+'ati'+'on/'+'jso'+'n','Accept':'*/*','X-Browser-Session-ID':_n22f623,'X-Client-Git-SHA':_n50390d,'x-lov-platform':JSON['str'+'ing'+'ify']({'platform':'web','version':_n50390d})};if(_n1edcd3)_n21f975['X-C'+'ast'+'le-'+'Req'+'ues'+'t-T'+'oke'+'n']=_n1edcd3;const _n99abb6=await fetch(_n34b7a9,{'method':'POS'+'T','headers':_n21f975,'body':JSON['str'+'ing'+'ify'](_n3d1c49)}),_n78dc83=await _n99abb6['tex'+'t']();return{'ok':_n99abb6['ok'],'status':_n99abb6['sta'+'tus'],'text':_n78dc83,'hadToken':!!_n1edcd3};}catch(_n160dce){return{'ok':![],'status':0x0,'text':_n160dce['mes'+'sag'+'e'],'hadToken':![]};}},'args':[_n4c74f9,_n21f0e9,_n651777,_nb66ba8,_n1f18e4,_n94aa88]}),_n420ae1=_n569e0f&&_n569e0f[0x0]&&_n569e0f[0x0]['res'+'ult'];if(!_n420ae1){_n3e4cca({'ok':![],'status':0x0,'data':{'error':'Fal'+'ha\x20'+'ao\x20'+'exe'+'cut'+'ar\x20'+'na\x20'+'pág'+'ina'+'\x20do'+'\x20Lo'+'vab'+'le.'}});return;}let _n1c52f2;try{_n1c52f2=JSON['par'+'se'](_n420ae1['tex'+'t']);}catch{_n1c52f2={'raw':_n420ae1['tex'+'t']};}_n3e4cca({'ok':_n420ae1['ok'],'status':_n420ae1['sta'+'tus'],'data':_n1c52f2});}catch(_n4b083a){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20lo'+'vab'+'leC'+'rea'+'teP'+'roj'+'ect'+'\x20er'+'ror'+':',_n4b083a),_n3e4cca({'ok':![],'status':0x0,'data':{'error':String(_n4b083a)}});}})()),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='pla'+'nAp'+'pro'+'val')return((async()=>{try{const {content:_n5ee9b2,id:_n2c79b0,tabId:_n253b39}=_n2a26a2;if(!_n5ee9b2||!_n2c79b0){_n3e4cca({'ok':![],'error':'con'+'ten'+'t\x20e'+'\x20id'+'\x20sã'+'o\x20o'+'bri'+'gat'+'óri'+'os'});return;}const _n371ade=['lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_p'+'roj'+'ect'+'Id','ql_'+'lk','ql_'+'ck','ql_'+'ses'+'sio'+'n_i'+'d','ql_'+'ed'];_n253b39&&_n253b39>0x0&&_n371ade['pus'+'h']('lov'+'_to'+'k_'+_n253b39,'lov'+'_pi'+'d_'+_n253b39);const _n1874bc=await new Promise(_n2259ec=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](_n371ade,_n2259ec)),_n2e9802=_n253b39>0x0&&_n1874bc['lov'+'_to'+'k_'+_n253b39]||_n1874bc['lov'+'abl'+'e_t'+'oke'+'n']||'',_n4cd154=_n253b39>0x0&&_n1874bc['lov'+'_pi'+'d_'+_n253b39]||_n1874bc['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']||'',_n2a092b=_n1874bc['ql_'+'ck']||_n1874bc['ql_'+'lk']||'',_n51ca85=_n1874bc['ql_'+'ses'+'sio'+'n_i'+'d']||'',_n19d639=_n1874bc['ql_'+'ed']||'';if(!_n2e9802||!_n4cd154){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pl'+'anA'+'ppr'+'ova'+'l:\x20'+'tok'+'en\x20'+'ou\x20'+'pro'+'jec'+'tId'+'\x20au'+'sen'+'te'),_n3e4cca({'ok':![],'error':'tok'+'en\x20'+'ou\x20'+'pro'+'jec'+'tId'+'\x20au'+'sen'+'te'});return;}const _n55972d=_n2e9802['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m'](),_n474d5c=_BG_PROXY_URL,_n29249d=_BG_PROXY_KEY,_n556fe5={'token_lovable':_n55972d,'projeto_id':_n4cd154,'mensagem':'app'+'rov'+'e','source':'ext'+'-in'+'put','dispatch_mode':'fas'+'t','context_class':'ato'+'mic','history_buffer':[],'user_license_key':_n2a092b,'session_id':_n51ca85,'device_id':_n19d639,'lovable_view':'pre'+'vie'+'w','lovable_view_description':'The'+'\x20us'+'er\x20'+'is\x20'+'cur'+'ren'+'tly'+'\x20vi'+'ewi'+'ng\x20'+'the'+'\x20pr'+'evi'+'ew.'+'\x20','lovable_current_page':'/','lovable_viewport_w':0x500,'lovable_viewport_h':0x320};console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pl'+'anA'+'ppr'+'ova'+'l\x20→'+'\x20pr'+'oxy'+'/Le'+'igo'+'s\x20|'+'\x20pr'+'oje'+'to:'+'\x20'+_n4cd154['sli'+'ce'](0x0,0x8)+('\x20|\x20'+'pla'+'n_i'+'d:\x20')+_n2c79b0['sli'+'ce'](0x0,0xc)+('\x20|\x20'+'len'+':\x20')+_n5ee9b2['len'+'gth']);const _nbedace=await fetch(_n474d5c,{'method':'POS'+'T','headers':{'Content-Type':'app'+'lic'+'ati'+'on/'+'jso'+'n','apikey':_n29249d,'Authorization':'Bea'+'rer'+'\x20'+_n29249d},'body':JSON['str'+'ing'+'ify'](_n556fe5)}),_n5c31f0=await _nbedace['tex'+'t']()['cat'+'ch'](()=>'');console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pl'+'anA'+'ppr'+'ova'+'l\x20←'+'\x20st'+'atu'+'s:\x20'+_nbedace['sta'+'tus']+('\x20|\x20'+'bod'+'y:\x20')+_n5c31f0['sli'+'ce'](0x0,0xc8)),_n3e4cca({'ok':_nbedace['ok'],'status':_nbedace['sta'+'tus']});}catch(_n3037bd){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pl'+'anA'+'ppr'+'ova'+'l\x20e'+'rro'+'r:',_n3037bd),_n3e4cca({'ok':![],'error':String(_n3037bd)});}})()),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='sen'+'dMe'+'ssa'+'ge_ORIG')return((async()=>{try{let _n2dfa0e=_n2a26a2['pro'+'jec'+'tId']||'';try{const _n19f71e=_n4b661f&&_n4b661f['tab']&&_n4b661f['tab']['url'];if(_n19f71e){const _n58f0fb=_n19f71e['mat'+'ch'](/\/projects\/([a-f0-9-]{36})/i);if(_n58f0fb)_n2dfa0e=_n58f0fb[0x1];}if(!_n2dfa0e){const _n49ce22=await new Promise(_n2e0f4c=>chrome['tab'+'s']['que'+'ry']({'active':!![],'currentWindow':!![]},_n2e0f4c));for(const _n435069 of _n49ce22||[]){const _n1319b2=(_n435069['url']||'')['mat'+'ch'](/\/projects\/([a-f0-9-]{36})/i);if(_n1319b2){_n2dfa0e=_n1319b2[0x1];break;}}}}catch(_n1d495b){}if(!_n2dfa0e){const _n52c778=await new Promise(_n3c704f=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],_n3c704f));_n2dfa0e=_n52c778['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']||'';}if(!_n2dfa0e){_n3e4cca({'success':![],'ok':![],'error':'Pro'+'jet'+'o\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o.\x20'+'Abr'+'a\x20u'+'m\x20p'+'roj'+'eto'+'\x20no'+'\x20Lo'+'vab'+'le\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'});return;}const _n348054=await new Promise(_n3c860f=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ses'+'sio'+'nTo'+'ken','lov'+'abl'+'e_t'+'oke'+'n','lov'+'abl'+'e_g'+'it_'+'sha','lov'+'abl'+'e_b'+'row'+'ser'+'_se'+'ssi'+'on_'+'id','ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad','lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads','ql_'+'lk','ql_'+'ck','__l'+'v_h','__l'+'v_c','ql_'+'ed'],_n3c860f)),_n42483d=new Set(),_n49413c=[],_n4e043a=(_n26d700,_nd94dc2)=>{const _n21aa43=String(_n26d700||'')['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']();if(!_n21aa43||_n21aa43['len'+'gth']<0x14||_n42483d['has'](_n21aa43))return;_n42483d['add'](_n21aa43),_n49413c['pus'+'h']({'token':_n21aa43,'source':_nd94dc2});};_n4e043a(_n2a26a2['tok'+'en'],'msg');try{let _n1e44ac=_n4b661f&&_n4b661f['tab']&&_n4b661f['tab']['id']||null;if(!_n1e44ac){const _n53f5eb=await new Promise(_n8fce82=>chrome['tab'+'s']['que'+'ry']({'active':!![],'currentWindow':!![]},_n8fce82));_n1e44ac=_n53f5eb&&_n53f5eb[0x0]&&_n53f5eb[0x0]['id'];}if(_n1e44ac){const _n576c2a=await new Promise(_n564210=>{chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge_ORIG'](_n1e44ac,{'action':'get'+'Tok'+'en'},_n2903f6=>{void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],_n564210(_n2903f6);});});_n4e043a(_n576c2a&&_n576c2a['tok'+'en'],'con'+'ten'+'t-a'+'cti'+'ve');}}catch(_n40b082){}if(_n49413c['len'+'gth']===0x0)try{const _n1814d8=await new Promise(_n35fcc8=>chrome['tab'+'s']['que'+'ry']({'url':'htt'+'ps:'+'//l'+'ova'+'ble'+'.de'+'v/*'},_n35fcc8));for(const _n16f498 of _n1814d8||[]){if(!_n16f498['id'])continue;const _n35c794=await new Promise(_n4039dd=>{chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge_ORIG'](_n16f498['id'],{'action':'get'+'Tok'+'en'},_n45fc3d=>{void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],_n4039dd(_n45fc3d);});});_n4e043a(_n35c794&&_n35c794['tok'+'en'],'lov'+'abl'+'e-t'+'ab');if(_n49413c['len'+'gth']>0x0)break;}}catch(_n28dce5){}_n4e043a(_n348054['lov'+'abl'+'e_t'+'oke'+'n'],'sto'+'rag'+'e');if(_n49413c['len'+'gth']===0x0){_n3e4cca({'success':![],'ok':![],'error':'Tok'+'en\x20'+'do\x20'+'Lov'+'abl'+'e\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o.\x20'+'Rec'+'arr'+'egu'+'e\x20o'+'\x20pr'+'oje'+'to\x20'+'e\x20t'+'ent'+'e\x20n'+'ova'+'men'+'te.'});return;}const _n5ea4da=_n49413c[0x0]['tok'+'en'];chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_token':_n5ea4da});const _n254ae6=String(_n2a26a2['mes'+'sag'+'e']||''),_n14c774=_n348054['lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads']||[],_ne5060c=_n14c774['len'+'gth']>0x0?_n14c774[_n14c774['len'+'gth']-0x1]['bod'+'y']:null;let _n1e6c54={};_ne5060c&&typeof _ne5060c==='obj'+'ect'&&(_n1e6c54={..._ne5060c},delete _n1e6c54['int'+'ent'],delete _n1e6c54['err'+'or_'+'ids'],delete _n1e6c54['mes'+'sag'+'e_i'+'nte'+'nt_'+'met'+'ada'+'ta'],delete _n1e6c54['con'+'tai'+'ns_'+'err'+'or']);const _n4f24ca=Array['isA'+'rra'+'y'](_n2a26a2['att'+'ach'+'men'+'ts'])?_n2a26a2['att'+'ach'+'men'+'ts']:[],_n5f052e=_n348054['ses'+'sio'+'nTo'+'ken']||null,_n255678=_n2a26a2['lic'+'ens'+'eKe'+'y']||_n348054['ql_'+'ck']||_n348054['__l'+'v_c']||null,_n413fc1=_n2a26a2['dev'+'ice'+'Fin'+'ger'+'pri'+'nt']||_n348054['__l'+'v_h']||_n348054['ql_'+'ed']||null,_n3c1059=_n348054['ql_'+'rea'+'l_l'+'ova'+'ble'+'_pa'+'ylo'+'ad']||{},_n1c07ee={'message':_n254ae6,'projectId':_n2dfa0e,'token':_n5ea4da,'mensagem':_n254ae6,'projeto_id':_n2dfa0e,'token_lovable':_n5ea4da,'git_sha':_n348054['lov'+'abl'+'e_g'+'it_'+'sha']||undefined,'browser_session_id':_n348054['lov'+'abl'+'e_b'+'row'+'ser'+'_se'+'ssi'+'on_'+'id']||undefined,'lovable_browser_session_id':_n348054['lov'+'abl'+'e_b'+'row'+'ser'+'_se'+'ssi'+'on_'+'id']||undefined,'attachments':_n4f24ca['len'+'gth']>0x0?_n4f24ca:undefined,'fast_ack':!![],'lastPayload':_n1e6c54,'client_id':_n3c1059['cli'+'ent'+'_id']||undefined,'integration_metadata':_n3c1059['int'+'egr'+'ati'+'on_'+'met'+'ada'+'ta']||undefined,'user_license_key':_n255678||undefined,'licenseKey':_n255678||undefined,'license_key':_n255678||undefined,'deviceFingerprint':_n413fc1||undefined,'device_id':_n413fc1||undefined},_n1b998=_BG_PROXY_URL,_n3a870a=_BG_PROXY_KEY,_n4c97fa='tr_'+Date['now']()+'_'+Math['ran'+'dom']()['toS'+'tri'+'ng'](0x24)['sli'+'ce'](0x2,0xa),_n23b26b={'Content-Type':'app'+'lic'+'ati'+'on/'+'jso'+'n','apikey':_n3a870a,'Authorization':'Bea'+'rer'+'\x20'+(_n5f052e||_n3a870a),'x-extension-trace-id':_n4c97fa};let _n26b445;for(let _n5a2799=0x0;_n5a2799<=0x2;_n5a2799++){const _n32fa34=new AbortController(),_n107d2b=setTimeout(()=>_n32fa34['abo'+'rt'](),0xafc8);try{_n26b445=await fetch(_n1b998,{'method':'POS'+'T','headers':_n23b26b,'body':JSON['str'+'ing'+'ify'](_n1c07ee),'signal':_n32fa34['sig'+'nal']}),clearTimeout(_n107d2b);if(_n26b445['ok']||_n26b445['sta'+'tus']<0x1f4||_n5a2799===0x2)break;await new Promise(_n3de07f=>setTimeout(_n3de07f,0x5dc*(_n5a2799+0x1)));}catch(_n302810){clearTimeout(_n107d2b);if(_n5a2799===0x2)throw _n302810;await new Promise(_n478115=>setTimeout(_n478115,0x5dc*(_n5a2799+0x1)));}}chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_last_send_log':{'ts':Date['now'](),'projectId':_n2dfa0e,'status':_n26b445['sta'+'tus'],'ok':_n26b445['ok'],'step':'sen'+'dMe'+'ssa'+'ge_'+'pro'+'xy_'+'v62'+'34'}});if(_n26b445['ok']){let _n2e0d32;try{const _n119897=JSON['par'+'se'](await _n26b445['tex'+'t']());if(typeof _n119897['cmd'+'_co'+'unt']==='num'+'ber'){_n2e0d32=_n119897['cmd'+'_co'+'unt'];const _n2c9e3c=await new Promise(_n51c338=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['ql_'+'cmd'+'_co'+'unt'],_n51c338)),_n6ac20a=_n2c9e3c&&_n2c9e3c['ql_'+'cmd'+'_co'+'unt']||0x0;chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_cmd_count':Math['max'](_n6ac20a,_n2e0d32)});}}catch(_n56e353){}_n3e4cca({'success':!![],'ok':!![],'status':_n26b445['sta'+'tus'],'cmd_count':_n2e0d32});}else{const _nb08dc=await _n26b445['tex'+'t']()['cat'+'ch'](()=>'');let _n379bd7={};try{_n379bd7=JSON['par'+'se'](_nb08dc);}catch{}const _n3499ec=_n379bd7['err'+'or_'+'dis'+'pla'+'y']||_n379bd7['mes'+'sag'+'e']||_n379bd7['err'+'or']||'Err'+'o\x20'+_n26b445['sta'+'tus']+('.\x20R'+'eca'+'rre'+'gue'+'\x20o\x20'+'Lov'+'abl'+'e\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.');_n3e4cca({'success':![],'ok':![],'status':_n26b445['sta'+'tus'],'error':_n3499ec});}}catch(_n30a12c){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20se'+'ndM'+'ess'+'age'+'\x20er'+'ror'+':',_n30a12c),_n3e4cca({'success':![],'ok':![],'error':_n30a12c['mes'+'sag'+'e']||String(_n30a12c)});}})()),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='upl'+'oad'+'Att'+'ach'+'men'+'t')return((async()=>{try{let _n5c0cc9=_n2a26a2['pro'+'jec'+'tId']||'';try{const _n4b7063=_n4b661f&&_n4b661f['tab']&&_n4b661f['tab']['url'];if(_n4b7063){const _n405f93=_n4b7063['mat'+'ch'](/\/projects\/([a-f0-9-]{36})/i);if(_n405f93)_n5c0cc9=_n405f93[0x1];}if(!_n5c0cc9){const _n301d09=await new Promise(_n83e975=>chrome['tab'+'s']['que'+'ry']({'active':!![],'currentWindow':!![]},_n83e975));for(const _n24fcd5 of _n301d09||[]){const _ncdc4e4=(_n24fcd5['url']||'')['mat'+'ch'](/\/projects\/([a-f0-9-]{36})/i);if(_ncdc4e4){_n5c0cc9=_ncdc4e4[0x1];break;}}}}catch(_n4001c7){}if(!_n5c0cc9){const _n1d1c0a=await new Promise(_n1c1976=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_p'+'roj'+'ect'+'Id'],_n1c1976));_n5c0cc9=_n1d1c0a['lov'+'abl'+'e_p'+'roj'+'ect'+'Id']||'';}const _n4f9829=await new Promise(_n5ccb3e=>chrome['sto'+'rag'+'e']['loc'+'al']['get'](['lov'+'abl'+'e_t'+'oke'+'n'],_n5ccb3e)),_n5cb470=new Set(),_n44509f=[],_n1be1a3=(_n53caf4,_n30357f)=>{const _n8c56f1=String(_n53caf4||'')['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']();if(!_n8c56f1||_n8c56f1['len'+'gth']<0x14||_n5cb470['has'](_n8c56f1))return;_n5cb470['add'](_n8c56f1),_n44509f['pus'+'h']({'token':_n8c56f1,'source':_n30357f});};try{let _n27b74b=_n4b661f&&_n4b661f['tab']&&_n4b661f['tab']['id']||null;if(!_n27b74b){const _n48d2ed=await new Promise(_n4292b1=>chrome['tab'+'s']['que'+'ry']({'active':!![],'currentWindow':!![]},_n4292b1));_n27b74b=_n48d2ed&&_n48d2ed[0x0]&&_n48d2ed[0x0]['id'];}if(_n27b74b){const _n5026d8=await new Promise(_n39d170=>{chrome['tab'+'s']['sen'+'dMe'+'ssa'+'ge_ORIG'](_n27b74b,{'action':'get'+'Tok'+'en'},_n3fe0f1=>{void chrome['run'+'tim'+'e']['las'+'tEr'+'ror'],_n39d170(_n3fe0f1);});});_n1be1a3(_n5026d8&&_n5026d8['tok'+'en'],'con'+'ten'+'t-a'+'cti'+'ve');}}catch(_n1b0182){}_n1be1a3(_n4f9829['lov'+'abl'+'e_t'+'oke'+'n'],'sto'+'rag'+'e');if(_n44509f['len'+'gth']===0x0){_n3e4cca({'ok':![],'error':'Tok'+'en\x20'+'do\x20'+'Lov'+'abl'+'e\x20n'+'ão\x20'+'enc'+'ont'+'rad'+'o.\x20'+'Rec'+'arr'+'egu'+'e\x20a'+'\x20pá'+'gin'+'a.'});return;}const _n193a53=_n44509f[0x0]['tok'+'en'],_n2e5c7c=_BG_PROXY_URL,_n1f345c=_BG_PROXY_KEY,_n59ca1c=new AbortController(),_n199c99=setTimeout(()=>_n59ca1c['abo'+'rt'](),0xafc8);let _n58ba4e;try{_n58ba4e=await fetch(_n2e5c7c,{'method':'POS'+'T','headers':{'Content-Type':'app'+'lic'+'ati'+'on/'+'jso'+'n','apikey':_n1f345c,'Authorization':'Bea'+'rer'+'\x20'+_n1f345c},'body':JSON['str'+'ing'+'ify']({'action':'upl'+'oad','token_lovable':_n193a53,'file_name':_n2a26a2['fil'+'eNa'+'me'],'content_type':_n2a26a2['con'+'ten'+'tTy'+'pe'],'file_data':_n2a26a2['fil'+'eDa'+'ta'],'projeto_id':_n5c0cc9}),'signal':_n59ca1c['sig'+'nal']});}finally{clearTimeout(_n199c99);}const _n291387=await _n58ba4e['jso'+'n']()['cat'+'ch'](()=>({}));if(!_n58ba4e['ok']||_n291387['err'+'or']){_n3e4cca({'ok':![],'error':_n291387['err'+'or']||'Err'+'o\x20'+_n58ba4e['sta'+'tus']+('\x20no'+'\x20up'+'loa'+'d')});return;}if(!_n291387['fil'+'e_i'+'d']&&!_n291387['dow'+'nlo'+'ad_'+'url']){_n3e4cca({'ok':![],'error':'Upl'+'oad'+'\x20fa'+'lho'+'u\x20—'+'\x20se'+'m\x20f'+'ile'+'_id'+'/do'+'wnl'+'oad'+'_ur'+'l'});return;}_n3e4cca({'ok':!![],'result':_n291387});}catch(_n2e06dd){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20up'+'loa'+'dAt'+'tac'+'hme'+'nt\x20'+'err'+'or:',_n2e06dd),_n3e4cca({'ok':![],'error':_n2e06dd['mes'+'sag'+'e']||String(_n2e06dd)});}})()),!![];if(_n2a26a2&&_n2a26a2['act'+'ion']==='pro'+'xyF'+'etc'+'h')return((async()=>{const _n1511f2=_n2a26a2['hea'+'der'+'s']||{},_n3b506f={..._n1511f2,'User-Agent':_n1511f2['Use'+'r-A'+'gen'+'t']||navigator['use'+'rAg'+'ent'],'X-Extension-Version':'5.8','X-User-Agent':'Lov'+'abl'+'e-I'+'nfi'+'nit'+'e/5'+'.8\x20'+'('+navigator['use'+'rAg'+'ent']+')'},_n4f397c={'method':_n2a26a2['met'+'hod']||'POS'+'T','headers':_n3b506f};if(_n2a26a2['bod'+'y'])_n4f397c['bod'+'y']=_n2a26a2['bod'+'y'];const _n1c5e02=0x3;let _n362e89=null;for(let _n44d0f6=0x1;_n44d0f6<=_n1c5e02;_n44d0f6++){try{console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pr'+'oxy'+'Fet'+'ch\x20'+'(tr'+'y\x20'+_n44d0f6+'/'+_n1c5e02+(')\x20-'+'>'),_n2a26a2['url']);const _n3c0f7a=new AbortController(),_n5ede0f=setTimeout(()=>_n3c0f7a['abo'+'rt'](),0x3a98),_n3d87a7=await fetch(_n2a26a2['url'],{..._n4f397c,'signal':_n3c0f7a['sig'+'nal']});clearTimeout(_n5ede0f);const _n2c7118=await _n3d87a7['tex'+'t']();let _n214f0f;try{_n214f0f=JSON['par'+'se'](_n2c7118);}catch(_n16b739){_n214f0f={'raw':_n2c7118};}_n3e4cca({'ok':_n3d87a7['ok'],'status':_n3d87a7['sta'+'tus'],'data':_n214f0f});return;}catch(_n1ee789){_n362e89=_n1ee789,console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pr'+'oxy'+'Fet'+'ch\x20'+'att'+'emp'+'t\x20'+_n44d0f6+('\x20fa'+'ile'+'d:'),_n1ee789?.['mes'+'sag'+'e']||_n1ee789),_n44d0f6<_n1c5e02&&await new Promise(_n44f695=>setTimeout(_n44f695,0x1f4*_n44d0f6));}}const _n1168ec=String(_n362e89?.['mes'+'sag'+'e']||_n362e89||'Err'+'o\x20d'+'esc'+'onh'+'eci'+'do');let _n29ec37='Não'+'\x20fo'+'i\x20p'+'oss'+'íve'+'l\x20c'+'one'+'cta'+'r\x20a'+'o\x20s'+'erv'+'ido'+'r.\x20'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20i'+'nte'+'rne'+'t\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.\x0a'+'\x0aPo'+'ssí'+'vei'+'s\x20c'+'aus'+'as:'+'\x0a•\x20'+'Fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20bl'+'oqu'+'ean'+'do\x20'+'(Ka'+'spe'+'rsk'+'y,\x20'+'AVG'+',\x20A'+'vas'+'t,\x20'+'Win'+'dow'+'s\x20D'+'efe'+'nde'+'r)\x0a'+'•\x20V'+'PN\x20'+'ou\x20'+'pro'+'xy\x20'+'ati'+'vo\x0a'+'•\x20B'+'loq'+'uea'+'dor'+'\x20de'+'\x20an'+'únc'+'ios'+'\x20(u'+'Blo'+'ck,'+'\x20Ad'+'Blo'+'ck)'+'\x0a•\x20'+'Int'+'ern'+'et\x20'+'ins'+'táv'+'el\x0a'+'\x0aO\x20'+'que'+'\x20fa'+'zer'+':\x0a1'+')\x20P'+'aus'+'e\x20o'+'\x20an'+'tiv'+'íru'+'s/f'+'ire'+'wal'+'l\x20p'+'or\x20'+'1\x20m'+'inu'+'to\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'\x0a2)'+'\x20De'+'sli'+'gue'+'\x20VP'+'N/p'+'rox'+'y\x20s'+'e\x20e'+'sti'+'ver'+'\x20us'+'and'+'o\x0a3'+')\x20D'+'esa'+'tiv'+'e\x20e'+'xte'+'nsõ'+'es\x20'+'blo'+'que'+'ado'+'ras'+'\x20ne'+'sta'+'\x20ab'+'a\x0a4'+')\x20L'+'ibe'+'re\x20'+'o\x20d'+'omí'+'nio'+'\x20su'+'pab'+'ase'+'.co'+'\x20no'+'\x20fi'+'rew'+'all';if(/abort/i['tes'+'t'](_n1168ec))_n29ec37='Tem'+'po\x20'+'de\x20'+'con'+'exã'+'o\x20e'+'sgo'+'tad'+'o.\x20'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20i'+'nte'+'rne'+'t\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.\x0a'+'\x0aPo'+'ssí'+'vei'+'s\x20c'+'aus'+'as:'+'\x0a•\x20'+'Fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20bl'+'oqu'+'ean'+'do\x20'+'(Ka'+'spe'+'rsk'+'y,\x20'+'AVG'+',\x20A'+'vas'+'t,\x20'+'Win'+'dow'+'s\x20D'+'efe'+'nde'+'r)\x0a'+'•\x20V'+'PN\x20'+'ou\x20'+'pro'+'xy\x20'+'ati'+'vo\x0a'+'•\x20B'+'loq'+'uea'+'dor'+'\x20de'+'\x20an'+'únc'+'ios'+'\x20(u'+'Blo'+'ck,'+'\x20Ad'+'Blo'+'ck)'+'\x0a•\x20'+'Int'+'ern'+'et\x20'+'ins'+'táv'+'el\x0a'+'\x0aO\x20'+'que'+'\x20fa'+'zer'+':\x0a1'+')\x20P'+'aus'+'e\x20o'+'\x20an'+'tiv'+'íru'+'s/f'+'ire'+'wal'+'l\x20p'+'or\x20'+'1\x20m'+'inu'+'to\x20'+'e\x20t'+'ent'+'e\x20d'+'e\x20n'+'ovo'+'\x0a2)'+'\x20De'+'sli'+'gue'+'\x20VP'+'N/p'+'rox'+'y\x20s'+'e\x20e'+'sti'+'ver'+'\x20us'+'and'+'o\x0a3'+')\x20D'+'esa'+'tiv'+'e\x20e'+'xte'+'nsõ'+'es\x20'+'blo'+'que'+'ado'+'ras'+'\x20ne'+'sta'+'\x20ab'+'a\x0a4'+')\x20L'+'ibe'+'re\x20'+'o\x20d'+'omí'+'nio'+'\x20su'+'pab'+'ase'+'.co'+'\x20no'+'\x20fi'+'rew'+'all';else{if(/Failed to fetch|NetworkError|net::|ENOTFOUND|ECONNREFUSED/i['tes'+'t'](_n1168ec))_n29ec37='Fal'+'ha\x20'+'de\x20'+'red'+'e.\x20'+'Ver'+'ifi'+'que'+'\x20su'+'a\x20i'+'nte'+'rne'+'t,\x20'+'fir'+'ewa'+'ll\x20'+'ou\x20'+'ant'+'iví'+'rus'+'\x20e\x20'+'ten'+'te\x20'+'nov'+'ame'+'nte'+'.\x0a\x0a'+'Pos'+'sív'+'eis'+'\x20ca'+'usa'+'s:\x0a'+'•\x20F'+'ire'+'wal'+'l\x20o'+'u\x20a'+'nti'+'vír'+'us\x20'+'blo'+'que'+'and'+'o\x20('+'Kas'+'per'+'sky'+',\x20A'+'VG,'+'\x20Av'+'ast'+',\x20W'+'ind'+'ows'+'\x20De'+'fen'+'der'+')\x0a•'+'\x20VP'+'N\x20o'+'u\x20p'+'rox'+'y\x20a'+'tiv'+'o\x0a•'+'\x20Bl'+'oqu'+'ead'+'or\x20'+'de\x20'+'anú'+'nci'+'os\x20'+'(uB'+'loc'+'k,\x20'+'AdB'+'loc'+'k)\x0a'+'•\x20I'+'nte'+'rne'+'t\x20i'+'nst'+'áve'+'l\x0a\x0a'+'O\x20q'+'ue\x20'+'faz'+'er:'+'\x0a1)'+'\x20Pa'+'use'+'\x20o\x20'+'ant'+'iví'+'rus'+'/fi'+'rew'+'all'+'\x20po'+'r\x201'+'\x20mi'+'nut'+'o\x20e'+'\x20te'+'nte'+'\x20de'+'\x20no'+'vo\x0a'+'2)\x20'+'Des'+'lig'+'ue\x20'+'VPN'+'/pr'+'oxy'+'\x20se'+'\x20es'+'tiv'+'er\x20'+'usa'+'ndo'+'\x0a3)'+'\x20De'+'sat'+'ive'+'\x20ex'+'ten'+'sõe'+'s\x20b'+'loq'+'uea'+'dor'+'as\x20'+'nes'+'ta\x20'+'aba'+'\x0a4)'+'\x20Li'+'ber'+'e\x20o'+'\x20do'+'mín'+'io\x20'+'sup'+'aba'+'se.'+'co\x20'+'no\x20'+'fir'+'ewa'+'ll';else{if(/CORS/i['tes'+'t'](_n1168ec))_n29ec37='Blo'+'que'+'io\x20'+'de\x20'+'seg'+'ura'+'nça'+'\x20de'+'tec'+'tad'+'o.\x20'+'Rec'+'arr'+'egu'+'e\x20a'+'\x20pá'+'gin'+'a\x20e'+'\x20te'+'nte'+'\x20no'+'vam'+'ent'+'e.';}}console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20pr'+'oxy'+'Fet'+'ch\x20'+'giv'+'ing'+'\x20up'+':',_n1168ec),_n3e4cca({'ok':![],'status':0x0,'data':{'error':_n29ec37,'detail':_n1168ec}});})()),!![];});try{chrome['web'+'Req'+'ues'+'t']['onB'+'efo'+'reS'+'end'+'Hea'+'der'+'s']['add'+'Lis'+'ten'+'er'](_n4cf946=>{const _neba6e2=(_n4cf946['req'+'ues'+'tHe'+'ade'+'rs']||[])['fin'+'d'](_n421cb0=>_n421cb0['nam'+'e']['toL'+'owe'+'rCa'+'se']()==='aut'+'hor'+'iza'+'tio'+'n');if(_neba6e2&&_neba6e2['val'+'ue']){const _n304797=_neba6e2['val'+'ue']['rep'+'lac'+'e'](/^Bearer\s+/i,'')['tri'+'m']();if(_n304797['len'+'gth']>0x14){const _n376ae0={'lovable_token':_n304797};_n4cf946['tab'+'Id']&&_n4cf946['tab'+'Id']>0x0&&(_n376ae0['lov'+'_to'+'k_'+_n4cf946['tab'+'Id']]=_n304797);const _n242942=/\/projects\/[a-f0-9-]{36}\/chat$/i['tes'+'t'](_n4cf946['url']);_n242942&&(_n376ae0['lov'+'_ht']=_n304797,_n4cf946['tab'+'Id']&&_n4cf946['tab'+'Id']>0x0&&(_n376ae0['lov'+'_ht'+'_'+_n4cf946['tab'+'Id']]=_n304797)),chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n376ae0);}}const _n2809f8=_n4cf946['url']['mat'+'ch'](/projects\/([a-f0-9-]{36})/);if(_n2809f8&&_n2809f8[0x1]){const _n1584e4=_n2809f8[0x1],_n260ba6={'lovable_projectId':_n1584e4};_n4cf946['tab'+'Id']&&_n4cf946['tab'+'Id']>0x0&&(_n260ba6['lov'+'_pi'+'d_'+_n4cf946['tab'+'Id']]=_n1584e4),chrome['sto'+'rag'+'e']['loc'+'al']['set'](_n260ba6);}const _n28dafa=_n4cf946['url']['mat'+'ch'](/workspaces\/([A-Za-z0-9_-]{8,40})/);_n28dafa&&_n28dafa[0x1]&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_workspaceId':_n28dafa[0x1]});const _n9a79b4=(_n4cf946['req'+'ues'+'tHe'+'ade'+'rs']||[])['fin'+'d'](_n3b27f7=>_n3b27f7['nam'+'e']['toL'+'owe'+'rCa'+'se']()==='x-b'+'row'+'ser'+'-se'+'ssi'+'on-'+'id');_n9a79b4&&_n9a79b4['val'+'ue']&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_browser_session_id':_n9a79b4['val'+'ue']});const _n4d45f7=(_n4cf946['req'+'ues'+'tHe'+'ade'+'rs']||[])['fin'+'d'](_n12e767=>_n12e767['nam'+'e']['toL'+'owe'+'rCa'+'se']()==='x-c'+'ast'+'le-'+'req'+'ues'+'t-t'+'oke'+'n');_n4d45f7&&_n4d45f7['val'+'ue']&&_n4d45f7['val'+'ue']['len'+'gth']>0x64&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_castle_token':_n4d45f7['val'+'ue'],'lovable_castle_ts':Date['now']()});},{'urls':['htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'*']},['req'+'ues'+'tHe'+'ade'+'rs','ext'+'raH'+'ead'+'ers']);;}catch(bg_n3ecbf9){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20we'+'bRe'+'que'+'st\x20'+'lis'+'ten'+'er\x20'+'ind'+'isp'+'oní'+'vel'+':',bg_n3ecbf9?.['mes'+'sag'+'e']);}try{chrome['web'+'Req'+'ues'+'t']['onB'+'efo'+'reR'+'equ'+'est']['add'+'Lis'+'ten'+'er'](_n1d33ab=>{if(_n1d33ab['met'+'hod']!=='POS'+'T')return;if(!_n1d33ab['req'+'ues'+'tBo'+'dy']||!_n1d33ab['req'+'ues'+'tBo'+'dy']['raw'])return;try{const _n3ce4dd=_n1d33ab['req'+'ues'+'tBo'+'dy']['raw'][0x0]&&_n1d33ab['req'+'ues'+'tBo'+'dy']['raw'][0x0]['byt'+'es'];if(!_n3ce4dd)return;const _n563ad3=new TextDecoder('utf'+'-8')['dec'+'ode'](_n3ce4dd);if(!_n563ad3||_n563ad3['len'+'gth']<0xa)return;const _n5b1e0f=JSON['par'+'se'](_n563ad3);if(!_n5b1e0f||typeof _n5b1e0f!=='obj'+'ect')return;const _nfaf6f={};if(_n5b1e0f['thr'+'ead'+'_id'])_nfaf6f['thr'+'ead'+'_id']=_n5b1e0f['thr'+'ead'+'_id'];if(_n5b1e0f['vie'+'w'])_nfaf6f['vie'+'w']=_n5b1e0f['vie'+'w'];if(_n5b1e0f['mod'+'el'])_nfaf6f['mod'+'el']=_n5b1e0f['mod'+'el'];if(_n5b1e0f['cur'+'ren'+'t_p'+'age'])_nfaf6f['cur'+'ren'+'t_p'+'age']=_n5b1e0f['cur'+'ren'+'t_p'+'age'];if(_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_w'+'idt'+'h'])_nfaf6f['cur'+'ren'+'t_v'+'iew'+'por'+'t_w'+'idt'+'h']=_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_w'+'idt'+'h'];if(_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_h'+'eig'+'ht'])_nfaf6f['cur'+'ren'+'t_v'+'iew'+'por'+'t_h'+'eig'+'ht']=_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_h'+'eig'+'ht'];if(_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_d'+'pr'])_nfaf6f['cur'+'ren'+'t_v'+'iew'+'por'+'t_d'+'pr']=_n5b1e0f['cur'+'ren'+'t_v'+'iew'+'por'+'t_d'+'pr'];if(_n5b1e0f['ses'+'sio'+'n_r'+'epl'+'ay'])_nfaf6f['ses'+'sio'+'n_r'+'epl'+'ay']=_n5b1e0f['ses'+'sio'+'n_r'+'epl'+'ay'];if(_n5b1e0f['cli'+'ent'+'_id'])_nfaf6f['cli'+'ent'+'_id']=_n5b1e0f['cli'+'ent'+'_id'];if(_n5b1e0f['int'+'egr'+'ati'+'on_'+'met'+'ada'+'ta'])_nfaf6f['int'+'egr'+'ati'+'on_'+'met'+'ada'+'ta']=_n5b1e0f['int'+'egr'+'ati'+'on_'+'met'+'ada'+'ta'];Object['key'+'s'](_nfaf6f)['len'+'gth']>0x0&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'ql_real_lovable_payload':_nfaf6f});_n5b1e0f['ai_'+'mes'+'sag'+'e_i'+'d']&&typeof _n5b1e0f['ai_'+'mes'+'sag'+'e_i'+'d']==='str'+'ing'&&_n5b1e0f['ai_'+'mes'+'sag'+'e_i'+'d']['sta'+'rts'+'Wit'+'h']('aim'+'sg_')&&chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_last_aimsg':_n5b1e0f['ai_'+'mes'+'sag'+'e_i'+'d']});const _n51fd4c={'timestamp':Date['now'](),'url':_n1d33ab['url'],'body':_n5b1e0f};chrome['sto'+'rag'+'e']['loc'+'al']['get']({'lovable_chat_payloads':[]},_n4bd35d=>{const _n5e7577=_n4bd35d['lov'+'abl'+'e_c'+'hat'+'_pa'+'ylo'+'ads']||[];_n5e7577['pus'+'h'](_n51fd4c);if(_n5e7577['len'+'gth']>0x14)_n5e7577['spl'+'ice'](0x0,_n5e7577['len'+'gth']-0x14);chrome['sto'+'rag'+'e']['loc'+'al']['set']({'lovable_chat_payloads':_n5e7577});});}catch(_n543295){}},{'urls':['htt'+'ps:'+'//a'+'pi.'+'lov'+'abl'+'e.d'+'ev/'+'pro'+'jec'+'ts/'+'*/c'+'hat']},['req'+'ues'+'tBo'+'dy']),console['log']('[Ba'+'ckg'+'rou'+'nd]'+'\x20on'+'Bef'+'ore'+'Req'+'ues'+'t\x20a'+'tiv'+'o\x20—'+'\x20ca'+'ptu'+'ra\x20'+'pay'+'loa'+'d\x20n'+'ati'+'vo\x20'+'do\x20'+'cha'+'t');}catch(bg_n55770b){console['war'+'n']('[Ba'+'ckg'+'rou'+'nd]'+'\x20on'+'Bef'+'ore'+'Req'+'ues'+'t\x20i'+'ndi'+'spo'+'nív'+'el:',bg_n55770b?.['mes'+'sag'+'e']);}
// [Manus] Background Send Bridge
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'sendMessage') {
        console.log("[Manus] Intercepting sendMessage for direct bridge");
        
        chrome.storage.local.get([
            'lovable_token', 
            'lovable_projectId', 
            'lovable_browser_session_id',
            'ql_real_lovable_payload'
        ], async (res) => {
            const tabId = sender.tab ? sender.tab.id : (await chrome.tabs.query({active: true, currentWindow: true}))[0]?.id;
            
            let token = res.lovable_token;
            let projectId = res.lovable_projectId;
            
            if (tabId) {
                const tabData = await chrome.storage.local.get([`lov_tok_${tabId}`, `lov_pid_${tabId}`, `lov_ht_${tabId}`]);
                token = token || tabData[`lov_tok_${tabId}`] || tabData[`lov_ht_${tabId}`];
                projectId = projectId || tabData[`lov_pid_${tabId}`];
            }

            if (!token || !projectId) {
                sendResponse({ status: 'error', message: 'Token do Lovable não encontrado. Recarregue a página do Lovable.' });
                return;
            }

            try {
                const payload = res.ql_real_lovable_payload || {};
                const response = await fetch(`https://api.lovable.dev/projects/${projectId}/chat`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                        'X-Browser-Session-Id': res.lovable_browser_session_id || ''
                    },
                    body: JSON.stringify({
                        ...payload,
                        message: request.message,
                        optimisticImageUrls: request.optimisticUrls || []
                    })
                });

                if (response.ok) {
                    sendResponse({ status: 'ok' });
                } else {
                    const errData = await response.json().catch(() => ({}));
                    sendResponse({ status: 'error', message: errData.message || 'Erro na API do Lovable' });
                }
            } catch (err) {
                sendResponse({ status: 'error', message: err.message });
            }
        });
        return true; 
    }
});
